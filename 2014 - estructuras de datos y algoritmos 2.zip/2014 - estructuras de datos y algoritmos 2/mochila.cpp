void mochila(int objetoHasta, int dineroHasta, int tiempoHasta, Arrat<Estadio> o, int* solactual, int *solOptima
, int valorActual, int & mejorValor)
{
	if(objetoHasta>0)
	{
		if(dinero>=0 && tiempoHasa>=0)
		{
			for(int k=0; k<=o[objetoHasta].cantidad;k++)
			{
				int dinero = dineroHasta - k*o[objetoHasta].precio;
				int tiempo =  tiempoHasta -k*o[objetoHasta].tiempo;
				int valor = valorActual + k*o[objetoHasta].valor
				solActual[objetoHasta]=k;
				mochcila(objetoHasta-1,dinero,tiempo,o,solActual,valor,mojorValor);
			};
		};
	}
	else
	{
		if(valorActual>mejorValor)
		{
			valorActual = mejorValor;
			copiar(solOptima,solActual);
		};
	}
}