void QS(int * v, int izq, int der)
{
	if(izq < der)
	{
		int postPivote = particion(v, izq, der);
		QS(v, izq, posPivote-1);
		QS(v, posPivote+1, der);
	
	};
};