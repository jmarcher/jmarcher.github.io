#ifndef ITERADORAVL_CPP
#define ITERADORAVL_CPP

#include "IteradorAVL.h"
#include <Assert.h>

template <class T>
IteradorAVL<T>::IteradorAVL(Puntero<nodoAVL<T>> raiz, nat largo)
{
	this->raiz = raiz;
	stack = Array<Puntero<nodoAVL<T>>>(largo);
	Reiniciar();
}

template <class T>
IteradorAVL<T>::~IteradorAVL()
{
}


template <class T>
void IteradorAVL<T>::Reiniciar()
{
	for (nat i = 0; i < stack.ObtenerLargo(); i++)
		stack[i] = NULL;

	tope = 0;
	AgregarCamino(raiz);
}

template <class T>
bool IteradorAVL<T>::HayElemento() const
{
	return tope != 0;
}

template <class T>
const T& IteradorAVL<T>::ElementoActual() const
{
	assert(HayElemento());
	return stack[tope - 1]->dato;
}

template <class T>
void IteradorAVL<T>::Avanzar()
{
	assert(HayElemento());
	tope--;
	Puntero<nodoAVL<T>> actual = stack[tope];
	stack[tope] = NULL;
	AgregarCamino(actual->der);
}

template <class T>
void IteradorAVL<T>:: AgregarCamino(Puntero<nodoAVL<T>> nodo)
{
	while (nodo != NULL)
	{
		stack[tope] = nodo;
		tope++;
		nodo = nodo->izq;
	}
}

template<class T>
Puntero<Iteracion<T>> IteradorAVL<T>::Clonar() const
{
	Puntero<Iteracion<T>> iter;

	return iter;
};

#endif