﻿#ifndef ISISTEMA_H
#define ISISTEMA_H

#include "Cadena.h"
#include "Iterador.h"
#include "Puntero.h"
#include "TipoRetorno.h"
#include "Tupla.h"
#include "IEstacion.h"
#include "ILinea.h"

class ISistema abstract
{
public:
	virtual ~ISistema(){}

	// Hito de Control Tipo 1
	virtual TipoRetorno IngresoEstacion(Cadena nombre, nat hAbre, nat hCierra) abstract;
	virtual TipoRetorno IngresoLinea(nat nroLinea, nat precio, Iterador<Tupla<Cadena, nat, nat, nat>> estaciones) abstract;
	virtual TipoRetorno HabilitacionTramo(nat nroLinea, Cadena eOrigen, Cadena eDestino, bool habilitado) abstract;
	virtual Tupla<TipoRetorno, pLinea> ConsultaLinea(nat nroLinea) abstract;
	virtual Tupla<TipoRetorno, pEstacion> ConsultaEstacion(Cadena nombreEstacion) abstract;
	virtual Tupla<TipoRetorno, Iterador<pEstacion>> ListadoEstaciones() abstract;
	virtual Tupla<TipoRetorno, pEstacion> EstacionMasLineasHabilitadas() abstract;

	// Entrega final Tipo 1
	virtual Tupla<TipoRetorno, Iterador<pEstacion>> ListadoEstacionesHorario() abstract;
	virtual Tupla<TipoRetorno, Iterador<pEstacion>> TrayectoMenorDistancia(Cadena eOrigen, Cadena eDestino, nat hora) abstract;
	virtual Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> CableadoMenorDistancia() abstract;
	virtual Tupla<TipoRetorno, Iterador<pEstacion>> ListadoTrayecto(Iterador<Cadena> estaciones) abstract;
	virtual Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> ListadoTodosLosTrayectos(Cadena eOrigen, Cadena eDestino) abstract;

	// Entrega final Tipo 2
	virtual Tupla<TipoRetorno, Iterador<pEstacion>> TrayectoMenosTransbordos(Cadena eOrigen, Cadena eDestino) abstract;
	virtual Tupla<TipoRetorno, nat> CantidadMaxima(Cadena eOrigen, Cadena eDestino) abstract;
	virtual Tupla<TipoRetorno, nat, Iterador<pLinea>> LineasAAbordarA(nat dineroMax) abstract;
	virtual Tupla<TipoRetorno, nat, Iterador<pLinea>> LineasAAbordarB(nat dineroMax) abstract;

	// Operaciones opcionales
	virtual Tupla<TipoRetorno, Iterador<pEstacion>> EstacionesCriticas(Cadena eOrigen, Cadena eDestino) abstract;
};

#endif
