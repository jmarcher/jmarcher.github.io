﻿#include "CasoDePrueba.h"
#include "PruebasMock.h"

CasoDePrueba::CasoDePrueba(Puntero<ISistema> (*inicializar)(nat MAX_LINEAS, nat MAX_ESTACIONES))
{
	this->inicializar = inicializar;
}

Puntero<ISistema> CasoDePrueba::InicializarSistema(nat MAX_LINEAS, nat MAX_ESTACIONES)
{
	Puntero<ISistema> interfaz = inicializar(MAX_LINEAS, MAX_ESTACIONES);
	ignorarOK = false;
	return interfaz;
}

void CasoDePrueba::InicializarEstacion(Puntero<ISistema> interfaz)
{
	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema();
	Cadena ingreso = " Se ingresa la estacion {0}";

	foreach (estacion, estaciones)
		Verificar(interfaz->IngresoEstacion(estacion->ObtenerNombre(), estacion->ObtenerHAbre(), estacion->ObtenerHCierra()), OK, ingreso.DarFormato(estacion->ObtenerNombre()));
}

void CasoDePrueba::InicializarLinea(Puntero<ISistema> interfaz)
{
	Array<pLinea> lineas = ObtenerLineasDelSistema();
	Cadena ingreso = " Se ingresa la linea {0}";

	foreach (linea, lineas)
	{
		char nroLinea[8]; 
		_itoa_s(linea->ObtenerNroLinea(), nroLinea, 10);

		Verificar(interfaz->IngresoLinea(linea->ObtenerNroLinea(), linea->ObtenerPrecio(), linea->ObtenerEstaciones().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), OK, ingreso.DarFormato(nroLinea));
	}
}

Array<pEstacion> CasoDePrueba::ObtenerEstacionesDelSistema(nat orden)
{
	Array<pEstacion> retorno = Array<pEstacion>(23);

	//Orden de ingreso (sin orden)
	if(orden == 0)
	{
		retorno[0] = new EstacionMock("Atocha", 10, 20);
		retorno[1] = new EstacionMock("San Cristóbal", 11, 20);
		retorno[2] = new EstacionMock("Mirasierra", 18, 23);
		retorno[3] = new EstacionMock("Boadilla", 8, 22);
		retorno[4] = new EstacionMock("Callao", 4, 21);
		retorno[5] = new EstacionMock("Cartagena", 7, 22);
		retorno[6] = new EstacionMock("Jarama", 12, 17);
		retorno[7] = new EstacionMock("Esperanza", 9, 20);
		retorno[8] = new EstacionMock("La Fortuna", 3, 18);
		retorno[9] = new EstacionMock("Estrecho", 5, 23);
		retorno[10] = new EstacionMock("Fuencarral", 9, 20);
		retorno[11] = new EstacionMock("Goya", 8, 20);
		retorno[12] = new EstacionMock("Gran Vía", 7, 22);
		retorno[13] = new EstacionMock("Metropolitano", 7, 15);
		retorno[14] = new EstacionMock("Hortaleza", 13, 23);
		retorno[15] = new EstacionMock("Bilbao", 10, 21);
		retorno[16] = new EstacionMock("La Poveda", 1, 21);
		retorno[17] = new EstacionMock("Estadio Olímpico", 6, 20);
		retorno[18] = new EstacionMock("Portazgo", 12, 20);
		retorno[19] = new EstacionMock("Colón", 8, 19);
		retorno[20] = new EstacionMock("Henares", 10, 22);
		retorno[21] = new EstacionMock("Quevedo", 2, 21);
		retorno[22] = new EstacionMock("Barajas", 8, 19);
	}
	//nombre
	else if(orden == 1)
	{
		retorno[0] = new EstacionMock("Atocha", 10, 20);
		retorno[1] = new EstacionMock("Barajas", 8, 19);
		retorno[2] = new EstacionMock("Bilbao", 10, 21);
		retorno[3] = new EstacionMock("Boadilla", 8, 22);
		retorno[4] = new EstacionMock("Callao", 4, 21);
		retorno[5] = new EstacionMock("Cartagena", 7, 22);
		retorno[6] = new EstacionMock("Colón", 8, 19);
		retorno[7] = new EstacionMock("Esperanza", 9, 20);
		retorno[8] = new EstacionMock("Estadio Olímpico", 6, 20);
		retorno[9] = new EstacionMock("Estrecho", 5, 23);
		retorno[10] = new EstacionMock("Fuencarral", 9, 20);
		retorno[11] = new EstacionMock("Goya", 8, 20);
		retorno[12] = new EstacionMock("Gran Vía", 7, 22);
		retorno[13] = new EstacionMock("Henares", 10, 22);
		retorno[14] = new EstacionMock("Hortaleza", 13, 23);
		retorno[15] = new EstacionMock("Jarama", 12, 17);
		retorno[16] = new EstacionMock("La Fortuna", 3, 18);
		retorno[17] = new EstacionMock("La Poveda", 1, 21);
		retorno[18] = new EstacionMock("Metropolitano", 7, 15);
		retorno[19] = new EstacionMock("Mirasierra", 18, 23);
		retorno[20] = new EstacionMock("Portazgo", 12, 20);
		retorno[21] = new EstacionMock("Quevedo", 2, 21);
		retorno[22] = new EstacionMock("San Cristóbal", 11, 20);
	}
	return retorno;
}

Array<pLinea> CasoDePrueba::ObtenerLineasDelSistema()
{
	Array<pLinea> retorno = Array<pLinea>(7);
	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);
	
	Array<Tupla<pEstacion, nat, nat, nat>> tramos;
	
	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(5);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[18], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[1], 100, 8, 30);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[8], 50, 8, 30);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[19], 150, 20, 50);
	tramos[4] = Tupla<pEstacion, nat, nat, nat>(estaciones[15], 50, 10, 10);
	retorno[0] = new LineaMock(8, 20, tramos.ObtenerIterador());

	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(5);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[0], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[12], 50, 50, 15);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[17], 10, 20, 10);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[11], 15, 7, 10);
	tramos[4] = Tupla<pEstacion, nat, nat, nat>(estaciones[21], 10, 10, 10);
	retorno[1] = new LineaMock(10, 100, tramos.ObtenerIterador());

	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(4);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[13], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[6], 50, 10, 10);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[2], 100, 10, 10);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[7], 10, 10, 10);
	retorno[2] = new LineaMock(5, 50, tramos.ObtenerIterador());

	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(5);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[10], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[22], 50, 50, 15);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[9], 20, 20, 15);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[16], 15, 15, 10);
	tramos[4] = Tupla<pEstacion, nat, nat, nat>(estaciones[20], 20, 10, 10);
	retorno[3] = new LineaMock(19, 90, tramos.ObtenerIterador());

	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(4);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[4], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[14], 100, 50, 20);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[3], 50, 20, 15);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[5], 75, 25, 40);
	retorno[4] = new LineaMock(1, 50, tramos.ObtenerIterador());

	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(9);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[0], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[11], 50, 50, 75);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[17], 20, 10, 15);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[21], 10, 10, 10);
	tramos[4] = Tupla<pEstacion, nat, nat, nat>(estaciones[2], 50, 50, 50);
	tramos[5] = Tupla<pEstacion, nat, nat, nat>(estaciones[18], 105, 105, 105);
	tramos[6] = Tupla<pEstacion, nat, nat, nat>(estaciones[15], 575, 80, 20);
	tramos[7] = Tupla<pEstacion, nat, nat, nat>(estaciones[1], 50, 10, 8);
	tramos[8] = Tupla<pEstacion, nat, nat, nat>(estaciones[10], 80, 80, 80);
	retorno[5] = new LineaMock(2, 120, tramos.ObtenerIterador());

	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(8);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[5], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[4], 500, 100, 50);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[13], 10, 75, 15);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[7], 150, 8, 100);
	tramos[4] = Tupla<pEstacion, nat, nat, nat>(estaciones[2], 20, 30, 70);
	tramos[5] = Tupla<pEstacion, nat, nat, nat>(estaciones[11], 130, 85, 90);
	tramos[6] = Tupla<pEstacion, nat, nat, nat>(estaciones[17], 55, 70, 35);
	tramos[7] = Tupla<pEstacion, nat, nat, nat>(estaciones[0], 25, 90, 90);
	retorno[6] = new LineaMock(7, 110, tramos.ObtenerIterador());

	return retorno;
}

Cadena CasoDePrueba::GetNombre()const
{
	return "Casos de Prueba";
}

void CasoDePrueba::CorrerPruebaConcreta()
{
	PruebaOKIngresoEstacion();
	PruebaOKIngresoLinea();
	PruebaOKHabilitacionTramo();
	PruebaOKConsultaLinea();
	PruebaOKConsultaEstacion();
	PruebaOKListadoEstaciones();
	PruebaOKEstacionMasLineasHabilitadas();
	PruebaOKListadoEstacionesHorario();
	PruebaOKTrayectoMenorDistancia();
	PruebaOKCableadoMenorDistancia();
	PruebaOKListadoTrayecto();
	PruebaOKListadoTodosLosTrayectos();
	PruebaOKTrayectoMenosTransbordos();
	PruebaOKCantidadMaxima();
	PruebaOKLineasAAbordarA();
	PruebaOKLineasAAbordarB();
	PruebaOKEstacionesCriticas();

	PruebaERRORIngresoEstacion();
	PruebaERRORIngresoLinea();
	PruebaERRORHabilitacionTramo();
	PruebaERRORConsultaLinea();
	PruebaERRORConsultaEstacion();
	PruebaERRORListadoEstaciones();
	PruebaERROREstacionMasLineasHabilitadas();
	PruebaERRORListadoEstacionesHorario();
	PruebaERRORTrayectoMenorDistancia();
	PruebaERRORCableadoMenorDistancia();
	PruebaERRORListadoTrayecto();
	PruebaERRORListadoTodosLosTrayectos();
	PruebaERRORTrayectoMenosTransbordos();
	PruebaERRORCantidadMaxima();
	PruebaERRORLineasAAbordarA();
	PruebaERRORLineasAAbordarB();
	PruebaERROREstacionesCriticas();
}

void CasoDePrueba::Verificar(TipoRetorno obtenido, TipoRetorno esperado, Cadena comentario)
{
	if (!ignorarOK || obtenido != esperado)
		Prueba::Verificar(obtenido, esperado, comentario);
}

template <class T>
void CasoDePrueba::Verificar(const T& obtenido, const T& esperado, Cadena comentario)
{
	Verificar(SonIguales(obtenido, esperado) ? OK : ERROR, OK, comentario.DarFormato(ObtenerTexto(obtenido), ObtenerTexto(esperado)));
}

template <class T>
void CasoDePrueba::VerificarConjuntos(Iterador<T> obtenidos, Iterador<T> esperados, Cadena comentarioEncontrado, Cadena comentarioFalta, Cadena comentarioSobra)
{
	bool verificarCantidad = true;
	nat totalObtenidos = 0;
	foreach (obtenido, obtenidos)
	{
		totalObtenidos++;
		bool esta = false;
		foreach (esperado, esperados)
		{
			if (SonIguales(obtenido, esperado))
			{
				Verificar(OK, OK, comentarioEncontrado.DarFormato(ObtenerTexto(obtenido), ObtenerTexto(esperado)));
				esta = true;
				break;
			}
		}
		if (!esta)
		{
			Verificar(ERROR, OK, comentarioSobra.DarFormato(ObtenerTexto(obtenido)));
			verificarCantidad = false;
		}
	}
	nat totalEsperados = 0;
	foreach (esperado, esperados)
	{
		totalEsperados++;
		bool esta = false;
		foreach (obtenido, obtenidos)
		{
			if (SonIguales(obtenido, esperado))
			{
				esta = true;
				break;
			}
		}
		if (!esta)
		{
			Verificar(ERROR, OK, comentarioFalta.DarFormato(ObtenerTexto(esperado)));
			verificarCantidad = false;
		}
	}
	if (verificarCantidad && totalObtenidos != totalEsperados)
		Verificar(ERROR, OK, "Se verifica la cantidad de elementos de los conjuntos");
}

template <class T>
void CasoDePrueba::VerificarSecuencias(Iterador<T> obtenidos, Iterador<T> esperados, Cadena comentarioEncontrado, Cadena comentarioFalta, Cadena comentarioSobra)
{
	esperados.Reiniciar();

	foreach (obtenido, obtenidos)
	{
		if (esperados.HayElemento())
		{
			T esperado = *esperados;
			esperados++;
			Verificar(obtenido, esperado, comentarioEncontrado);
		}
		else
			Verificar(ERROR, OK, comentarioSobra.DarFormato(ObtenerTexto(obtenido)));
	}

	while (esperados.HayElemento())
	{
		T esperado = *esperados;
		esperados++;
		Verificar(ERROR, OK, comentarioFalta.DarFormato(ObtenerTexto(esperado)));
	}
}

template <class T>
bool CasoDePrueba::SonIguales(Iterador<T> obtenidos, Iterador<T> esperados) const
{
	obtenidos.Reiniciar();
	esperados.Reiniciar();
	while (obtenidos.HayElemento() && esperados.HayElemento())
	{
		if (!SonIguales(*obtenidos, *esperados))
			return false;
		obtenidos++;
		esperados++;
	}

	return esperados.HayElemento() == obtenidos.HayElemento();
}

template <class T>
bool CasoDePrueba::Pertenece(const T& obtenido, Iterador<T> esperados) const
{
	foreach (esperado, esperados)
	{
		if (SonIguales(obtenido, esperado))
			return true;
	}
	return false;
}

void CasoDePrueba::VerificarConsultaLinea(Tupla<TipoRetorno, pLinea> obtenido, Tupla<TipoRetorno, pLinea> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		Verificar(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarConsultaEstacion(Tupla<TipoRetorno, pEstacion> obtenido, Tupla<TipoRetorno, pEstacion> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		Verificar(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarListadoEstaciones(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarSecuencias(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarEstacionMasLineasHabilitadas(Tupla<TipoRetorno, pEstacion> obtenido, Tupla<TipoRetorno, pEstacion> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		Verificar(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarListadoEstacionesHorario(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarSecuencias(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarTrayectoMenorDistancia(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarSecuencias(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarCableadoMenorDistancia(Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> obtenido, Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarSecuencias(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarListadoTrayecto(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarSecuencias(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarListadoTodosLosTrayectos(Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> obtenido, Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarSecuencias(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarTrayectoMenosTransbordos(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarSecuencias(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarCantidadMaxima(Tupla<TipoRetorno, nat> obtenido, Tupla<TipoRetorno, nat> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		Verificar(obtenido.Dato2 == esperado.Dato2 ? OK : ERROR, OK, "Se verifica el dato 2");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarLineasAAbordarA(Tupla<TipoRetorno, nat, Iterador<pLinea>> obtenido, Tupla<TipoRetorno, nat, Iterador<pLinea>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		Verificar(obtenido.Dato2 == esperado.Dato2 ? OK : ERROR, OK, "Se verifica el dato 2");
		VerificarSecuencias(obtenido.Dato3, esperado.Dato3, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato3, esperado.Dato3, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarLineasAAbordarB(Tupla<TipoRetorno, nat, Iterador<pLinea>> obtenido, Tupla<TipoRetorno, nat, Iterador<pLinea>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		Verificar(obtenido.Dato2 == esperado.Dato2 ? OK : ERROR, OK, "Se verifica el dato 2");
		VerificarSecuencias(obtenido.Dato3, esperado.Dato3, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato3, esperado.Dato3, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarEstacionesCriticas(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarSecuencias(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

bool CasoDePrueba::SonIguales(const pEstacion& obtenido, const pEstacion& esperado) const
{
	return obtenido->ObtenerNombre() == esperado->ObtenerNombre() && obtenido->ObtenerHAbre() == esperado->ObtenerHAbre() && obtenido->ObtenerHCierra() == esperado->ObtenerHCierra();
}

Cadena CasoDePrueba::ObtenerTexto(const pEstacion& e) const
{
	return e->ObtenerNombre();
}

bool CasoDePrueba::SonIguales(const pLinea& obtenido, const pLinea& esperado) const
{
	return obtenido->ObtenerNroLinea() == esperado->ObtenerNroLinea() && obtenido->ObtenerPrecio() == esperado->ObtenerPrecio();
}

Cadena CasoDePrueba::ObtenerTexto(const pLinea& l) const
{
	return "Indefinido";
}

bool CasoDePrueba::SonIguales(const Tupla<pEstacion, nat, nat, nat>& obtenido, const Tupla<pEstacion, nat, nat, nat>& esperado) const
{
	return SonIguales(obtenido.Dato1, esperado.Dato1) /* cuidado con posibles stack overflows */ && obtenido.Dato2 == esperado.Dato2 && obtenido.Dato3 == esperado.Dato3 && obtenido.Dato4 == esperado.Dato4;
}

Cadena CasoDePrueba::ObtenerTexto(const Tupla<pEstacion, nat, nat, nat>& t) const
{
	return ObtenerTexto(t.Dato1); /* cuidado con posibles stack overflows*/
}

bool CasoDePrueba::SonIguales(const Tupla<pEstacion, pEstacion, nat>& obtenido, const Tupla<pEstacion, pEstacion, nat>& esperado) const
{
	return SonIguales(obtenido.Dato1, esperado.Dato1) /* cuidado con posibles stack overflows */ && SonIguales(obtenido.Dato2, esperado.Dato2) /* cuidado con posibles stack overflows */ && obtenido.Dato3 == esperado.Dato3;
}

Cadena CasoDePrueba::ObtenerTexto(const Tupla<pEstacion, pEstacion, nat>& t) const
{
	return ObtenerTexto(t.Dato1); /* cuidado con posibles stack overflows*/
}

void CasoDePrueba::PruebaOKIngresoEstacion()
{
	IniciarSeccion("Ingreso Estacion");
	Puntero<ISistema> interfaz = InicializarSistema();

	InicializarEstacion(interfaz);

	CerrarSeccion();
}

void CasoDePrueba::PruebaOKIngresoLinea()
{
	IniciarSeccion("Ingreso Linea");
	Puntero<ISistema> interfaz = InicializarSistema();

	ignorarOK = true;
	InicializarEstacion(interfaz);
	ignorarOK = false;

	InicializarLinea(interfaz);

	CerrarSeccion();
}

void CasoDePrueba::PruebaOKHabilitacionTramo()
{
	IniciarSeccion("Habilitacion Tramo");
	Puntero<ISistema> interfaz = InicializarSistema();
	
	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);
	Cadena habilitar = " Se habilita el tramo {0} - {1} perteneciente a la linea {2}";
	Cadena inhabilitar = " Se inhabilita el tramo {0} - {1} perteneciente a la linea {2}";
	
	Verificar(interfaz->HabilitacionTramo(19, estaciones[22]->ObtenerNombre(), estaciones[9]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("19", estaciones[22]->ObtenerNombre(), estaciones[9]->ObtenerNombre()));
	Verificar(interfaz->HabilitacionTramo(8, estaciones[1]->ObtenerNombre(), estaciones[8]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("8", estaciones[1]->ObtenerNombre(), estaciones[8]->ObtenerNombre()));
	Verificar(interfaz->HabilitacionTramo(7, estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("7", estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre()));

	Verificar(interfaz->HabilitacionTramo(8, estaciones[1]->ObtenerNombre(), estaciones[8]->ObtenerNombre(), true), OK, habilitar.DarFormato("8", estaciones[1]->ObtenerNombre(), estaciones[8]->ObtenerNombre()));
	Verificar(interfaz->HabilitacionTramo(7, estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre(), true), OK, habilitar.DarFormato("7", estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre()));

	CerrarSeccion();
}

void CasoDePrueba::PruebaOKConsultaLinea()
{
	IniciarSeccion("Consulta Linea");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, pLinea> esperado;
	Tupla<TipoRetorno, pLinea> obtenido;
	char nroLinea[8]; 

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pLinea> lineas = ObtenerLineasDelSistema();
	Cadena texto = " Se consulta la linea {0}";
	
	obtenido = interfaz->ConsultaLinea(lineas[0]->ObtenerNroLinea());
	esperado = Tupla<TipoRetorno, pLinea>(OK, lineas[0]);
	_itoa_s(lineas[0]->ObtenerNroLinea(), nroLinea, 10);

	VerificarConsultaLinea(obtenido, esperado, texto.DarFormato(nroLinea));

	obtenido = interfaz->ConsultaLinea(lineas[3]->ObtenerNroLinea());
	esperado = Tupla<TipoRetorno, pLinea>(OK, lineas[3]);
	_itoa_s(lineas[3]->ObtenerNroLinea(), nroLinea, 10);

	VerificarConsultaLinea(obtenido, esperado, texto.DarFormato(nroLinea));

	CerrarSeccion();
}

void CasoDePrueba::PruebaOKConsultaEstacion()
{
	IniciarSeccion("Consulta Estacion");
	Puntero<ISistema> interfaz = InicializarSistema();
	Cadena comentario = "Se consulta la estación {0}";

	ignorarOK = true;
	InicializarEstacion(interfaz);
	ignorarOK = false;
	Tupla<TipoRetorno, pEstacion> esperado;
	Tupla<TipoRetorno, pEstacion> obtenido;

	//Prueba 1
	obtenido = interfaz->ConsultaEstacion("Atocha");
	esperado = Tupla<TipoRetorno, pEstacion>(OK, ObtenerEstacionesDelSistema()[0]);

	VerificarConsultaEstacion(obtenido, esperado, "Comentario");
	

	//Prueba 2
	obtenido = interfaz->ConsultaEstacion("Callao");
	esperado = Tupla<TipoRetorno, pEstacion>(OK, ObtenerEstacionesDelSistema()[4]);

	VerificarConsultaEstacion(obtenido, esperado, "Comentario");
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKListadoEstaciones()
{
	IniciarSeccion("Listado Estaciones");
	Puntero<ISistema> interfaz = InicializarSistema();

	ignorarOK = true;
	Verificar(interfaz->IngresoEstacion("Berna", 10, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Campamento", 10, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Atocha", 10, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Mirasierra", 10, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Vicálvaro", 10, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Avenida de América", 10, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Quevedo", 10, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Callao", 10, 20), OK, "");
	ignorarOK = false;


	Array<pEstacion> estaciones = Array<pEstacion>(8);
	estaciones[0] = new EstacionMock("Atocha", 10, 20);
	estaciones[1] = new EstacionMock("Avenida de América", 10, 20);
	estaciones[2] = new EstacionMock("Berna", 10, 20);
	estaciones[3] = new EstacionMock("Callao", 10, 20);
	estaciones[4] = new EstacionMock("Campamento", 10, 20);
	estaciones[5] = new EstacionMock("Mirasierra", 10, 20);
	estaciones[6] = new EstacionMock("Quevedo", 10, 20);
	estaciones[7] = new EstacionMock("Vicálvaro", 10, 20);

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	
	obtenido = interfaz->ListadoEstaciones();
	esperado = Tupla<TipoRetorno, Iterador<pEstacion>>(OK, estaciones.ObtenerIterador());

	VerificarListadoEstaciones(obtenido, esperado, "Se listan las estaciones ordenadas por nombre.");
	
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKEstacionMasLineasHabilitadas()
{
	IniciarSeccion("Estacion Mas Lineas Habilitadas");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, pEstacion> esperado;
	Tupla<TipoRetorno, pEstacion> obtenido;

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);
	Cadena masHabilitadas = " Se verifica la estacion con mas lineas habilitadas : {0}";
	char nroLinea[8]; 

	obtenido = interfaz->EstacionMasLineasHabilitadas();
	esperado = Tupla<TipoRetorno, pEstacion>(OK, estaciones[2]);

	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, masHabilitadas.DarFormato(estaciones[2]->ObtenerNombre()));

	ignorarOK = true;

	Array<Tupla<pEstacion, nat, nat, nat>> tramos;
	
	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(2);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[22], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[9], 100, 8, 30);

	Puntero<LineaMock> linea = new LineaMock(11, 20, tramos.ObtenerIterador());	
	_itoa_s(linea->ObtenerNroLinea(), nroLinea, 10);	
	Verificar(interfaz->IngresoLinea(linea->ObtenerNroLinea(), linea->ObtenerPrecio(), linea->ObtenerEstaciones().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), OK, "se da de alta la linea");

	linea = new LineaMock(12, 20, tramos.ObtenerIterador());
	_itoa_s(linea->ObtenerNroLinea(), nroLinea, 10);	
	Verificar(interfaz->IngresoLinea(linea->ObtenerNroLinea(), linea->ObtenerPrecio(), linea->ObtenerEstaciones().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), OK, "se da de alta la linea");

	linea = new LineaMock(13, 20, tramos.ObtenerIterador());
	_itoa_s(linea->ObtenerNroLinea(), nroLinea, 10);	
	Verificar(interfaz->IngresoLinea(linea->ObtenerNroLinea(), linea->ObtenerPrecio(), linea->ObtenerEstaciones().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), OK, "se da de alta la linea");

	linea = new LineaMock(14, 20, tramos.ObtenerIterador());
	_itoa_s(linea->ObtenerNroLinea(), nroLinea, 10);	
	Verificar(interfaz->IngresoLinea(linea->ObtenerNroLinea(), linea->ObtenerPrecio(), linea->ObtenerEstaciones().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), OK, "se da de alta la linea");

	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[11], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[17], 100, 8, 30);

	linea = new LineaMock(15, 20, tramos.ObtenerIterador());	
	_itoa_s(linea->ObtenerNroLinea(), nroLinea, 10);	
	Verificar(interfaz->IngresoLinea(linea->ObtenerNroLinea(), linea->ObtenerPrecio(), linea->ObtenerEstaciones().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), OK, "se da de alta la linea");

	ignorarOK = false;

	obtenido = interfaz->EstacionMasLineasHabilitadas();
	esperado = Tupla<TipoRetorno, pEstacion>(OK, estaciones[22]);
	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, masHabilitadas.DarFormato(estaciones[22]->ObtenerNombre()));

	Cadena habilitar = " Se habilita el tramo {0} - {1} perteneciente a la linea {2}";
	Cadena inhabilitar = " Se inhabilita el tramo {0} - {1} perteneciente a la linea {2}";
	
	Verificar(interfaz->HabilitacionTramo(19, estaciones[22]->ObtenerNombre(), estaciones[9]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("19", estaciones[22]->ObtenerNombre(), estaciones[9]->ObtenerNombre()));
	Verificar(interfaz->HabilitacionTramo(8, estaciones[1]->ObtenerNombre(), estaciones[8]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("8", estaciones[1]->ObtenerNombre(), estaciones[8]->ObtenerNombre()));

	obtenido = interfaz->EstacionMasLineasHabilitadas();
	esperado = Tupla<TipoRetorno, pEstacion>(OK, estaciones[11]);
	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, masHabilitadas.DarFormato(estaciones[11]->ObtenerNombre()));

	Verificar(interfaz->HabilitacionTramo(7, estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("7", estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre()));

	obtenido = interfaz->EstacionMasLineasHabilitadas();
	esperado = Tupla<TipoRetorno, pEstacion>(OK, estaciones[22]);
	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, masHabilitadas.DarFormato(estaciones[22]->ObtenerNombre()));

	Verificar(interfaz->HabilitacionTramo(7, estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre(), true), OK, habilitar.DarFormato("7", estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre()));

	obtenido = interfaz->EstacionMasLineasHabilitadas();
	esperado = Tupla<TipoRetorno, pEstacion>(OK, estaciones[11]);
	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, masHabilitadas.DarFormato(estaciones[22]->ObtenerNombre()));

	Verificar(interfaz->HabilitacionTramo(19, estaciones[22]->ObtenerNombre(), estaciones[9]->ObtenerNombre(), true), OK, habilitar.DarFormato("19", estaciones[22]->ObtenerNombre(), estaciones[9]->ObtenerNombre()));

	obtenido = interfaz->EstacionMasLineasHabilitadas();
	esperado = Tupla<TipoRetorno, pEstacion>(OK, estaciones[22]);
	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, masHabilitadas.DarFormato(estaciones[22]->ObtenerNombre()));

	CerrarSeccion();
}

void CasoDePrueba::PruebaOKListadoEstacionesHorario()
{
	IniciarSeccion("Listado Estaciones Horario");
	Puntero<ISistema> interfaz = InicializarSistema();

	ignorarOK = true;
	Verificar(interfaz->IngresoEstacion("Berna", 1, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Campamento", 5, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Atocha", 3, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Mirasierra", 14, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Vicálvaro", 14, 21), OK, "");
	Verificar(interfaz->IngresoEstacion("Avenida de América", 2, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Quevedo", 15, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Callao", 20, 23), OK, "");
	ignorarOK = false;

	//Se espera que a igual hora de apertura se ordene por nombre
	Array<pEstacion> estaciones = Array<pEstacion>(8);
	estaciones[0] = new EstacionMock("Berna", 1, 20);
	estaciones[1] = new EstacionMock("Avenida de América", 2, 20);
	estaciones[2] = new EstacionMock("Atocha", 3, 20);
	estaciones[3] = new EstacionMock("Campamento", 5, 20);
	estaciones[4] = new EstacionMock("Mirasierra", 14, 20);
	estaciones[5] = new EstacionMock("Vicálvaro", 14, 21);
	estaciones[6] = new EstacionMock("Quevedo", 15, 20);
	estaciones[7] = new EstacionMock("Callao", 20, 23);

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	
	obtenido = interfaz->ListadoEstacionesHorario();
	esperado = Tupla<TipoRetorno, Iterador<pEstacion>>(OK, estaciones.ObtenerIterador());

	VerificarListadoEstacionesHorario(obtenido, esperado, "Se listan las estaciones por horario de apertura.");
	
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKTrayectoMenorDistancia()
{
	IniciarSeccion("Trayecto Menor Distancia");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	/*
	obtenido = interfaz->TrayectoMenorDistancia();
	esperado = ...

	VerificarTrayectoMenorDistancia(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKCableadoMenorDistancia()
{
	IniciarSeccion("Cableado Menor Distancia");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> esperado;
	Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> obtenido;

	/*
	obtenido = interfaz->CableadoMenorDistancia();
	esperado = ...

	VerificarCableadoMenorDistancia(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKListadoTrayecto()
{
	IniciarSeccion("Listado Trayecto");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	/*
	obtenido = interfaz->ListadoTrayecto();
	esperado = ...

	VerificarListadoTrayecto(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKListadoTodosLosTrayectos()
{
	IniciarSeccion("Listado Todos Los Trayectos");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> esperado;
	Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> obtenido;

	/*
	obtenido = interfaz->ListadoTodosLosTrayectos();
	esperado = ...

	VerificarListadoTodosLosTrayectos(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKTrayectoMenosTransbordos()
{
	IniciarSeccion("Trayecto Menos Transbordos");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	/*
	obtenido = interfaz->TrayectoMenosTransbordos();
	esperado = ...

	VerificarTrayectoMenosTransbordos(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKCantidadMaxima()
{
	IniciarSeccion("Cantidad Maxima");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, nat> esperado;
	Tupla<TipoRetorno, nat> obtenido;

	/*
	obtenido = interfaz->CantidadMaxima();
	esperado = ...

	VerificarCantidadMaxima(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKLineasAAbordarA()
{
	IniciarSeccion("Lineas AAbordar A");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, nat, Iterador<pLinea>> esperado;
	Tupla<TipoRetorno, nat, Iterador<pLinea>> obtenido;

	/*
	obtenido = interfaz->LineasAAbordarA();
	esperado = ...

	VerificarLineasAAbordarA(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKLineasAAbordarB()
{
	IniciarSeccion("Lineas AAbordar B");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, nat, Iterador<pLinea>> esperado;
	Tupla<TipoRetorno, nat, Iterador<pLinea>> obtenido;

	/*
	obtenido = interfaz->LineasAAbordarB();
	esperado = ...

	VerificarLineasAAbordarB(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKEstacionesCriticas()
{
	IniciarSeccion("Estaciones Criticas");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	/*
	obtenido = interfaz->EstacionesCriticas();
	esperado = ...

	VerificarEstacionesCriticas(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORIngresoEstacion()
{
	IniciarSeccion("Ingreso Estacion", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema();
	Cadena ingreso = " Se ingresa la estacion {0}";

	foreach (estacion, estaciones)
		interfaz->IngresoEstacion(estacion->ObtenerNombre(), estacion->ObtenerHAbre(), estacion->ObtenerHCierra());


	Verificar(interfaz->IngresoEstacion("Atocha",1,24), ERROR, "La estación \"Atocha\" ya existe");
	Verificar(interfaz->IngresoEstacion("Carlos",1,24), ERROR, "El sistema esta lleno, no se pueden agregar mas");
	Verificar(interfaz->IngresoEstacion("Estacion trucha",10,5), ERROR, "HAbre > HCierra");
	Verificar(interfaz->IngresoEstacion("Estacion trucha",1,27), ERROR, "HAbre > 24");



	CerrarSeccion();
}



void CasoDePrueba::PruebaERRORIngresoLinea()
{
	IniciarSeccion("Ingreso Linea", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	ignorarOK = true;
	InicializarEstacion(interfaz);
	ignorarOK = false;
	Array<Tupla<Cadena,nat,nat,nat>> arr = Array<Tupla<Cadena,nat,nat,nat>>(3);
	Tupla<Cadena,nat,nat,nat> tuplita;
	tuplita.AsignarDato1("Atocha");tuplita.AsignarDato2(0);tuplita.AsignarDato3(0);tuplita.AsignarDato4(0);
	arr[0]=tuplita;
	tuplita.AsignarDato1("Estacion trucha");tuplita.AsignarDato2(4);tuplita.AsignarDato3(4);tuplita.AsignarDato4(4);
	arr[1]=tuplita;
	tuplita.AsignarDato1("Bilbao");tuplita.AsignarDato2(4);tuplita.AsignarDato3(4);tuplita.AsignarDato4(4);
	arr[2]=tuplita;
	Verificar(interfaz->IngresoLinea(1,10,arr.ObtenerIterador()),ERROR, " La estacion \"Estacion trucha\" no existe ");


	tuplita.AsignarDato1("Atocha");tuplita.AsignarDato2(0);tuplita.AsignarDato3(0);tuplita.AsignarDato4(0);
	arr[0]=tuplita;
	tuplita.AsignarDato1("Jarama");tuplita.AsignarDato2(4);tuplita.AsignarDato3(4);tuplita.AsignarDato4(4);
	arr[1]=tuplita;
	tuplita.AsignarDato1("Bilbao");tuplita.AsignarDato2(0);tuplita.AsignarDato3(4);tuplita.AsignarDato4(4);
	arr[2]=tuplita;
	Verificar(interfaz->IngresoLinea(1,10,arr.ObtenerIterador()),ERROR, "Entre \"Jarama\" y \"Bilbao\" hay distancia 0");

	tuplita.AsignarDato1("Atocha");tuplita.AsignarDato2(0);tuplita.AsignarDato3(0);tuplita.AsignarDato4(0);
	arr[0]=tuplita;
	tuplita.AsignarDato1("Jarama");tuplita.AsignarDato2(4);tuplita.AsignarDato3(4);tuplita.AsignarDato4(4);
	arr[1]=tuplita;
	tuplita.AsignarDato1("Bilbao");tuplita.AsignarDato2(16);tuplita.AsignarDato3(4);tuplita.AsignarDato4(4);
	arr[2]=tuplita;
	Verificar(interfaz->IngresoLinea(0,10,arr.ObtenerIterador()),ERROR, "nroLinea fuera de rango");

	tuplita.AsignarDato1("Atocha");tuplita.AsignarDato2(0);tuplita.AsignarDato3(0);tuplita.AsignarDato4(0);
	arr[0]=tuplita;
	tuplita.AsignarDato1("Jarama");tuplita.AsignarDato2(4);tuplita.AsignarDato3(4);tuplita.AsignarDato4(4);
	arr[1]=tuplita;
	tuplita.AsignarDato1("Bilbao");tuplita.AsignarDato2(16);tuplita.AsignarDato3(4);tuplita.AsignarDato4(4);
	arr[2]=tuplita;
	Verificar(interfaz->IngresoLinea(1654654,10,arr.ObtenerIterador()),ERROR, "nroLinea fuera de rango");

	//InicializarLinea(interfaz);

//	Tupla<TipoRetorno,pEstacion> tuplita = interfaz->ConsultaEstacion("Atocha");

	//Hacer Errores sobre las estructuras chicas

	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORHabilitacionTramo()
{
	IniciarSeccion("Habilitacion Tramo", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Verificar(interfaz->HabilitacionTramo(57770, "Atocha","Bilbao", true), ERROR, "El nroLinea no existe");
	Verificar(interfaz->HabilitacionTramo(8, "Estacion trucha","Bilbao", true), ERROR, "La EOrigen no existe");
	Verificar(interfaz->HabilitacionTramo(8, "Atocha","Estacion trucha", true), ERROR, "La EDestino no existe");

	//Verificar(interfaz->HabilitacionTramo(18, "Atocha","Bilbao", true), ERROR, "Comentario");
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORConsultaLinea()
{
	IniciarSeccion("Consulta Linea", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	ignorarOK=true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK=false;

	Array<pLinea> arrLineas = ObtenerLineasDelSistema();
	pLinea linea = new LineaMock(0,50,arrLineas[0]->ObtenerEstaciones());
	Tupla<TipoRetorno, pLinea> esperado = Tupla<TipoRetorno, pLinea>(ERROR,NULL);
	Tupla<TipoRetorno, pLinea> obtenido = interfaz->ConsultaLinea(0);
	VerificarConsultaLinea(obtenido, esperado, "El nroLinea=0 no existe");


	linea = new LineaMock(100,50,arrLineas[0]->ObtenerEstaciones());
	esperado = Tupla<TipoRetorno, pLinea>(ERROR,NULL);
	obtenido = interfaz->ConsultaLinea(100);
	VerificarConsultaLinea(obtenido, esperado, "El nroLinea=0 no existe");
	/*foreach(linea,arrLineas){
		
	}
	*/

	/*
	obtenido = interfaz->ConsultaLinea();
	esperado = ...

	
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORConsultaEstacion()
{
	IniciarSeccion("Consulta Estacion", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, pEstacion> esperado = Tupla<TipoRetorno, pEstacion> (ERROR, NULL);
	Tupla<TipoRetorno, pEstacion> obtenido = interfaz->ConsultaEstacion("Estacion trucha");


	VerificarConsultaEstacion(obtenido, esperado, "\"Estacion trucha\" no existe");

	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORListadoEstaciones()
{
	IniciarSeccion("Listado Estaciones", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado = Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR,NULL) ;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido = interfaz->ListadoEstaciones();

	/*
	obtenido = interfaz->ListadoEstaciones();
	esperado = ...
	*/
	VerificarListadoEstaciones(obtenido, esperado, "No hay estaciones en el sistema");
	
	CerrarSeccion();
}

void CasoDePrueba::PruebaERROREstacionMasLineasHabilitadas()
{
	IniciarSeccion("Estacion Mas Lineas Habilitadas", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();
	 
	ignorarOK=true;
	InicializarEstacion(interfaz);
	ignorarOK=false;
	Tupla<TipoRetorno, pEstacion> esperado = Tupla<TipoRetorno, pEstacion>(ERROR, NULL);
	Tupla<TipoRetorno, pEstacion> obtenido = interfaz->EstacionMasLineasHabilitadas();
	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, "No hay lineas en el sistema");


	interfaz = InicializarSistema();
	esperado = Tupla<TipoRetorno, pEstacion>(ERROR, NULL);
	obtenido = interfaz->EstacionMasLineasHabilitadas();
	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, "No hay ni estaciones ni lineas en el sistema");
	/*
	obtenido = interfaz->EstacionMasLineasHabilitadas();
	esperado = ...
	*/
	
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORListadoEstacionesHorario()
{
	IniciarSeccion("Listado Estaciones Horario", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	/*
	obtenido = interfaz->ListadoEstacionesHorario();
	esperado = ...

	VerificarListadoEstacionesHorario(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORTrayectoMenorDistancia()
{
	IniciarSeccion("Trayecto Menor Distancia", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	/*
	obtenido = interfaz->TrayectoMenorDistancia();
	esperado = ...

	VerificarTrayectoMenorDistancia(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORCableadoMenorDistancia()
{
	IniciarSeccion("Cableado Menor Distancia", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> esperado;
	Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> obtenido;

	/*
	obtenido = interfaz->CableadoMenorDistancia();
	esperado = ...

	VerificarCableadoMenorDistancia(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORListadoTrayecto()
{
	IniciarSeccion("Listado Trayecto", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	/*
	obtenido = interfaz->ListadoTrayecto();
	esperado = ...

	VerificarListadoTrayecto(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORListadoTodosLosTrayectos()
{
	IniciarSeccion("Listado Todos Los Trayectos", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> esperado;
	Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> obtenido;

	/*
	obtenido = interfaz->ListadoTodosLosTrayectos();
	esperado = ...

	VerificarListadoTodosLosTrayectos(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORTrayectoMenosTransbordos()
{
	IniciarSeccion("Trayecto Menos Transbordos", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	/*
	obtenido = interfaz->TrayectoMenosTransbordos();
	esperado = ...

	VerificarTrayectoMenosTransbordos(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORCantidadMaxima()
{
	IniciarSeccion("Cantidad Maxima", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, nat> esperado;
	Tupla<TipoRetorno, nat> obtenido;

	/*
	obtenido = interfaz->CantidadMaxima();
	esperado = ...

	VerificarCantidadMaxima(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORLineasAAbordarA()
{
	IniciarSeccion("Lineas AAbordar A", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, nat, Iterador<pLinea>> esperado;
	Tupla<TipoRetorno, nat, Iterador<pLinea>> obtenido;

	/*
	obtenido = interfaz->LineasAAbordarA();
	esperado = ...

	VerificarLineasAAbordarA(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORLineasAAbordarB()
{
	IniciarSeccion("Lineas AAbordar B", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, nat, Iterador<pLinea>> esperado;
	Tupla<TipoRetorno, nat, Iterador<pLinea>> obtenido;

	/*
	obtenido = interfaz->LineasAAbordarB();
	esperado = ...

	VerificarLineasAAbordarB(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaERROREstacionesCriticas()
{
	IniciarSeccion("Estaciones Criticas", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	/*
	obtenido = interfaz->EstacionesCriticas();
	esperado = ...

	VerificarEstacionesCriticas(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}
