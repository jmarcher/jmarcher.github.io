﻿#pragma once

#include "Puntero.h"
#include "Cadena.h"

class IEstacion abstract
{
public:
	virtual ~IEstacion(){}

	virtual Cadena ObtenerNombre() const abstract;
	virtual nat ObtenerHAbre() const abstract;
	virtual nat ObtenerHCierra() const abstract;

	virtual bool operator==(const IEstacion& e) const abstract;
};
typedef Puntero<IEstacion> pEstacion;