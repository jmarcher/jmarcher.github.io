#ifndef GRAFOIMP_CPP
#define GRAFOIMP_CPP
#define INFINITO 99999

#include "GrafoImp.h"
#include "ComparadorArcoGrafoEstaciones.h"
#include "ListaOrdenada.h"
#include <iostream>
#include "FuncionHashEstacion.h"
#include "ComparadorEstaciones.h"
#include "Linea.h"
using namespace std;


template<class V, class A>
GrafoImp<V,A>::GrafoImp(nat maxVertices, const Puntero<Comparador<V>>& compVertices,const Puntero<Comparador<A>>& compArcos)
{
	this->nodoMasAdy.cantAdyacentes = -1;
	this->cardinal = 0;
	this->cantMaxVertices =  maxVertices;
	this->aArcos = Matriz<Puntero<AVL<pArco>>>(cantMaxVertices);
	this->aVertices = Array<nodoVert<V>>(cantMaxVertices);
	this->thVertices = new TablaHash<nodoVert<V>>(new FuncionHashNodoGrafo(), new ComparadorVertices(), cantMaxVertices);

	this->aCompVertice = compVertices;
	this->aCompArco = compArcos;

	Puntero<ComparadorNodoGrafo> ngComp =  new ComparadorNodoGrafo();

	for(nat i=0;i<cantMaxVertices;i++)
	{
		for(nat j=0;j<cantMaxVertices;j++)
		{
			this->aArcos[i][j] = new AVL<pArco>(ngComp);
		};
	};
};

template<class V, class A>
bool GrafoImp<V,A>::estaLleno() const
{ 
	return cardinal == cantMaxVertices; 
};

template<class V, class A>
void GrafoImp<V,A>::InsertarVertice(const V& v)
{
	if(!pertenece(v)){
		if(!estaLleno()){
			nodoVert<V> nV;
			nV.vertice = v;
			nV.cantAdyacentes = 0;
			nV.habilitado = true;
			nV.nombreInterno = this->cardinal;
			if(this->nodoMasAdy.cantAdyacentes == -1)
			{
				this->nodoMasAdy = nV;
			};
			this->aVertices[this->cardinal]=nV;
			this->thVertices->insertar(nV);
			this->cardinal++;
		};

	};
};



template<class V, class A>
void GrafoImp<V,A>::InsertarArco(const V& o, const V& d, A arco)
{


	//si ya existe el arco, lo actualiza.
	if(pertenece(o) && pertenece(d) && estaHabilitado(o) && estaHabilitado(d))

	{
		nat origen = nombreInterno(o);
		nat destino = nombreInterno(d);
		pArco nA = new nodoArco<A>();
		nA->arco = arco;
		nA->habilitado = true;
		this->aVertices[origen].cantAdyacentes ++;


		if(this->aVertices[origen].cantAdyacentes > this->nodoMasAdy.cantAdyacentes 
			|| ( (this->aVertices[origen].cantAdyacentes == this->nodoMasAdy.cantAdyacentes)

			&& aCompVertice->EsMenor(this->aVertices[origen].vertice, this->nodoMasAdy.vertice) ) )
		{
			this->nodoMasAdy = this->aVertices[origen];
		};
		if(this->aArcos[origen][destino]==NULL)
		{//Si esta null creamos un nuevo arbol
			//TODO *** NO SE COMO SE TRATA EN OTRAS OPERACIONES
		};

		this->aArcos[origen][destino]->insertar(nA);
	};
};

template<class V, class A>
bool GrafoImp<V,A>::EliminarArco(const V& o, const V& d, const A& a)
{
	assert(false);
	//SIN IMPLEMENTAR
	return false;
};


template<class V, class A>
bool GrafoImp<V,A>::EliminarVertice(const V& v)
{
	assert(false);
	//SIN IMPLEMENTAR
	return false;
};

template<class V, class A>
bool GrafoImp<V,A>::HabilitarArco(const V& o, const V& d, const A& a)
{
	if(pertenece(o) && pertenece(d))
	{
		nat origen  = nombreInterno(o);
		nat destino = nombreInterno(d);
		if(!this->aArcos[origen][destino]->esVacio())
		{

			pArco pA = this->aArcos[origen][destino]->getDato(new nodoArco<A>(a));
			if(!pA->habilitado)
			{
				this->aVertices[origen].cantAdyacentes++;

				if(this->aVertices[origen].cantAdyacentes > this->nodoMasAdy.cantAdyacentes 
					|| ( (this->aVertices[origen].cantAdyacentes == this->nodoMasAdy.cantAdyacentes)

					&& aCompVertice->EsMenor(this->aVertices[origen].vertice, this->nodoMasAdy.vertice) ) )
				{
					this->nodoMasAdy = this->aVertices[origen];
				};
			}
			pA->habilitado=true;
			return true;
		}
		return false;
	}
	return false;
};

template<class V, class A>
void GrafoImp<V,A>::maxAdy(){
	nodoVert<V> nV = this->aVertices[0];
	for(nat i=1;i<this->cantMaxVertices;i++)
	{
		if(this->aVertices[i].cantAdyacentes > nV.cantAdyacentes
			|| ( (this->aVertices[i].cantAdyacentes == nV.cantAdyacentes) 
			&& aCompVertice->EsMenor(this->aVertices[i].vertice, nV.vertice) )
			)
		{
			nV = this->aVertices[i];
		};
	};

	this->nodoMasAdy = nV;
};

template<class V, class A>
bool GrafoImp<V,A>::DeshabilitarArco(const V& o, const V& d, const A& a)
{
	if(pertenece(o) && pertenece(d))
	{
		nat origen = nombreInterno(o);
		nat destino = nombreInterno(d);
		if(!this->aArcos[origen][destino]->esVacio())
		{


			pArco pA = this->aArcos[origen][destino]->getDato(new nodoArco<A>(a));
			if(pA->habilitado)
			{
				this->aVertices[origen].cantAdyacentes--;
				if(aCompVertice->SonIguales(this->aVertices[origen].vertice, this->nodoMasAdy.vertice))
				{//Se le rest� un al m�ximo hay que buscar un nuevo m�ximo si lo hay, sino queda todo igual
					maxAdy();
				};
			}
			pA->habilitado=false;
			return true;
		}
		return false;
	}
	return false;
};

template<class V, class A>
bool GrafoImp<V,A>::HabilitarVertice(const V& v)
{
	if(pertenece(v))
	{
		nat indice = nombreInterno(v);
		this->aVertices[indice].habilitado=true;
		return true;
	};
	return false;
};

template<class V, class A>
bool GrafoImp<V,A>::DeshabilitarVertice(const V& v)
{
	if(pertenece(v))
	{
		nat indice = nombreInterno(v);
		this->aVertices[indice].habilitado=false;
		return true;
	};
	return false;
};

template<class V, class A>
bool GrafoImp<V,A>::estaHabilitado(const V& v) const
{
	nat indice = nombreInterno(v);
	return aVertices[indice].habilitado;
};

template<class V, class A>
bool GrafoImp<V,A>::estaHabilitado(const V& o, const V& d, const A& a) const
{
	nat origen = nombreInterno(o);
	nat destino = nombreInterno(d);
	pArco nA = this->aArcos[origen][destino]->getDato(new nodoArco<A>(a));

	return estaHabilitado(o) && estaHabilitado(d) && nA->habilitado;
};



template<class V, class A>
Puntero<Grafo<V,A>> GrafoImp<V,A>::clon() const
{
	//assert(false);

	Puntero<GrafoImp<V,A>> retorno = new GrafoImp<V,A>(this->cantMaxVertices, this->aCompVertice, this->aCompArco);
	for(nat i = 0 ; i< this->cantVertices(); i++)
	{
		pEstacion e = new Estacion(this->aVertices[i].vertice->ObtenerNombre(),this->aVertices[i].vertice->ObtenerHAbre(),
			this->aVertices[i].vertice->ObtenerHCierra());
		retorno->InsertarVertice(e);

		if(!this->aVertices[i].habilitado)
			retorno->DeshabilitarVertice(e);
	};
	for(nat i = 0 ; i< this->cantVertices(); i++)
	{
		for(nat j = 0 ; j< this->cantVertices(); j++)
		{
			V vo = this->aVertices[i].vertice;
			V vd = this->aVertices[j].vertice;
			Iterador <pArco> iter = this->aArcos[i][j]->ObtenerIterador();
			while(iter.HayElemento())
			{
				pArco arquito = iter.ElementoActual();
				pArco aInsertar = new nodoArco<A>();
				aInsertar->habilitado=arquito->habilitado;
				pArcoEstaciones arcoOriginal = arquito->arco;
				pArcoEstaciones arcoaInsertar = new arcoGrafoEstaciones(arcoOriginal->nroLinea,vo,vd);
				arcoaInsertar->densidad = arcoOriginal->densidad;
				arcoaInsertar->destino = arcoOriginal->destino;
				arcoaInsertar->distancia= arcoOriginal->distancia;
				arcoaInsertar->nroLinea = arcoOriginal->nroLinea;
				arcoaInsertar->origen = arcoOriginal->origen;
				arcoaInsertar->tiempo = arcoOriginal->tiempo;

				retorno->InsertarArco(vo, vd, arcoaInsertar);
				if(!arquito->habilitado)
					retorno->DeshabilitarArco(vo, vd, arcoaInsertar);
				iter.Avanzar();
			};
			iter.Reiniciar();
		};
	};
	//SIN IMPLEMENTAR
	return retorno;
};

template<class V, class A>
Puntero<Grafo<V,A>> GrafoImp<V,A>::crearVacio() const
{
	return new GrafoImp<V,A>(cantMaxVertices, aCompVertice, aCompArco);
};

template<class V, class A>
Grafo<V,A>& GrafoImp<V,A>::operator=(const Grafo<V,A>& g)
{

	return *this;
};

template<class V, class A>
Iterador<A> GrafoImp<V,A>::arcos(const V& o, const V& d) const
{	
	Iterador <A> ret;
	if(pertenece(o) && pertenece(d))
	{
		nat origen = nombreInterno(o);
		nat destino = nombreInterno(d);
		Iterador <pArco> iter = this->aArcos[origen][destino]->ObtenerIterador();
		Array<A> arr = Array<A>( this->aArcos[origen][destino]->cardinal());
		nat i=0;
		while(iter.HayElemento())
		{
			arr[i] = iter.ElementoActual()->arco;
			iter.Avanzar();
			i++;
		};
		ret = arr.ObtenerIterador();
	};
	return ret;
};
//pre
//pos retorna un iterador sobre los arcos o-d

template<class V, class A>
Iterador<V> GrafoImp<V,A>::vertices() const
{
	Array<V> arreglo = Array<V>(cardinal);
	nat insert=0;
	for(nat i = 0; i<cardinal ; i++)
	{
		nodoVert<V> nV = this->aVertices[i];
		cout << nV.vertice->ObtenerNombre() << " -- "<< nV.cantAdyacentes <<  endl;
		if(estaHabilitado(nV.vertice)){
			arreglo[insert]=nV.vertice;
			insert++;
		}
	};
	return arreglo.ObtenerIterador();
};
//pre
//pos retorna un iterador sobre los vertices del grafo


//O tambien incidentes
template<class V, class A>
Iterador<A> GrafoImp<V,A>::adyacentes(const V& v) const
{
	Array<A> arreglo = Array<A>(cantMaxVertices*100);
	Puntero<ListaOrdenada<A>> retorno = new ListaOrdenada<A>(this->aCompArco);
	nat indice = 0;
	if(pertenece(v))
	{
		nat origen = nombreInterno(v);
		for(nat i = 0; i<this->cantVertices() ; i++)
		{
			//cout << "i: " << i << " indice2 : "<<indice<<endl;
			if(i!=origen){
				//cout << "i: " << i << " indice: "<<indice<<endl;
				Puntero<AVL<pArco>> nA = this->aArcos[origen][i];
				Iterador<pArco> iter = nA->ObtenerIterador();
				//cout << "Tama�o: "<< nA->cardinal() << endl;
				while (iter.HayElemento())
				{
					//cout << "i: " << i << " indice: "<<indice<<endl;
					pArco arcoActual = iter.ElementoActual();
					if(arcoActual->habilitado)
					{
						//arreglo[indice]=arcoActual->arco;
						retorno->agregarElemento(arcoActual->arco);
						indice++;
					}
					iter.Avanzar();
				};
				iter.Reiniciar();
			}
		};
	};
	return retorno->toArray().ObtenerIterador();
	return arreglo.ObtenerIterador();
};

template<class V, class A>
Iterador<A> GrafoImp<V,A>::incidentes(const V& v) const
{
	Array<A> arreglo = Array<A>(cantMaxVertices*100);
	Puntero<ListaOrdenada<A>> retorno = new ListaOrdenada<A>(this->aCompArco);
	nat indice = 0;
	if(pertenece(v))
	{
		nat origen = nombreInterno(v);
		for(nat i = 0; i<this->cantVertices() ; i++)
		{
			//cout << "i: " << i << " indice2 : "<<indice<<endl;
			if(i!=origen){
				//cout << "i: " << i << " indice: "<<indice<<endl;
				Puntero<AVL<pArco>> nA = this->aArcos[i][origen];
				Iterador<pArco> iter = nA->ObtenerIterador();
				//cout << "Tama�o: "<< nA->cardinal() << endl;
				while (iter.HayElemento())
				{
					//cout << "i: " << i << " indice: "<<indice<<endl;
					pArco arcoActual = iter.ElementoActual();
					if(arcoActual->habilitado)
					{
						//arreglo[indice]=arcoActual->arco;
						retorno->agregarElemento(arcoActual->arco);
						indice++;
					}
					iter.Avanzar();
				};
				iter.Reiniciar();
			}
		};
	};
	return retorno->toArray().ObtenerIterador();
};

template<class V, class A>
bool GrafoImp<V,A>::pertenece(const V& v) const
{
	nodoVert<V> nodo;
	nodo.vertice = v;
	return this->thVertices->pertenece(nodo);
};

template<class V, class A>
nat GrafoImp<V,A>::nombreInterno(const V& v) const
{
	int pos=0;
	nodoVert<V> nV;
	nV.vertice=v;
	nV = this->thVertices->getDato(nV);
	pos = nV.nombreInterno;
	return pos;
};

template<class V, class A>
const V& GrafoImp<V,A>::verticeMasAdyacentes() const
{
	/*	for(nat i=0; i<cardinal;i++)
	{
	cout << aVertices[i].vertice->ObtenerNombre() << "  ---  " << aVertices[i].cantAdyacentes << endl;
	}*/
	return this->nodoMasAdy.vertice;
};

template<class V, class A>
bool  GrafoImp<V,A>::HayMasDesconocidos(Array<nodoDijkstra> dbDij)
{
	for(nat i=0;i<dbDij.ObtenerLargo();i++)
	{
		if(dbDij[i].conocido==false)
			return true;
	};
	return false;
};

template<class V, class A>
pEstacion  GrafoImp<V,A>::ObtenerSiguienteDesconocidoDensidad(Array<nodoDijkstra> dbDij)
{
	pEstacion minimo = NULL;
	nat costoMinimo = INFINITO;
	for(nat i=0;i<dbDij.ObtenerLargo();i++)
	{
		if(dbDij[i].conocido==false)
		{
			if(costoMinimo > dbDij[i].densidad)
			{
				minimo = dbDij[i].estacion;
				costoMinimo = dbDij[i].densidad;
			};
		};
		//return dbDij[i].estacion;
	};
	return minimo;
};

template<class V, class A>
pEstacion  GrafoImp<V,A>::ObtenerSiguienteDesconocido(Array<nodoDijkstra> dbDij)
{
	pEstacion minimo = NULL;
	nat costoMinimo = INFINITO;
	for(nat i=0;i<dbDij.ObtenerLargo();i++)
	{
		if(dbDij[i].conocido==false)
		{
			if(costoMinimo > dbDij[i].distancia)
			{
				minimo = dbDij[i].estacion;
				costoMinimo = dbDij[i].distancia;
			};
		};
		//return dbDij[i].estacion;
	};
	return minimo;
};

template<class V, class A>
Iterador<pEstacion> GrafoImp<V,A>::trayectoMenordistancia(const pEstacion& o, const pEstacion& d, nat hora)
{

	Array<nodoDijkstra> dbDij = Array<nodoDijkstra>(this->cantVertices());
	//cout << "Entro alguna vez? "<<endl;
	for(nat i=0;i<this->cantVertices();i++)
	{
		dbDij[i].conocido=false;
		dbDij[i].distancia = INFINITO;
		dbDij[i].ant = NULL;
		dbDij[i].estacion = this->aVertices[i].vertice;
	};
	//cout << "Entro alguna vez? "<<endl;
	nat origen = this->nombreInterno(o);
	dbDij[origen].distancia = 0;
	dbDij[origen].conocido = true;
	pEstacion estacion = o;
	while(HayMasDesconocidos(dbDij) && estacion != NULL)
	{
		//cout << "Entro alguna vez? "<<endl;
		nat nOrigen = this->nombreInterno(estacion);
		dbDij[nOrigen].conocido=true;
		Iterador<A> adyac = adyacentes(estacion);
		while(adyac.HayElemento())
		{
			A arcoAdyacente = adyac.ElementoActual();
			if(arcoAdyacente!=NULL)
			{
				//cout << "alguna no es null"<< endl;
				if(dbDij[nOrigen].distancia+arcoAdyacente->distancia < dbDij[this->nombreInterno(arcoAdyacente->destino)].distancia

					&& (hora==114 ||  (dbDij[nOrigen].estacion->ObtenerHAbre()<=hora && dbDij[nOrigen].estacion->ObtenerHCierra()>=hora)))
				{
					dbDij[this->nombreInterno(arcoAdyacente->destino)].distancia =dbDij[nOrigen].distancia+arcoAdyacente->distancia;
					dbDij[this->nombreInterno(arcoAdyacente->destino)].ant = estacion;
				};
			};
			adyac.Avanzar();
		};
		adyac.Reiniciar();
		//cout << "no pifia antes" << endl;
		estacion = ObtenerSiguienteDesconocido(dbDij);
		//cout << "pifio?"<<endl;
	};
	bool termine = false;
	bool hayCamino = true;
	nat siguiente = this->nombreInterno(d);
	nat indice=0;
	Array<pEstacion> listEstaciones = Array<pEstacion>(this->cantVertices());

	while(!termine && hayCamino)
	{
		if(dbDij[siguiente].conocido)
		{
			pEstacion e = dbDij[siguiente].estacion;
			if((hora>=e->ObtenerHAbre() && hora<=e->ObtenerHCierra()
				|| ( siguiente == this->nombreInterno(d) || siguiente == this->nombreInterno(o))) || hora == 114)//no le da bola al horario en o y d
			{
				//cout << siguiente <<endl;
				listEstaciones[indice] = e;

				indice++;

				if(siguiente == this->nombreInterno(o))
				{
					termine=true;
				}
				if(!termine)
					siguiente = this->nombreInterno(dbDij[siguiente].ant);
			}
			else
			{
				hayCamino = false;
				termine=true;
			};
		}
		else
		{
			hayCamino=false;
			termine=true;
		};
	};


	Array<pEstacion> retorno = Array<pEstacion>(indice);
	if(hayCamino){
		nat iAux = indice-1;
		for(nat i=0;i<indice;i++)
		{
			retorno[i] = listEstaciones[iAux];
			iAux--;
		};
	};
	if(!hayCamino)
		return NULL;
	return retorno.ObtenerIterador();
};

template<class V, class A>
Tupla<Iterador<A>,nat> GrafoImp<V,A>::crearCaminoDensidad(const pEstacion& origen, const pEstacion& destino, Array<nodoDijkstra> dbDij)
{
	Puntero<ListaOrdenada<pArcoEstaciones>> camino = new ListaOrdenada<pArcoEstaciones>(new ComparadorArcoGrafoEstacionesListaMenor());
	//los va metiendo y siempre te va a quedar el camino hecho
	bool termine = false;
	bool hayCamino = true;
	nat siguiente = this->nombreInterno(destino);
	nat densidadMenor = INFINITO;


	while(!termine && hayCamino)
	{
		if(dbDij[siguiente].conocido)
		{
			pEstacion e = dbDij[siguiente].estacion;


			if(siguiente == this->nombreInterno(origen))
			{
				/*if(densidadMenor>dbDij[siguiente].arcoUsado->densidad)
				{
				densidadMenor=dbDij[siguiente].arcoUsado->densidad;
				};*/
				//camino->agregarElemento(dbDij[siguiente].arcoUsado);
				termine=true;
			}
			if(!termine && dbDij[siguiente].ant!=NULL){
				//cout << "Densidad: " << dbDij[siguiente].arcoUsado->densidad << " " << siguiente << endl;
				if(densidadMenor>dbDij[siguiente].arcoUsado->densidad)
				{

					densidadMenor=dbDij[siguiente].arcoUsado->densidad;
				};
				camino->agregarElemento(dbDij[siguiente].arcoUsado);
			}
			if(!termine)
				siguiente = this->nombreInterno(dbDij[siguiente].ant);
		}
		else
		{
			hayCamino=false;
			termine=true;
		};
	};
	return Tupla<Iterador<A>,nat>(camino->toArray().ObtenerIterador(),densidadMenor);
};


template<class V, class A>
Iterador<pEstacion> GrafoImp<V,A>::crearCamino(const pEstacion& origen, const pEstacion& destino, Array<nodoDijkstra> dbDij)
{
	Puntero<ListaOrdenada<pEstacion>> camino = new ListaOrdenada<pEstacion>(new ComparadorEstacionesListaMenor());
	//los va metiendo y siempre te va a quedar el camino hecho
	bool termine = false;
	bool hayCamino = true;
	nat siguiente = this->nombreInterno(destino);


	while(!termine && hayCamino)
	{
		if(dbDij[siguiente].conocido)
		{
			pEstacion e = dbDij[siguiente].estacion;


			if(siguiente == this->nombreInterno(origen))
			{
				camino->agregarElemento(e);
				termine=true;
			}
			if(!termine && dbDij[siguiente].ant!=NULL){
				camino->agregarElemento(e);
			}
			if(!termine)
				siguiente = this->nombreInterno(dbDij[siguiente].ant);
		}
		else
		{
			hayCamino=false;
			termine=true;
		};
	};
	return camino->toArray().ObtenerIterador();
};

template<class V, class A>
bool GrafoImp<V,A>::HayCamino(pEstacion origen, pEstacion destino)
{
	Array<nodoDijkstra> dbDij = this->dijkstra(origen);
	bool termine = false;
	bool hayCamino = true;
	nat siguiente = this->nombreInterno(destino);

	while(!termine && hayCamino)
	{
		if(dbDij[siguiente].conocido)
		{
			pEstacion e = dbDij[siguiente].estacion;


			if(siguiente == this->nombreInterno(origen))
			{
				termine=true;
			}
			if(!termine)
				siguiente = this->nombreInterno(dbDij[siguiente].ant);
		}
		else
		{
			hayCamino=false;
			termine=true;
		};
	};
	return hayCamino;
};

template<class V, class A>
Iterador<Tupla<pEstacion, pEstacion, nat>> GrafoImp<V,A>::cableadoMenorDistancia()
{
	Tupla<Matriz<A>,nat> krusky = this->kruskal();
	Array<Tupla<pEstacion, pEstacion, nat>> retorno = Array<Tupla<pEstacion, pEstacion, nat>>(krusky.ObtenerDato2());
	Matriz<A> matriz =krusky.ObtenerDato1();
	nat indice=0;
	for(nat i =0; i<this->cantVertices();i++)
	{
		for(nat j =0;j <this->cantVertices();j++)
		{

			if(matriz[i][j] != NULL)
			{
				Tupla<pEstacion, pEstacion, nat> actual;
				actual.AsignarDato1(matriz[i][j]->origen);
				actual.AsignarDato2(matriz[i][j]->destino);
				actual.AsignarDato3(matriz[i][j]->distancia);
				retorno[indice] = actual;
				indice++;
			};
		};
	};
	//cout << "Cardinal " << indice << "cosooooo " <<krusky.ObtenerDato2()<< endl;
	return retorno.ObtenerIterador();
};

template<class V, class A>
Tupla<Matriz<A>,nat> GrafoImp<V,A>::kruskal()
{
	Matriz<A> arbol = Matriz<A>(this->cantVertices());
	componente = Array<int>(this->cantVertices());
	Puntero<ListaOrdenada<A>> cp = new ListaOrdenada<A>(this->aCompArco);
	nat cardi=0;
	for(nat i = 0; i < this->cantVertices(); i++)
	{
		componente[i] = i;
	};
	nat cantARI=0;
	for(nat i=0; i<this->cantVertices(); i++)
	{
		for(nat j=0; j<this->cantVertices(); j++)
		{
			Iterador<pArco> iter = this->aArcos[i][j]->ObtenerIterador();
			cantARI = cantARI+ this->aArcos[i][j]->cardinal();
			//	cout << "I: " << i << " J: " << j << " Cardinal: " << this->aArcos[i][j]->cardinal();
			nat cardiIter=0;
			while(iter.HayElemento())
			{
				pArco pa = iter.ElementoActual();
				pa->kDelete = false;
				//cout << "Arista: O: " << nombreInterno(pa->arco->origen) << " D: " << nombreInterno(pa->arco->destino) << " C: " << pa->arco->distancia << endl;
				cp->agregarElemento(pa->arco);
				//cout << "Pertenece? " << cp->pertenece(pa->arco) << endl;
				iter.Avanzar();
				cardiIter++;

			};
			iter.Reiniciar();
		};
	};


	while(!cp->esVacia())
	{
		A arista = cp->obtenerPrimero();
		cp->eliminarPrimero();
		V vo = arista->origen;
		V vd = arista->destino;
		nat compO = componenteDe(nombreInterno(vo));
		nat compD = componenteDe(nombreInterno(vd));
		if(compO != compD)
		{
			cardi++;
			arbol[nombreInterno(vo)][nombreInterno(vd)] = arista;
			unir(compO, compD);
		};
	}

	Tupla<Matriz<A>,nat> ret;
	ret.AsignarDato1(arbol);
	ret.AsignarDato2(cardi);
	return ret;
};

template<class V, class A>
Array<nodoDijkstra> GrafoImp<V,A>::dijkstraDensidad(const pEstacion &o)
{
	Array<nodoDijkstra> dbDij = Array<nodoDijkstra>(this->cantVertices());
	//cout << "Entro alguna vez? "<<endl;
	nat MAX_DENS = 1000;
	for(nat i=0;i<this->cantVertices();i++)
	{
		dbDij[i].conocido=false;
		dbDij[i].distancia = INFINITO;
		dbDij[i].densidad = INFINITO;
		dbDij[i].ant = NULL;
		dbDij[i].arcoUsado=NULL;
		dbDij[i].estacion = this->aVertices[i].vertice;
	};
	//cout << "Entro alguna vez? "<<endl;
	nat origen = this->nombreInterno(o);
	dbDij[origen].distancia = 0;
	dbDij[origen].densidad = 0;
	dbDij[origen].conocido = true;
	pEstacion estacion = o;
	while(HayMasDesconocidos(dbDij) && estacion != NULL)
	{
		//cout << "Entro alguna vez? "<<endl;
		nat nOrigen = this->nombreInterno(estacion);
		dbDij[nOrigen].conocido=true;
		Iterador<A> adyac = adyacentes(estacion);
		while(adyac.HayElemento())
		{
			A arcoAdyacente = adyac.ElementoActual();
			if(arcoAdyacente!=NULL)
			{
				//cout << "alguna no es null"<< endl;
				if(((MAX_DENS-dbDij[nOrigen].densidad)+(MAX_DENS-arcoAdyacente->densidad)) < (MAX_DENS-dbDij[this->nombreInterno(arcoAdyacente->destino)].densidad))
				{
					dbDij[this->nombreInterno(arcoAdyacente->destino)].densidad =(MAX_DENS-dbDij[nOrigen].densidad)+(MAX_DENS-arcoAdyacente->densidad);
					dbDij[this->nombreInterno(arcoAdyacente->destino)].ant = estacion;
					dbDij[this->nombreInterno(arcoAdyacente->destino)].arcoUsado = arcoAdyacente;
				};
			};
			adyac.Avanzar();
		};
		adyac.Reiniciar();
		//cout << "no pifia antes" << endl;
		estacion = ObtenerSiguienteDesconocidoDensidad(dbDij);
		//cout << "pifio?"<<endl;
	};
	return dbDij;
};

template<class V, class A>
Array<nodoDijkstra> GrafoImp<V,A>::dijkstra(const pEstacion &o)
{

	Array<nodoDijkstra> dbDij = Array<nodoDijkstra>(this->cantVertices());
	//cout << "Entro alguna vez? "<<endl;
	for(nat i=0;i<this->cantVertices();i++)
	{
		dbDij[i].conocido=false;
		dbDij[i].distancia = INFINITO;
		dbDij[i].ant = NULL;
		dbDij[i].estacion = this->aVertices[i].vertice;
	};
	//cout << "Entro alguna vez? "<<endl;
	nat origen = this->nombreInterno(o);
	dbDij[origen].distancia = 0;
	dbDij[origen].conocido = true;
	pEstacion estacion = o;
	while(HayMasDesconocidos(dbDij) && estacion != NULL)
	{
		//cout << "Entro alguna vez? "<<endl;
		nat nOrigen = this->nombreInterno(estacion);
		dbDij[nOrigen].conocido=true;
		Iterador<A> adyac = adyacentes(estacion);
		while(adyac.HayElemento())
		{
			A arcoAdyacente = adyac.ElementoActual();
			if(arcoAdyacente!=NULL)
			{
				//cout << "alguna no es null"<< endl;
				if(dbDij[nOrigen].distancia+arcoAdyacente->distancia < dbDij[this->nombreInterno(arcoAdyacente->destino)].distancia)
				{
					dbDij[this->nombreInterno(arcoAdyacente->destino)].distancia =dbDij[nOrigen].distancia+arcoAdyacente->distancia;
					dbDij[this->nombreInterno(arcoAdyacente->destino)].ant = estacion;
				};
			};
			adyac.Avanzar();
		};
		adyac.Reiniciar();
		//cout << "no pifia antes" << endl;
		estacion = ObtenerSiguienteDesconocido(dbDij);
		//cout << "pifio?"<<endl;
	};
	return dbDij;
};

template<class V, class A>
Iterador<pEstacion> GrafoImp<V,A>::estacionesCriticas(const pEstacion& o, const pEstacion& d )
{

	Array<nodoDijkstra> dbDij = Array<nodoDijkstra>(this->cantVertices());
	Array<pEstacion> retorno = Array<pEstacion>(this->cantVertices());
	nat indice=0;
	//cout << "Entro alguna vez? "<<endl;
	for(nat aDeshabilitar=0; aDeshabilitar<this->cantVertices(); aDeshabilitar++)
	{
		if(aDeshabilitar != this->nombreInterno(o) && aDeshabilitar!=this->nombreInterno(d))
		{
			for(nat i=0;i<this->cantVertices();i++)
			{
				dbDij[i].conocido=false;
				dbDij[i].distancia = INFINITO;
				if(aDeshabilitar==i){
					dbDij[i].conocido=true;
					dbDij[i].distancia = 0;
				}
				dbDij[i].ant = NULL;
				dbDij[i].estacion = this->aVertices[i].vertice;
			};
			//cout << "Entro alguna vez? "<<endl;
			nat origen = this->nombreInterno(o);
			dbDij[origen].distancia = 0;
			dbDij[origen].conocido = true;
			pEstacion estacion = o;
			while(HayMasDesconocidos(dbDij) && estacion != NULL)
			{
				//cout << "Entro alguna vez? "<<endl;
				nat nOrigen = this->nombreInterno(estacion);
				dbDij[nOrigen].conocido=true;
				Iterador<A> adyac = adyacentes(estacion);
				while(adyac.HayElemento())
				{
					A arcoAdyacente = adyac.ElementoActual();
					if(arcoAdyacente!=NULL)
					{
						//cout << "alguna no es null"<< endl;
						if(dbDij[nOrigen].distancia+arcoAdyacente->distancia < dbDij[this->nombreInterno(arcoAdyacente->destino)].distancia)
						{
							dbDij[this->nombreInterno(arcoAdyacente->destino)].distancia =dbDij[nOrigen].distancia+arcoAdyacente->distancia;
							dbDij[this->nombreInterno(arcoAdyacente->destino)].ant = estacion;
						};
					};
					adyac.Avanzar();
				};
				adyac.Reiniciar();
				//cout << "no pifia antes" << endl;
				estacion = ObtenerSiguienteDesconocido(dbDij);
				//cout << "pifio?"<<endl;
			};

			/*for(nat i = 0; i<this->cantVertices(); i++)
			{
			//<< ", "<<
			cout << i << ", "<< dbDij[i].conocido << ", "<< dbDij[i].distancia << ", ";
			if(dbDij[i].ant==NULL)
			cout << "NULL";
			else
			cout << nombreInterno(dbDij[i].ant);
			cout << endl;
			};*/

			/***********/
			//Ver si hay camino al final
			bool termine = false;
			bool hayCamino = true;
			nat siguiente = this->nombreInterno(d);
			Array<pEstacion> listEstaciones = Array<pEstacion>(this->cantVertices());

			while(!termine && hayCamino)
			{
				if(dbDij[siguiente].conocido)
				{
					if(siguiente == this->nombreInterno(o))
					{
						termine=true;
					}
					if(siguiente != this->nombreInterno(o) && dbDij[siguiente].ant==NULL)
					{
						termine=true;
						hayCamino=false;
					}
					if(!termine){
						siguiente = this->nombreInterno(dbDij[siguiente].ant);
					}

				}
				else
				{
					//cout << "Estoy aca" << endl;
					hayCamino=false;
					termine=true;
				};
			};
			//si no hay camino es una estacion critica
			if(!hayCamino)
			{
				retorno[indice]=this->aVertices[aDeshabilitar].vertice;
				indice++;
			};
		};
	};
	nat cantNotNull=0;
	for(nat i = 0; i<this->cantVertices(); i++)
	{
		if(retorno[i]!=NULL)
			cantNotNull++;
	};
	Array<pEstacion> nuevoRetorno(cantNotNull);
	for(nat i=0;i<cantNotNull;i++)
	{
		nuevoRetorno[i]=retorno[i];
	};
	return nuevoRetorno.ObtenerIterador();
};


template<class V, class A>
GrafoImp<V,A>::~GrafoImp(void)
{
};

template<class V, class A>
bool GrafoImp<V,A>::perteneceCamino(Array<Iterador<pEstacion>> caminos, Iterador<pEstacion> camino)
{
	//assert(false);
	return camino==NULL;
	bool retorno = false;
	for(nat i=0; i<caminos.ObtenerLargo(); i++)
	{
		if(caminos[i]!=NULL)
		{
			bool sonIguales = true;
			//	cout << endl << "Camino "<< i<< endl;
			while(camino.HayElemento())
			{
				//	cout << caminos[i].ElementoActual()->ObtenerNombre() << " --- " << camino.ElementoActual()->ObtenerNombre() << endl;
				if(caminos[i].ElementoActual() != camino.ElementoActual())
					sonIguales = false;
				caminos[i].Avanzar();
				camino.Avanzar();
			};
			if(caminos[i].HayElemento())
				sonIguales=false;
			camino.Reiniciar();
			caminos[i].Reiniciar();
			if(sonIguales)
				retorno = true;
		};
	};
	return retorno;
};

template<class V, class A>
void GrafoImp<V,A>::trayectoMenosTrasbordos(const pEstacion& origenActual, const pEstacion& destino, 
		Puntero<ListaOrdenada<pEstacion>> lstActual, Puntero<ListaOrdenada<tListaEstaciones>> lstSolucion,
		int cantLineasActuales,Puntero<int> mejorCantLineas, int distanciaActual, Puntero<int> mejorDistancia, int lineaActual)
{
	if(this->aCompVertice->SonIguales(origenActual,destino))
	{
		this->aVertices[nombreInterno(destino)].conocido=true;
		lstActual->agregarElemento(origenActual);

		Puntero<ListaOrdenada<pEstacion>> laux = lstActual->clone();
		
		if(cantLineasActuales<mejorCantLineasAt)
		{
			lstSolucion->eliminarPrimero();
			lstSolucion->agregarElemento(laux);
			mejorCantLineasAt = (cantLineasActuales);
			mejorDistanciaAt =  (distanciaActual);
		}else if(cantLineasActuales == mejorCantLineasAt && distanciaActual < mejorDistanciaAt){
			lstSolucion->eliminarPrimero();
			lstSolucion->agregarElemento(laux);
			mejorCantLineasAt = (cantLineasActuales);
			mejorDistanciaAt =  (distanciaActual);

		}
		lstActual->eliminar(origenActual);

		return;
	};
	if(this->aVertices[nombreInterno(origenActual)].conocido)
		return;
	this->aVertices[nombreInterno(origenActual)].conocido=true;
	lstActual->agregarElemento(origenActual);
	Iterador<A> iter = this->adyacentes(origenActual);
	while(iter.HayElemento())
	{
		if(iter.ElementoActual()!=NULL){
			int lineasActualesAsumar=0;
			if(iter.ElementoActual()->nroLinea!=lineaActual)
			{
				lineasActualesAsumar++;
			};
			//pLineaMia paDist = new Linea(iter.ElementoActual());
			this->trayectoMenosTrasbordos(iter.ElementoActual()->destino, destino,lstActual,lstSolucion,
				cantLineasActuales+lineasActualesAsumar, mejorCantLineas, distanciaActual+iter.ElementoActual()->distancia,mejorDistancia, iter.ElementoActual()->nroLinea);
		}
		iter.Avanzar();
	};
	iter.Reiniciar();
	lstActual->eliminar(origenActual);
	this->aVertices[nombreInterno(origenActual)].conocido=false;
};


template<class V, class A>
void GrafoImp<V,A>::todosTrayectos(const pEstacion& origenActual, const pEstacion& destino, Puntero<ListaOrdenada<pEstacion>> lstActual, Puntero<ListaOrdenada<tListaEstaciones>> lstSolucion)
{
	if(this->aCompVertice->SonIguales(origenActual,destino))
	{
		this->aVertices[nombreInterno(destino)].conocido=true;
		lstActual->agregarElemento(origenActual);

		tListaEstaciones laux = lstActual->clone();
		if(!lstSolucion->pertenece(laux))
			lstSolucion->agregarElemento(laux);
		lstActual->eliminar(origenActual);

		return;
	};
	if(this->aVertices[nombreInterno(origenActual)].conocido)
		return;
	this->aVertices[nombreInterno(origenActual)].conocido=true;
	lstActual->agregarElemento(origenActual);
	Iterador<A> iter = this->adyacentes(origenActual);
	while(iter.HayElemento())
	{
		if(iter.ElementoActual()!=NULL)
			this->todosTrayectos(iter.ElementoActual()->destino, destino,lstActual,lstSolucion);
		iter.Avanzar();
	};
	iter.Reiniciar();
	lstActual->eliminar(origenActual);
	this->aVertices[nombreInterno(origenActual)].conocido=false;
};

template<class V, class A>
Iterador<Iterador<pEstacion>> GrafoImp<V,A>::todosLosTrayectos(const pEstacion& origen, const pEstacion& destino)
{
	Puntero<ListaOrdenada<pEstacion>> listAux = new ListaOrdenada<pEstacion>(new ComparadorEstacionesLista());
	Puntero<ListaOrdenada<tListaEstaciones>> solucion = new ListaOrdenada<tListaEstaciones>(new ComparadorListaOrdenada());
	for(nat i=0;i<this->cardinal;i++)
	{
		this->aVertices[i].conocido=false;
	};
	this->todosTrayectos(origen,destino,listAux,solucion);
	Array<tListaEstaciones> solArray = solucion->toArray();
	Array<Iterador<pEstacion>> solMatriz(solArray.ObtenerLargo());

	for(nat i=0;i<solArray.ObtenerLargo();i++)
	{
		solMatriz[i] = solArray[i]->toArray().ObtenerIterador();
	};
	Iterador<Iterador<pEstacion>> retornito = solMatriz.ObtenerIterador();
	/*while(retornito.HayElemento()){
	Iterador<pEstacion> iter = retornito.ElementoActual().Clonar();
	while(iter.HayElemento())
	{
	cout <<  " [" << nombreInterno(iter.ElementoActual()) <<"] ->";
	iter.Avanzar();
	};
	iter.Reiniciar();
	retornito.Avanzar();
	cout << endl << endl;
	};
	retornito.Reiniciar();*/

	return retornito;
};
template<class V, class A>
Iterador<pEstacion> GrafoImp<V,A>::trayectoMenosTrasbordosRetorno(const pEstacion& origen, const pEstacion& destino)
{
	Puntero<ListaOrdenada<pEstacion>> listAux = new ListaOrdenada<pEstacion>(new ComparadorEstacionesLista());
	Puntero<ListaOrdenada<tListaEstaciones>> solucion = new ListaOrdenada<tListaEstaciones>(new ComparadorListaOrdenada());
	for(nat i=0;i<this->cardinal;i++)
	{
		this->aVertices[i].conocido=false;
	};

	Puntero<int> mejorCantLineas =  new int(99999);
	Puntero<int> mejorDistancia = new int(99999);
	mejorCantLineasAt = 999999;
	mejorDistanciaAt = 999999;
	this->trayectoMenosTrasbordos(origen,destino,listAux,solucion, 0, mejorCantLineas, 0,mejorDistancia,99999);


	return solucion->obtenerPrimero()->toArray().ObtenerIterador();
};

template<class V, class A>
Iterador<pEstacion> GrafoImp<V,A>::trayectoMenorTiempo(Iterador<pEstacion> pasar)
{

	Puntero<ListaOrdenada<pEstacion>> estacionesMalas =  new ListaOrdenada<pEstacion>(new ComparadorEstacionesLista());
	while(pasar.HayElemento())
	{
		estacionesMalas->agregarElemento(pasar.ElementoActual());
		pasar.Avanzar();
	};
	pasar.Reiniciar();


	Iterador<pEstacion> solucion;
	pEstacion o = pasar.ElementoActual();
	pasar.Avanzar();
	pEstacion destino = pasar.ElementoActual();
	Puntero<ListaOrdenada<pEstacion>> estacionesAIgnorar =  new ListaOrdenada<pEstacion>(new ComparadorEstaciones());

	//Puntero<ListaOrdenada<pEstacion>> estacionesNo =  new ListaOrdenada<pEstacion>(new ComparadorEstaciones());
	Array<pEstacion> arraySolucion = Array<pEstacion>(this->cantVertices());
	nat indice = 1;
	arraySolucion[0]=o;
	Puntero<ListaOrdenada<pEstacion>> caminoSolucion =  new ListaOrdenada<pEstacion>(new ComparadorEstacionesLista());
	while(pasar.HayElemento())
	{
		estacionesAIgnorar->agregarElemento(pasar.ElementoActual());
		pasar.Avanzar();
	};
	pasar.Reiniciar();
	Array<nodoDijkstra> dbDij = Array<nodoDijkstra>(this->cantVertices());
	//cout << "Entro alguna vez? "<<endl;

	while(pasar.HayElemento())
	{
		if(!HayCamino(o,destino)){
			return NULL;
		};
		for(nat i=0;i<this->cantVertices();i++)
		{
			dbDij[i].conocido=false;
			dbDij[i].distancia = INFINITO;
			dbDij[i].tiempo = INFINITO;
			dbDij[i].ant = NULL;
			dbDij[i].estacion = this->aVertices[i].vertice;
			if(estacionesAIgnorar->pertenece(dbDij[i].estacion))
			{
				dbDij[i].conocido=true;
			};
		};
		//cout << "Entro alguna vez? "<<endl;
		nat origen = this->nombreInterno(o);
		dbDij[origen].distancia = 0;
		dbDij[origen].tiempo =0;
		dbDij[origen].conocido = true;
		pEstacion estacion = o;
		while(HayMasDesconocidos(dbDij) && estacion != NULL)
		{
			//cout << "Entro alguna vez? "<<endl;
			nat nOrigen = this->nombreInterno(estacion);
			dbDij[nOrigen].conocido=true;
			Iterador<A> adyac = adyacentes(estacion);
			while(adyac.HayElemento())
			{
				A arcoAdyacente = adyac.ElementoActual();
				if(arcoAdyacente!=NULL)
				{
					//cout << "alguna no es null"<< endl;
					if((dbDij[nOrigen].tiempo+arcoAdyacente->tiempo < dbDij[this->nombreInterno(arcoAdyacente->destino)].tiempo)
						||
						((dbDij[nOrigen].tiempo+arcoAdyacente->tiempo == dbDij[this->nombreInterno(arcoAdyacente->destino)].tiempo) &&
						dbDij[nOrigen].distancia+arcoAdyacente->distancia < dbDij[this->nombreInterno(arcoAdyacente->destino)].distancia))
					{
						dbDij[this->nombreInterno(arcoAdyacente->destino)].distancia =dbDij[nOrigen].distancia+arcoAdyacente->distancia;
						dbDij[this->nombreInterno(arcoAdyacente->destino)].tiempo = dbDij[nOrigen].tiempo+arcoAdyacente->tiempo;
						dbDij[this->nombreInterno(arcoAdyacente->destino)].ant = estacion;
					};
				};
				adyac.Avanzar();
			};
			adyac.Reiniciar();
			//cout << "no pifia antes" << endl;
			estacion = ObtenerSiguienteDesconocido(dbDij);
			//cout << "pifio?"<<endl;
		};

		
		Iterador<pEstacion> camino = this->crearCamino(o, destino, dbDij);
		nat iterActual = 0;
		while(camino.HayElemento())
		{
			//estacionesAIgnorar->agregarElemento(camino.ElementoActual());
			//cout << " [[" << nombreInterno(camino.ElementoActual()) << "] \"" << camino.ElementoActual()->ObtenerNombre()<<   "\"] -> ";
			if(iterActual!=0)
			{
				arraySolucion[indice] = camino.ElementoActual();
				indice++;
			};
			iterActual++;
			if(!estacionesMalas->pertenece(camino.ElementoActual()) || camino.ElementoActual() == o)
			{
				caminoSolucion->agregarElemento(camino.ElementoActual(),true);
			};
			camino.Avanzar();
		};
		cout << endl;
		camino.Reiniciar();
		solucion.Concat(camino);
		pasar.Avanzar();
		estacionesAIgnorar->agregarElemento(o);//la ignoro antes de cambiar
		o = destino;//nuevo origen
		if(pasar.HayElemento()){
			destino = pasar.ElementoActual();//nuevo destino (siguiente de la lista)
		};
		estacionesAIgnorar->eliminar(o);
		estacionesAIgnorar->eliminar(destino);
	};
	
	nat countNotNull=0;
	for(nat i=0;i<this->cantVertices();i++)
	{
		if(arraySolucion[i]!=NULL)
			countNotNull++;	
	}
	Array<pEstacion> ultimaSol(countNotNull);
	for(nat i=0;i<countNotNull;i++)
	{
		ultimaSol[i]=arraySolucion[i];
	}
	return ultimaSol.ObtenerIterador();
};

template<class V, class A>
nat GrafoImp<V,A>::cantidadMaximaPersonas(const pEstacion& origen, const pEstacion& destino)
{
	//Puntero<GrafoImp<V,A>> gResidual = clon();
	/*Puntero<GrafoImp<V,A>> gFlujo = clon();
	gFlujo->dejarAristasEnCero();*/

	nat pesoTotal =0;
	Array<nodoDijkstra> dbDij = dijkstraDensidad(origen);
	Tupla<Iterador<A>,nat> caminoAristas = crearCaminoDensidad(origen, destino,dbDij);
	Iterador<A> aristasCamino = caminoAristas.ObtenerDato1();
	nat pesoMinimo = caminoAristas.ObtenerDato2();
	Iterador<A> ady = this->adyacentes(origen);
	nat sumaAdy =0;
	nat sumaInc =0;
	while(ady.HayElemento())
	{
		sumaAdy += ady.ElementoActual()->densidad;
		ady.Avanzar();

	};

	Iterador<A> inc = this->incidentes(destino);
	while(inc.HayElemento())
	{
		sumaInc += inc.ElementoActual()->densidad;
		inc.Avanzar();

	};
	
	inc.Reiniciar();

	//cout <<  min(sumaAdy,sumaInc) << " " << sumaAdy << " " << sumaInc << " "<< pesoMinimo << endl;
	return min(sumaAdy,sumaInc);
	//nat min=;
	//cout << pesoMinimo << endl;

	while(aristasCamino.HayElemento())
	{/////// agregar arista al grafo de flijo
		pesoTotal += aristasCamino.ElementoActual()->densidad;
		aristasCamino.Avanzar();
	};

	//cout << endl <<endl << pesoTotal << endl << endl;
	return pesoTotal;
};
template<class V, class A>
void GrafoImp<V,A>::dejarAristasEnCero()
{
	Puntero<ComparadorNodoGrafo> ngComp =  new ComparadorNodoGrafo();
	for(nat i=0;i<this->cantVertices();i++)
	{
		for(nat j=0;j<this->cantVertices();j++)
		{
			this->aArcos[i][j] = new AVL<pArco>(ngComp);
		}
	};
};

template<class V, class A>
void GrafoImp<V,A>::actualizarDensidad(const pEstacion& origen, const pEstacion& destino, pArcoEstaciones arco, nat nuevaDensidad)
{
	nat nOrigen = nombreInterno(origen);
	nat nDestino = nombreInterno(destino);
	nat densidadActual = arco->densidad - nuevaDensidad;
	pArco arqueto = new nodoArco<pArcoEstaciones>();
	arqueto->arco = arco;
	if(densidadActual <= 0)
	{
	//	cout << "No deber�a estar aca! bah solo una vez"<< endl;
		this->DeshabilitarArco(origen,destino,arco);
	}else
	{
		//cout << "la nueva densidad: "<< densidadActual<< endl;
		arco->densidad = densidadActual;
	};
};
#endif