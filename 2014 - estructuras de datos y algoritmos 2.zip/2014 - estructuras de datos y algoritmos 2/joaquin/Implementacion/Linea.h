#pragma once
#include "ILinea.h"
#include "Array.h"
class Linea : public ILinea
{
public:

	Linea(nat nroLinea, nat precio, Iterador<Tupla<pEstacion, nat, nat, nat>> iter);
	Linea(const pLinea& l);

	//de ILinea;

	nat ObtenerNroLinea() const{ return nroLinea;};
	nat ObtenerPrecio() const{return (precio);};
	nat ObtenerDistancia(){return distancia;}
	nat ObtenerDistancia() const{return distancia;}
	Iterador<Tupla<pEstacion, nat, nat, nat>> ObtenerEstaciones() const;

	bool operator==(const ILinea& l) const
	{
		return nroLinea == l.ObtenerNroLinea();
	};

	~Linea(void);

private:
	nat nroLinea;
	nat precio;
	nat distancia;
	Array<Tupla<pEstacion, nat, nat, nat>> estaciones;
};

typedef Puntero<Linea> pLineaMia;