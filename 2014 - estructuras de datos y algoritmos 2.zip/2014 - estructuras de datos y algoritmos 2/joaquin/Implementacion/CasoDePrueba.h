﻿#pragma once

#include "ISistema.h"
#include "Prueba.h"

class CasoDePrueba : public Prueba
{
public:
	CasoDePrueba(Puntero<ISistema> (*inicializar)(nat MAX_LINEAS, nat MAX_ESTACIONES));
protected:
	void CorrerPruebaConcreta();
	Cadena GetNombre() const;

private:
	Puntero<ISistema> (*inicializar)(nat MAX_LINEAS, nat MAX_ESTACIONES);
	Puntero<ISistema> InicializarSistema(nat MAX_LINEAS = 20, nat MAX_ESTACIONES = 23);
	void InicializarEstacion(Puntero<ISistema> interfaz);
	void InicializarLinea(Puntero<ISistema> interfaz);

	bool ignorarOK;
	void Verificar(TipoRetorno obtenido, TipoRetorno esperado, Cadena comentario);
	template <class T>
	void Verificar(const T& obtenido, const T& esperado, Cadena comentario);
	template <class T>
	void VerificarConjuntos(Iterador<T> obtenidos, Iterador<T> esperados, Cadena comentarioEncontrado, Cadena comentarioFalta, Cadena comentarioSobra);
	template <class T>
	void VerificarSecuencias(Iterador<T> obtenidos, Iterador<T> esperados, Cadena comentarioEncontrado, Cadena comentarioFalta, Cadena comentarioSobra);
	bool VerificarLinea(Iterador<Tupla<pEstacion, nat, nat, nat>> obtenidos, Iterador<Tupla<pEstacion, nat, nat, nat>> esperados) const;
	template <class T>
	bool SonIguales(Iterador<T> obtenidos, Iterador<T> esperados) const;
	template <class T>
	bool Pertenece(const T& obtenido, Iterador<T> esperados) const;
	void VerificarConsultaLinea(Tupla<TipoRetorno, pLinea> obtenido, Tupla<TipoRetorno, pLinea> esperado, Cadena comentario);
	void VerificarConsultaEstacion(Tupla<TipoRetorno, pEstacion> obtenido, Tupla<TipoRetorno, pEstacion> esperado, Cadena comentario);
	void VerificarListadoEstaciones(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario);
	void VerificarEstacionMasLineasHabilitadas(Tupla<TipoRetorno, pEstacion> obtenido, Tupla<TipoRetorno, pEstacion> esperado, Cadena comentario);
	void VerificarListadoEstacionesHorario(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario);
	void VerificarTrayectoMenorDistancia(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario);
	void VerificarCableadoMenorDistancia(Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> obtenido, Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> esperado, Cadena comentario);
	void VerificarListadoTrayecto(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario);
	void VerificarListadoTodosLosTrayectos(Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> obtenido, Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> esperado, Cadena comentario);
	void VerificarTrayectoMenosTransbordos(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario);
	void VerificarCantidadMaxima(Tupla<TipoRetorno, nat> obtenido, Tupla<TipoRetorno, nat> esperado, Cadena comentario);
	void VerificarLineasAAbordar(Tupla<TipoRetorno, nat, Iterador<pLinea>> obtenido, Tupla<TipoRetorno, nat, Iterador<pLinea>> esperado, Cadena comentario);
	void VerificarEstacionesCriticas(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario);
	bool SonIguales(const pEstacion& obtenido, const pEstacion& esperado) const;
	Cadena ObtenerTexto(const pEstacion& e) const;
	Cadena ObtenerTexto(const Iterador<pEstacion>& recorrido) const
	{
		return Cadena();
	}

	bool SonIguales(const pLinea& obtenido, const pLinea& esperado) const;
	Cadena ObtenerTexto(const pLinea& l) const;
	bool SonIguales(const Tupla<pEstacion, nat, nat, nat>& obtenido, const Tupla<pEstacion, nat, nat, nat>& esperado) const;
	Cadena ObtenerTexto(const Tupla<pEstacion, nat, nat, nat>& t) const;
	bool SonIguales(const Tupla<pEstacion, pEstacion, nat>& obtenido, const Tupla<pEstacion, pEstacion, nat>& esperado) const;
	Cadena ObtenerTexto(const Tupla<pEstacion, pEstacion, nat>& t) const;

	void PruebaOKIngresoEstacion();
	void PruebaOKIngresoLinea();
	void PruebaOKHabilitacionTramo();
	void PruebaOKConsultaLinea();
	void PruebaOKConsultaEstacion();
	void PruebaOKListadoEstaciones();
	void PruebaOKEstacionMasLineasHabilitadas();
	void PruebaOKListadoEstacionesHorario();
	void PruebaOKTrayectoMenorDistancia();
	void PruebaOKCableadoMenorDistancia();
	void PruebaOKListadoTrayecto();
	void PruebaOKListadoTodosLosTrayectos();
	void PruebaOKTrayectoMenosTransbordos();
	void PruebaOKCantidadMaxima();
	void PruebaOKLineasAAbordarA();
	void PruebaOKLineasAAbordarB();
	void PruebaOKLineasAAbordar(bool esA);
	void PruebaOKEstacionesCriticas();

	void PruebaERRORIngresoEstacion();
	void PruebaERRORIngresoLinea();
	void PruebaERRORHabilitacionTramo();
	void PruebaERRORConsultaLinea();
	void PruebaERRORConsultaEstacion();
	void PruebaERRORListadoEstaciones();
	void PruebaERROREstacionMasLineasHabilitadas();
	void PruebaERRORListadoEstacionesHorario();
	void PruebaERRORTrayectoMenorDistancia();
	void PruebaERRORCableadoMenorDistancia();
	void PruebaERRORListadoTrayecto();
	void PruebaERRORListadoTodosLosTrayectos();
	void PruebaERRORTrayectoMenosTransbordos();
	void PruebaERRORCantidadMaxima();
	void PruebaERRORLineasAAbordarA();
	void PruebaERRORLineasAAbordarB();
	void PruebaERROREstacionesCriticas();

	Array<pEstacion> ObtenerEstacionesDelSistema(nat orden = 0);
	Array<pLinea> ObtenerLineasDelSistema();
};

class ConvertNombre : public Conversor<Tupla<pEstacion, nat, nat, nat>, Tupla<Cadena, nat, nat, nat>>
{
public:
	virtual ~ConvertNombre(){}
protected:
	Tupla<Cadena, nat, nat, nat> Convertir(const Tupla<pEstacion, nat, nat, nat>& t) const 
	{
		return Tupla<Cadena, nat, nat, nat>(t.Dato1->ObtenerNombre(), t.Dato2, t.Dato3, t.Dato4); 
	}
};