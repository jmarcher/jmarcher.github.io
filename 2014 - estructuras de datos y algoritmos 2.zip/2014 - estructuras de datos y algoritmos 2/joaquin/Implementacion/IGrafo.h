#pragma once
#include "Puntero.h"
#include "Iterador.h"
typedef unsigned int nat;
template<class V, class A>
class Grafo abstract
{
public:
	virtual ~Grafo(){};
	
	virtual void InsertarVertice(const V& v) abstract;
	//pre !estaLleno
	//pos agrega va a los vertices del grago, si v no pertenece al grafo
	
	virtual void InsertarArco(const V& o, const V& d, A arco) abstract;
	//pre pertenece(o) && pertenece(d) [[si el grafo ac�clico => !existeCamino(d,o)]]
	// agrega el arco al grafo
	
	virtual bool EliminarArco(const V& o, const V& d, const A& a) abstract;
	//pre
	//pos elimina el arco del grafo, retorna true si lo pudo eliminar, false en caso contrario.
	
	virtual bool EliminarVertice(const V& v) abstract;
	//pre 
	//por elimina v si este existe, y no teiene arcos, retorna true si lo elimina, y false en caso contrario
	
	virtual bool HabilitarArco(const V& o, const V& d, const A& a) abstract;
	//pre
	//pos se habilita el arco si existe, R: true si habilita, false si no pudo
	
	virtual bool DeshabilitarArco(const V& o, const V& d, const A& a) abstract;
	//pre
	//pos se deshabilita el arco si existe, R: true si deshabilita, false si no pudo
	
	virtual bool HabilitarVertice(const V& v) abstract;
	//pre
	//pos ...
	
	virtual bool DeshabilitarVertice(const V& v) abstract;
	//pre
	//pos ...
	
	virtual bool estaHabilitado(const V& v) const abstract;
	//pre
	//pos retorna true sii v esta habilitado
	
	virtual bool estaHabilitado(const V& o, const V& d, const A& a) const abstract;
	//pre
	//pos retorna true sii estahabilitado(o) && estaHabilitado(d) && estaHabilitado(a)

	virtual bool pertenece(const V& v) const abstract;
	//pre
	//pos ...

	virtual bool estaLleno() const abstract;
	//pre
	//pos ...
	
	virtual nat cantVertices() const abstract;
	//pre
	//pos ...
	
	virtual Puntero<Grafo<V,A>> clon() const abstract;
	//pre
	//pos ...
	
	virtual Puntero<Grafo<V,A>> crearVacio() const abstract;
	//pre
	//pos
	
	virtual Grafo<V,A>& operator=(const Grafo<V,A>& g) abstract;
	
	//ITERADORES
	virtual Iterador<A> arcos(const V& o, const V& d) const abstract;
	//pre
	//pos retorna un iterador sobre los arcos o-d
	
	virtual Iterador<V> vertices() const abstract;
	//pre
	//pos retorna un iterador sobre los vertices del grafo
	
	
	//O tambien incidentes
	virtual Iterador<A> adyacentes(const V& v) const abstract;
	//pre
	//pos devuelve los adyacentes al vertice V

	virtual Iterador<A> incidentes(const V& v) const abstract;
	
};