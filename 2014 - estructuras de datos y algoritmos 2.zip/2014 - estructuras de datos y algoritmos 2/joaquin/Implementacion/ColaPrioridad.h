#pragma once
#include "Puntero.h"
#include "Array.h"
#include "Comparador.h"
/*
Una cola de prioridad con prioridad natural
*/
typedef unsigned int nat;
template<class T>
class ColaPrioridad
{
public:
	ColaPrioridad(nat CANT_ELEMENTOS, const Puntero<Comparador<T>>& comp);

	void Insertar(const T & t, nat pr);

	void Eliminar(const T& t);
	
	T& Minimo() const;
	T& Maximo() const;

	virtual ~ColaPrioridad(void);
private:
	nat CANT_MAX_ELEMENTOS;
	Puntero<Comparador<T>> aComp;
	
};

