#include "Lista.h"


Lista::Lista(void)
{
}


Lista::~Lista(void)
{
}
