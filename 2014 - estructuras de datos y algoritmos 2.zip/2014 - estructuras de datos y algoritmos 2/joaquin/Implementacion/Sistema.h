﻿#ifndef SISTEMA_H
#define SISTEMA_H

#include "Puntero.h"
#include "ISistema.h"
#include "GrafoImp.h"
#include "AVL.h"
#include "TablaHash.h"
#include "Estacion.h"
#include "TablaHash.h"
#include "CadenaFuncionHash.h"
#include "ComparadorArcoGrafoEstaciones.h"
#include "ComparadorEstacionPorHorario.h"
#include "ComparadorEstaciones.h"
#include "FuncionHashEstacion.h"
#include "FuncionHashLinea.h"
#include "ComparadorLinea.h"
#include "arcoGrafoEstaciones.h"
#include "Linea.h"
#include "ListaOrdenada.h"
//#include "GrafoMetro.h"

class Sistema : public ISistema
{
public:
	Sistema(nat MAX_LINEAS, nat MAX_ESTACIONES);

	// Hito de Control Tipo 1
	TipoRetorno IngresoEstacion(Cadena nombre, nat hAbre, nat hCierra);

	Iterador<Tupla<pEstacion, nat, nat, nat>> pertenecenEstaciones( Iterador<Tupla<Cadena, nat, nat, nat>> estaciones) const;
	//verifica si existen las estaciones
	//retorna el iterador si existen todas con las pEstacion de cada una, retorna NULL en caso contrario.
	TipoRetorno IngresoLinea(nat nroLinea, nat precio, Iterador<Tupla<Cadena, nat, nat, nat>> estaciones);
	TipoRetorno HabilitacionTramo(nat nroLinea, Cadena eOrigen, Cadena eDestino, bool habilitado);
	Tupla<TipoRetorno, pLinea> ConsultaLinea(nat nroLinea);
	Tupla<TipoRetorno, pEstacion> ConsultaEstacion(Cadena nombreEstacion);
	Tupla<TipoRetorno, Iterador<pEstacion>> ListadoEstaciones();
	Tupla<TipoRetorno, pEstacion> EstacionMasLineasHabilitadas();

	// Entrega final Tipo 1
	Tupla<TipoRetorno, Iterador<pEstacion>> ListadoEstacionesHorario();
	Tupla<TipoRetorno, Iterador<pEstacion>> TrayectoMenorDistancia(Cadena eOrigen, Cadena eDestino, nat hora);
	Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> CableadoMenorDistancia();
	Tupla<TipoRetorno, Iterador<pEstacion>> ListadoTrayecto(Iterador<Cadena> estaciones);
	Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> ListadoTodosLosTrayectos(Cadena eOrigen, Cadena eDestino);

	// Entrega final Tipo 2
	Tupla<TipoRetorno, Iterador<pEstacion>> TrayectoMenosTransbordos(Cadena eOrigen, Cadena eDestino);
	Tupla<TipoRetorno, nat> CantidadMaxima(Cadena eOrigen, Cadena eDestino);
	Tupla<TipoRetorno, nat, Iterador<pLinea>> LineasAAbordarA(nat dineroMax);
	Tupla<TipoRetorno, nat, Iterador<pLinea>> LineasAAbordarB(nat dineroMax);

	// Operaciones opcionales
	Tupla<TipoRetorno, Iterador<pEstacion>> EstacionesCriticas(Cadena eOrigen, Cadena eDestino);

private:
	//Estructuras
	Puntero<AVL<pEstacion>> avlEstaciones;
	Puntero<AVL<pEstacion>> avlEstacionesPorHorario;
	Puntero<TablaHash<pEstacion>> hashEstaciones;
	Array<pLinea> arrayLineas;
	//Puntero<TablaHash<pLinea>> hashLineas;
	Puntero<GrafoImp<pEstacion,pArcoEstaciones>> grafoEstaciones;
	//Puntero<GrafoMetro> grafoEstaciones;
	Puntero<ComparadorEstaciones> compEstaciones;
	Puntero<ComparadorArcoGrafoEstaciones> compArcoGrafoEstaciones;
	Puntero<FuncionHashEstacion> funcHashEst;
	//Puntero<ComparadorLinea> compLinea;
	//Puntero<FuncionHashLinea> funcHashLinea;
	Puntero<ComparadorEstacionPorHorario> compEstacionesPorHorario;
	Array<pLineaMia> lineas;
	Matriz<int> dbLineas;
	Array<Matriz<int>> dbLineasAAbordar;
	int lineasAAbordarMochila(int c, int lineaHasta);
	int lineasAAbordarMochilaSinMemoria(int c, int lineaHasta);
	bool fueCalculado(int c, int lineaHasta);

	nat MAX_CANT_LINEAS, MAX_CANT_ESTACIONES;
	nat cantLineas;
	bool enRangoLinea(nat n);
};

#endif
