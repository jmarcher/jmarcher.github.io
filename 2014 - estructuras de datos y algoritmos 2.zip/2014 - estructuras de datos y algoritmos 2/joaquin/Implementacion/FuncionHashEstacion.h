#pragma once
#include "FuncionHash.h"
#include "IEstacion.h"
#include "CadenaFuncionHash.h"
#include "GrafoImp.h"

class FuncionHashEstacion : public FuncionHash<pEstacion>
{
public:
	nat CodigoDeHash(const pEstacion& e) const
	{
		Puntero<CadenaFuncionHash> cfh = new CadenaFuncionHash();
		return cfh->CodigoDeHash(e->ObtenerNombre());
	};
};
class FuncionHashNodoGrafo : public FuncionHash<nodoVert<pEstacion>>
{
public:
	nat CodigoDeHash(const nodoVert<pEstacion>& e) const
	{
		Puntero<CadenaFuncionHash> cfh = new CadenaFuncionHash();
		return cfh->CodigoDeHash(e.vertice->ObtenerNombre());
	};
};