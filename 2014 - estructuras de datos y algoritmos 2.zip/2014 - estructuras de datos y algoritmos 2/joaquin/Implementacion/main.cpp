﻿#include "CasoDePrueba.h"
#include "PruebaMemoria.h"
#include "ConductorPrueba.h"
#include "Sistema.h"
#include "Puntero.h"
#include "AVL.h"
#include "TablaHash.h"
#include "Cadena.h"
#include "CadenaFuncionHash.h"
#include "ComparadorEstaciones.h"
#include "FuncionHashEstacion.h"
#include <iostream>
#include <omp.h>
#include <stdio.h>
#include <chrono>
//#include "GrafoImp.h"
#include "Estacion.h"
//#include "GrafoMetro.h"

Puntero<ISistema> Inicializar(nat MAX_LINEAS, nat MAX_ESTACIONES)
{
	return new Sistema(MAX_LINEAS, MAX_ESTACIONES);
}


void main()

{

double dtime = omp_get_wtime();
auto begin = std::chrono::high_resolution_clock::now();

	Puntero<ConductorPrueba> cp = new ConductorPrueba();
	Array<Puntero<Prueba>> pruebas = Array<Puntero<Prueba>>(3);
	pruebas[0] = new PruebaMemoria();
	pruebas[1] = new CasoDePrueba(Inicializar);
	pruebas[2] = pruebas[0];
	cp->CorrerPruebas(pruebas.ObtenerIterador());

	auto end = std::chrono::high_resolution_clock::now();
	dtime = omp_get_wtime() - dtime;
	std::cout << std::chrono::duration_cast<std::chrono::nanoseconds>(end-begin).count() << "ns" << std::endl;
	printf("Tiempo en nano segundos: %d\n", std::chrono::duration_cast<std::chrono::nanoseconds>(end-begin).count());
    printf("time in seconds %f\n", dtime);
	
	std::cin.get();
}
