﻿#include "CasoDePrueba.h"
#include "PruebasMock.h"

CasoDePrueba::CasoDePrueba(Puntero<ISistema> (*inicializar)(nat MAX_LINEAS, nat MAX_ESTACIONES))
{
	this->inicializar = inicializar;
}

Puntero<ISistema> CasoDePrueba::InicializarSistema(nat MAX_LINEAS, nat MAX_ESTACIONES)
{
	Puntero<ISistema> interfaz = inicializar(MAX_LINEAS, MAX_ESTACIONES);
	ignorarOK = false;
	return interfaz;
}

void CasoDePrueba::InicializarEstacion(Puntero<ISistema> interfaz)
{
	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema();
	Cadena ingreso = " Se ingresa la estacion {0}";

	foreach (estacion, estaciones)
		Verificar(interfaz->IngresoEstacion(estacion->ObtenerNombre(), estacion->ObtenerHAbre(), estacion->ObtenerHCierra()), OK, ingreso.DarFormato(estacion->ObtenerNombre()));
}

void CasoDePrueba::InicializarLinea(Puntero<ISistema> interfaz)
{
	Array<pLinea> lineas = ObtenerLineasDelSistema();
	Cadena ingreso = " Se ingresa la linea {0}";

	foreach (linea, lineas)
	{
		char nroLinea[8]; 
		_itoa_s(linea->ObtenerNroLinea(), nroLinea, 10);

		Verificar(interfaz->IngresoLinea(linea->ObtenerNroLinea(), linea->ObtenerPrecio(), linea->ObtenerEstaciones().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), OK, ingreso.DarFormato(nroLinea));
	}
}

Array<pEstacion> CasoDePrueba::ObtenerEstacionesDelSistema(nat orden)
{
	Array<pEstacion> retorno = Array<pEstacion>(23);

	//Orden de ingreso (sin orden)
	if(orden == 0)
	{
		retorno[0] = new EstacionMock("Atocha", 10, 20);
		retorno[1] = new EstacionMock("San Cristóbal", 11, 20);
		retorno[2] = new EstacionMock("Mirasierra", 18, 23);
		retorno[3] = new EstacionMock("Boadilla", 8, 22);
		retorno[4] = new EstacionMock("Callao", 4, 21);
		retorno[5] = new EstacionMock("Cartagena", 7, 22);
		retorno[6] = new EstacionMock("Jarama", 12, 17);
		retorno[7] = new EstacionMock("Esperanza", 9, 20);
		retorno[8] = new EstacionMock("La Fortuna", 3, 18);
		retorno[9] = new EstacionMock("Estrecho", 5, 23);
		retorno[10] = new EstacionMock("Fuencarral", 9, 20);
		retorno[11] = new EstacionMock("Goya", 8, 20);
		retorno[12] = new EstacionMock("Gran Vía", 7, 22);
		retorno[13] = new EstacionMock("Metropolitano", 7, 15);
		retorno[14] = new EstacionMock("Hortaleza", 13, 23);
		retorno[15] = new EstacionMock("Bilbao", 10, 21);
		retorno[16] = new EstacionMock("La Poveda", 1, 21);
		retorno[17] = new EstacionMock("Estadio Olímpico", 6, 20);
		retorno[18] = new EstacionMock("Portazgo", 12, 20);
		retorno[19] = new EstacionMock("Colón", 8, 19);
		retorno[20] = new EstacionMock("Henares", 10, 22);
		retorno[21] = new EstacionMock("Quevedo", 2, 21);
		retorno[22] = new EstacionMock("Barajas", 8, 19);
	}
	//nombre
	else if(orden == 1)
	{
		retorno[0] = new EstacionMock("Atocha", 10, 20);
		retorno[1] = new EstacionMock("Barajas", 8, 19);
		retorno[2] = new EstacionMock("Bilbao", 10, 21);
		retorno[3] = new EstacionMock("Boadilla", 8, 22);
		retorno[4] = new EstacionMock("Callao", 4, 21);
		retorno[5] = new EstacionMock("Cartagena", 7, 22);
		retorno[6] = new EstacionMock("Colón", 8, 19);
		retorno[7] = new EstacionMock("Esperanza", 9, 20);
		retorno[8] = new EstacionMock("Estadio Olímpico", 6, 20);
		retorno[9] = new EstacionMock("Estrecho", 5, 23);
		retorno[10] = new EstacionMock("Fuencarral", 9, 20);
		retorno[11] = new EstacionMock("Goya", 8, 20);
		retorno[12] = new EstacionMock("Gran Vía", 7, 22);
		retorno[13] = new EstacionMock("Henares", 10, 22);
		retorno[14] = new EstacionMock("Hortaleza", 13, 23);
		retorno[15] = new EstacionMock("Jarama", 12, 17);
		retorno[16] = new EstacionMock("La Fortuna", 3, 18);
		retorno[17] = new EstacionMock("La Poveda", 1, 21);
		retorno[18] = new EstacionMock("Metropolitano", 7, 15);
		retorno[19] = new EstacionMock("Mirasierra", 18, 23);
		retorno[20] = new EstacionMock("Portazgo", 12, 20);
		retorno[21] = new EstacionMock("Quevedo", 2, 21);
		retorno[22] = new EstacionMock("San Cristóbal", 11, 20);
	}
	return retorno;
}

Array<pLinea> CasoDePrueba::ObtenerLineasDelSistema()
{
	Array<pLinea> retorno = Array<pLinea>(7);
	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);
	
	Array<Tupla<pEstacion, nat, nat, nat>> tramos;
	
	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(5);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[18], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[1], 100, 8, 30);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[8], 50, 8, 30);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[19], 150, 20, 50);
	tramos[4] = Tupla<pEstacion, nat, nat, nat>(estaciones[15], 50, 10, 10);
	retorno[0] = new LineaMock(8, 20, tramos.ObtenerIterador());

	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(5);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[0], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[12], 50, 50, 15);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[17], 10, 20, 10);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[11], 15, 7, 10);
	tramos[4] = Tupla<pEstacion, nat, nat, nat>(estaciones[21], 10, 10, 10);
	retorno[1] = new LineaMock(10, 100, tramos.ObtenerIterador());

	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(4);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[13], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[6], 50, 10, 10);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[2], 100, 10, 10);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[7], 10, 10, 10);
	retorno[2] = new LineaMock(5, 50, tramos.ObtenerIterador());

	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(5);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[10], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[22], 50, 50, 15);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[9], 20, 20, 15);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[16], 15, 15, 10);
	tramos[4] = Tupla<pEstacion, nat, nat, nat>(estaciones[20], 20, 10, 10);
	retorno[3] = new LineaMock(19, 90, tramos.ObtenerIterador());

	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(4);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[4], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[14], 100, 50, 20);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[3], 50, 20, 15);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[5], 75, 25, 40);
	retorno[4] = new LineaMock(1, 50, tramos.ObtenerIterador());

	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(9);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[0], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[11], 50, 50, 75);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[17], 20, 10, 15);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[21], 10, 10, 10);
	tramos[4] = Tupla<pEstacion, nat, nat, nat>(estaciones[2], 50, 50, 50);
	tramos[5] = Tupla<pEstacion, nat, nat, nat>(estaciones[18], 105, 105, 105);
	tramos[6] = Tupla<pEstacion, nat, nat, nat>(estaciones[15], 575, 80, 20);
	tramos[7] = Tupla<pEstacion, nat, nat, nat>(estaciones[1], 50, 10, 8);
	tramos[8] = Tupla<pEstacion, nat, nat, nat>(estaciones[10], 80, 80, 80);
	retorno[5] = new LineaMock(2, 120, tramos.ObtenerIterador());

	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(8);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[5], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[4], 500, 100, 50);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[13], 10, 75, 15);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[7], 150, 8, 100);
	tramos[4] = Tupla<pEstacion, nat, nat, nat>(estaciones[2], 20, 30, 70);
	tramos[5] = Tupla<pEstacion, nat, nat, nat>(estaciones[11], 130, 85, 90);
	tramos[6] = Tupla<pEstacion, nat, nat, nat>(estaciones[17], 55, 70, 35);
	tramos[7] = Tupla<pEstacion, nat, nat, nat>(estaciones[0], 25, 90, 90);
	retorno[6] = new LineaMock(7, 110, tramos.ObtenerIterador());

	return retorno;
}

Cadena CasoDePrueba::GetNombre()const
{
	return "Casos de Prueba";
}

void CasoDePrueba::CorrerPruebaConcreta()
{
	PruebaOKIngresoEstacion();
	PruebaOKIngresoLinea();
	PruebaOKHabilitacionTramo();
	PruebaOKConsultaLinea();
	PruebaOKConsultaEstacion();
	PruebaOKListadoEstaciones();
	PruebaOKEstacionMasLineasHabilitadas();
	PruebaOKListadoEstacionesHorario();
	PruebaOKTrayectoMenorDistancia();
	PruebaOKCableadoMenorDistancia();
	PruebaOKListadoTrayecto();
	PruebaOKListadoTodosLosTrayectos();
	PruebaOKTrayectoMenosTransbordos();
	PruebaOKCantidadMaxima();
	PruebaOKLineasAAbordarA();
	PruebaOKLineasAAbordarB();
	PruebaOKEstacionesCriticas();

	PruebaERRORIngresoEstacion();
	PruebaERRORIngresoLinea();
	PruebaERRORHabilitacionTramo();
	PruebaERRORConsultaLinea();
	PruebaERRORConsultaEstacion();
	PruebaERRORListadoEstaciones();
	PruebaERROREstacionMasLineasHabilitadas();
	PruebaERRORListadoEstacionesHorario();
	PruebaERRORTrayectoMenorDistancia();
	PruebaERRORCableadoMenorDistancia();
	PruebaERRORListadoTrayecto();
	PruebaERRORListadoTodosLosTrayectos();
	PruebaERRORTrayectoMenosTransbordos();
	PruebaERRORCantidadMaxima();
	PruebaERRORLineasAAbordarA();
	PruebaERRORLineasAAbordarB();
	PruebaERROREstacionesCriticas();
}

void CasoDePrueba::Verificar(TipoRetorno obtenido, TipoRetorno esperado, Cadena comentario)
{
	if (!ignorarOK || obtenido != esperado)
		Prueba::Verificar(obtenido, esperado, comentario);
}

template <class T>
void CasoDePrueba::Verificar(const T& obtenido, const T& esperado, Cadena comentario)
{
	Verificar(SonIguales(obtenido, esperado) ? OK : ERROR, OK, comentario.DarFormato(ObtenerTexto(obtenido), ObtenerTexto(esperado)));
}

template <class T>
void CasoDePrueba::VerificarConjuntos(Iterador<T> obtenidos, Iterador<T> esperados, Cadena comentarioEncontrado, Cadena comentarioFalta, Cadena comentarioSobra)
{
	bool verificarCantidad = true;
	nat totalObtenidos = 0;
	foreach (obtenido, obtenidos)
	{
		totalObtenidos++;
		bool esta = false;
		foreach (esperado, esperados)
		{
			if (SonIguales(obtenido, esperado))
			{
				Verificar(OK, OK, comentarioEncontrado.DarFormato(ObtenerTexto(obtenido), ObtenerTexto(esperado)));
				esta = true;
				break;
			}
		}
		if (!esta)
		{
			Verificar(ERROR, OK, comentarioSobra.DarFormato(ObtenerTexto(obtenido)));
			verificarCantidad = false;
		}
	}
	nat totalEsperados = 0;
	foreach (esperado, esperados)
	{
		totalEsperados++;
		bool esta = false;
		foreach (obtenido, obtenidos)
		{
			if (SonIguales(obtenido, esperado))
			{
				esta = true;
				break;
			}
		}
		if (!esta)
		{
			Verificar(ERROR, OK, comentarioFalta.DarFormato(ObtenerTexto(esperado)));
			verificarCantidad = false;
		}
	}
	if (verificarCantidad && totalObtenidos != totalEsperados)
		Verificar(ERROR, OK, "Se verifica la cantidad de elementos de los conjuntos");
}

template <class T>
void CasoDePrueba::VerificarSecuencias(Iterador<T> obtenidos, Iterador<T> esperados, Cadena comentarioEncontrado, Cadena comentarioFalta, Cadena comentarioSobra)
{
	esperados.Reiniciar();

	foreach (obtenido, obtenidos)
	{
		if (esperados.HayElemento())
		{
			T esperado = *esperados;
			esperados++;
			Verificar(obtenido, esperado, comentarioEncontrado);
		}
		else
			Verificar(ERROR, OK, comentarioSobra.DarFormato(ObtenerTexto(obtenido)));
	}

	while (esperados.HayElemento())
	{
		T esperado = *esperados;
		esperados++;
		Verificar(ERROR, OK, comentarioFalta.DarFormato(ObtenerTexto(esperado)));
	}
}

template <class T>
bool CasoDePrueba::SonIguales(Iterador<T> obtenidos, Iterador<T> esperados) const
{
	obtenidos.Reiniciar();
	esperados.Reiniciar();
	while (obtenidos.HayElemento() && esperados.HayElemento())
	{
		if (!SonIguales(*obtenidos, *esperados))
			return false;
		obtenidos++;
		esperados++;
	}

	return esperados.HayElemento() == obtenidos.HayElemento();
}

template <class T>
bool CasoDePrueba::Pertenece(const T& obtenido, Iterador<T> esperados) const
{
	foreach (esperado, esperados)
	{
		if (SonIguales(obtenido, esperado))
			return true;
	}
	return false;
}

void CasoDePrueba::VerificarConsultaLinea(Tupla<TipoRetorno, pLinea> obtenido, Tupla<TipoRetorno, pLinea> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		Verificar(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarConsultaEstacion(Tupla<TipoRetorno, pEstacion> obtenido, Tupla<TipoRetorno, pEstacion> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		Verificar(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarListadoEstaciones(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarSecuencias(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarEstacionMasLineasHabilitadas(Tupla<TipoRetorno, pEstacion> obtenido, Tupla<TipoRetorno, pEstacion> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		Verificar(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarListadoEstacionesHorario(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarSecuencias(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarTrayectoMenorDistancia(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarSecuencias(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarCableadoMenorDistancia(Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> obtenido, Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarListadoTrayecto(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarSecuencias(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarListadoTodosLosTrayectos(Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> obtenido, Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		//VerificarSecuencias(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarTrayectoMenosTransbordos(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarSecuencias(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		//VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarCantidadMaxima(Tupla<TipoRetorno, nat> obtenido, Tupla<TipoRetorno, nat> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		Verificar(obtenido.Dato2 == esperado.Dato2 ? OK : ERROR, OK, "Se verifica el dato 2");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarLineasAAbordar(Tupla<TipoRetorno, nat, Iterador<pLinea>> obtenido, Tupla<TipoRetorno, nat, Iterador<pLinea>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		Verificar(obtenido.Dato2 == esperado.Dato2 ? OK : ERROR, OK, "Se verifica la distancia total obtenida");
		VerificarConjuntos(obtenido.Dato3, esperado.Dato3, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

void CasoDePrueba::VerificarEstacionesCriticas(Tupla<TipoRetorno, Iterador<pEstacion>> obtenido, Tupla<TipoRetorno, Iterador<pEstacion>> esperado, Cadena comentario)
{
	if (obtenido.Dato1 == OK && esperado.Dato1 == OK)
	{
		IniciarSeccion(comentario, esperado.Dato1);
		VerificarConjuntos(obtenido.Dato2, esperado.Dato2, "Se obtuvo {0} y se esperaba {1}", "Se esperaba {0}", "No se esperaba {0}");
		CerrarSeccion();
	}
	else
		Verificar(obtenido.Dato1, esperado.Dato1, comentario);
}

bool CasoDePrueba::SonIguales(const pEstacion& obtenido, const pEstacion& esperado) const
{
	return obtenido->ObtenerNombre() == esperado->ObtenerNombre() && obtenido->ObtenerHAbre() == esperado->ObtenerHAbre() && obtenido->ObtenerHCierra() == esperado->ObtenerHCierra();
}

Cadena CasoDePrueba::ObtenerTexto(const pEstacion& e) const
{
	return e->ObtenerNombre();
}

bool CasoDePrueba::SonIguales(const pLinea& obtenido, const pLinea& esperado) const
{
	bool iguales = obtenido->ObtenerNroLinea() == esperado->ObtenerNroLinea() && obtenido->ObtenerPrecio() == esperado->ObtenerPrecio();

	return iguales && VerificarLinea(obtenido->ObtenerEstaciones(), esperado->ObtenerEstaciones());
}

bool CasoDePrueba::VerificarLinea(Iterador<Tupla<pEstacion, nat, nat, nat>> obtenidos, Iterador<Tupla<pEstacion, nat, nat, nat>> esperados) const
{
	esperados.Reiniciar();

	foreach (obtenido, obtenidos)
	{
		if (esperados.HayElemento())
		{
			Tupla<pEstacion, nat, nat, nat> esperado = *esperados;
			esperados++;
			if(!SonIguales(esperado, obtenido))
				return false;
		}
		else
			return false;
	}

	while (esperados.HayElemento())
	{
		Tupla<pEstacion, nat, nat, nat> esperado = *esperados;
		esperados++;
		return false;
	}

	return true;
}
Cadena CasoDePrueba::ObtenerTexto(const pLinea& l) const
{
	char nroLinea[8]; 
	_itoa_s(l->ObtenerNroLinea(), nroLinea, 10);
	return nroLinea;
}

bool CasoDePrueba::SonIguales(const Tupla<pEstacion, nat, nat, nat>& obtenido, const Tupla<pEstacion, nat, nat, nat>& esperado) const
{
	return SonIguales(obtenido.Dato1, esperado.Dato1) /* cuidado con posibles stack overflows */ && obtenido.Dato2 == esperado.Dato2 && obtenido.Dato3 == esperado.Dato3 && obtenido.Dato4 == esperado.Dato4;
}

Cadena CasoDePrueba::ObtenerTexto(const Tupla<pEstacion, nat, nat, nat>& t) const
{
	return ObtenerTexto(t.Dato1); /* cuidado con posibles stack overflows*/
}

bool CasoDePrueba::SonIguales(const Tupla<pEstacion, pEstacion, nat>& obtenido, const Tupla<pEstacion, pEstacion, nat>& esperado) const
{
	if(obtenido.Dato3 == esperado.Dato3)
	{
		return  (SonIguales(obtenido.Dato1, esperado.Dato1) && SonIguales(obtenido.Dato2, esperado.Dato2)) || (SonIguales(obtenido.Dato1, esperado.Dato2) && SonIguales(obtenido.Dato2, esperado.Dato1)) ;
	}
	return false;
}

Cadena CasoDePrueba::ObtenerTexto(const Tupla<pEstacion, pEstacion, nat>& t) const
{
	Cadena tramo = "tramo {0} - {1} con distancia {2}"; 
	char nroLinea[8]; 
	_itoa_s(t.Dato3, nroLinea, 10);
	return tramo.DarFormato(ObtenerTexto(t.Dato1), ObtenerTexto(t.Dato2), nroLinea); /* cuidado con posibles stack overflows*/
}

void CasoDePrueba::PruebaOKIngresoEstacion()
{
	IniciarSeccion("Ingreso Estacion");
	Puntero<ISistema> interfaz = InicializarSistema();

	InicializarEstacion(interfaz);

	CerrarSeccion();
}

void CasoDePrueba::PruebaOKIngresoLinea()
{
	IniciarSeccion("Ingreso Linea");
	Puntero<ISistema> interfaz = InicializarSistema();

	ignorarOK = true;
	InicializarEstacion(interfaz);
	ignorarOK = false;

	InicializarLinea(interfaz);

	CerrarSeccion();
}

void CasoDePrueba::PruebaOKHabilitacionTramo()
{
	IniciarSeccion("Habilitacion Tramo");
	Puntero<ISistema> interfaz = InicializarSistema();
	
	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);
	Cadena habilitar = " Se habilita el tramo {0} - {1} perteneciente a la linea {2}";
	Cadena inhabilitar = " Se inhabilita el tramo {0} - {1} perteneciente a la linea {2}";
	
	Verificar(interfaz->HabilitacionTramo(19, estaciones[22]->ObtenerNombre(), estaciones[9]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("19", estaciones[22]->ObtenerNombre(), estaciones[9]->ObtenerNombre()));
	Verificar(interfaz->HabilitacionTramo(8, estaciones[1]->ObtenerNombre(), estaciones[8]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("8", estaciones[1]->ObtenerNombre(), estaciones[8]->ObtenerNombre()));
	Verificar(interfaz->HabilitacionTramo(7, estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("7", estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre()));

	Verificar(interfaz->HabilitacionTramo(8, estaciones[1]->ObtenerNombre(), estaciones[8]->ObtenerNombre(), true), OK, habilitar.DarFormato("8", estaciones[1]->ObtenerNombre(), estaciones[8]->ObtenerNombre()));
	Verificar(interfaz->HabilitacionTramo(7, estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre(), true), OK, habilitar.DarFormato("7", estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre()));

	CerrarSeccion();
}

void CasoDePrueba::PruebaOKConsultaLinea()
{
	IniciarSeccion("Consulta Linea");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, pLinea> esperado;
	Tupla<TipoRetorno, pLinea> obtenido;
	char nroLinea[8]; 

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pLinea> lineas = ObtenerLineasDelSistema();
	Cadena texto = " Se consulta la linea {0}";
	
	obtenido = interfaz->ConsultaLinea(lineas[0]->ObtenerNroLinea());
	esperado = Tupla<TipoRetorno, pLinea>(OK, lineas[0]);
	_itoa_s(lineas[0]->ObtenerNroLinea(), nroLinea, 10);

	VerificarConsultaLinea(obtenido, esperado, texto.DarFormato(nroLinea));

	obtenido = interfaz->ConsultaLinea(lineas[3]->ObtenerNroLinea());
	esperado = Tupla<TipoRetorno, pLinea>(OK, lineas[3]);
	_itoa_s(lineas[3]->ObtenerNroLinea(), nroLinea, 10);

	VerificarConsultaLinea(obtenido, esperado, texto.DarFormato(nroLinea));

	CerrarSeccion();
}

void CasoDePrueba::PruebaOKConsultaEstacion()
{
	IniciarSeccion("Consulta Estacion");
	Puntero<ISistema> interfaz = InicializarSistema();
	Cadena comentario = "Se consulta la estación {0}";

	ignorarOK = true;
	InicializarEstacion(interfaz);
	ignorarOK = false;
	Tupla<TipoRetorno, pEstacion> esperado;
	Tupla<TipoRetorno, pEstacion> obtenido;

	//Prueba 1
	obtenido = interfaz->ConsultaEstacion("Atocha");
	esperado = Tupla<TipoRetorno, pEstacion>(OK, ObtenerEstacionesDelSistema()[0]);

	VerificarConsultaEstacion(obtenido, esperado, "Comentario");
	

	//Prueba 2
	obtenido = interfaz->ConsultaEstacion("Callao");
	esperado = Tupla<TipoRetorno, pEstacion>(OK, ObtenerEstacionesDelSistema()[4]);

	VerificarConsultaEstacion(obtenido, esperado, "Comentario");
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKListadoEstaciones()
{
	IniciarSeccion("Listado Estaciones");
	Puntero<ISistema> interfaz = InicializarSistema();

	ignorarOK = true;
	Verificar(interfaz->IngresoEstacion("Berna", 10, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Campamento", 10, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Atocha", 10, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Mirasierra", 10, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Vicálvaro", 10, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Avenida de América", 10, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Quevedo", 10, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Callao", 10, 20), OK, "");
	ignorarOK = false;


	Array<pEstacion> estaciones = Array<pEstacion>(8);
	estaciones[0] = new EstacionMock("Atocha", 10, 20);
	estaciones[1] = new EstacionMock("Avenida de América", 10, 20);
	estaciones[2] = new EstacionMock("Berna", 10, 20);
	estaciones[3] = new EstacionMock("Callao", 10, 20);
	estaciones[4] = new EstacionMock("Campamento", 10, 20);
	estaciones[5] = new EstacionMock("Mirasierra", 10, 20);
	estaciones[6] = new EstacionMock("Quevedo", 10, 20);
	estaciones[7] = new EstacionMock("Vicálvaro", 10, 20);

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	
	obtenido = interfaz->ListadoEstaciones();
	esperado = Tupla<TipoRetorno, Iterador<pEstacion>>(OK, estaciones.ObtenerIterador());

	VerificarListadoEstaciones(obtenido, esperado, "Se listan las estaciones ordenadas por nombre.");
	
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKEstacionMasLineasHabilitadas()
{
	IniciarSeccion("Estacion Mas Lineas Habilitadas");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, pEstacion> esperado;
	Tupla<TipoRetorno, pEstacion> obtenido;

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);
	Cadena masHabilitadas = " Se verifica la estacion con mas lineas habilitadas : {0}";
	char nroLinea[8]; 

	obtenido = interfaz->EstacionMasLineasHabilitadas();
	esperado = Tupla<TipoRetorno, pEstacion>(OK, estaciones[2]);

	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, masHabilitadas.DarFormato(estaciones[2]->ObtenerNombre()));

	ignorarOK = true;

	Array<Tupla<pEstacion, nat, nat, nat>> tramos;
	
	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(2);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[22], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[9], 100, 8, 30);

	Puntero<LineaMock> linea = new LineaMock(11, 20, tramos.ObtenerIterador());	
	_itoa_s(linea->ObtenerNroLinea(), nroLinea, 10);	
	Verificar(interfaz->IngresoLinea(linea->ObtenerNroLinea(), linea->ObtenerPrecio(), linea->ObtenerEstaciones().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), OK, "se da de alta la linea");

	linea = new LineaMock(12, 20, tramos.ObtenerIterador());
	_itoa_s(linea->ObtenerNroLinea(), nroLinea, 10);	
	Verificar(interfaz->IngresoLinea(linea->ObtenerNroLinea(), linea->ObtenerPrecio(), linea->ObtenerEstaciones().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), OK, "se da de alta la linea");

	linea = new LineaMock(13, 20, tramos.ObtenerIterador());
	_itoa_s(linea->ObtenerNroLinea(), nroLinea, 10);	
	Verificar(interfaz->IngresoLinea(linea->ObtenerNroLinea(), linea->ObtenerPrecio(), linea->ObtenerEstaciones().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), OK, "se da de alta la linea");

	linea = new LineaMock(14, 20, tramos.ObtenerIterador());
	_itoa_s(linea->ObtenerNroLinea(), nroLinea, 10);	
	Verificar(interfaz->IngresoLinea(linea->ObtenerNroLinea(), linea->ObtenerPrecio(), linea->ObtenerEstaciones().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), OK, "se da de alta la linea");

	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[11], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[17], 100, 8, 30);

	linea = new LineaMock(15, 20, tramos.ObtenerIterador());	
	_itoa_s(linea->ObtenerNroLinea(), nroLinea, 10);	
	Verificar(interfaz->IngresoLinea(linea->ObtenerNroLinea(), linea->ObtenerPrecio(), linea->ObtenerEstaciones().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), OK, "se da de alta la linea");

	ignorarOK = false;

	obtenido = interfaz->EstacionMasLineasHabilitadas();
	esperado = Tupla<TipoRetorno, pEstacion>(OK, estaciones[22]);
	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, masHabilitadas.DarFormato(estaciones[22]->ObtenerNombre()));

	Cadena habilitar = " Se habilita el tramo {0} - {1} perteneciente a la linea {2}";
	Cadena inhabilitar = " Se inhabilita el tramo {0} - {1} perteneciente a la linea {2}";
	
	Verificar(interfaz->HabilitacionTramo(19, estaciones[22]->ObtenerNombre(), estaciones[9]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("19", estaciones[22]->ObtenerNombre(), estaciones[9]->ObtenerNombre()));
	Verificar(interfaz->HabilitacionTramo(8, estaciones[1]->ObtenerNombre(), estaciones[8]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("8", estaciones[1]->ObtenerNombre(), estaciones[8]->ObtenerNombre()));

	obtenido = interfaz->EstacionMasLineasHabilitadas();
	esperado = Tupla<TipoRetorno, pEstacion>(OK, estaciones[11]);
	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, masHabilitadas.DarFormato(estaciones[11]->ObtenerNombre()));

	Verificar(interfaz->HabilitacionTramo(7, estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("7", estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre()));

	obtenido = interfaz->EstacionMasLineasHabilitadas();
	esperado = Tupla<TipoRetorno, pEstacion>(OK, estaciones[22]);
	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, masHabilitadas.DarFormato(estaciones[22]->ObtenerNombre()));

	Verificar(interfaz->HabilitacionTramo(7, estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre(), true), OK, habilitar.DarFormato("7", estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre()));

	obtenido = interfaz->EstacionMasLineasHabilitadas();
	esperado = Tupla<TipoRetorno, pEstacion>(OK, estaciones[11]);
	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, masHabilitadas.DarFormato(estaciones[11]->ObtenerNombre()));

	Verificar(interfaz->HabilitacionTramo(19, estaciones[22]->ObtenerNombre(), estaciones[9]->ObtenerNombre(), true), OK, habilitar.DarFormato("19", estaciones[22]->ObtenerNombre(), estaciones[9]->ObtenerNombre()));

	obtenido = interfaz->EstacionMasLineasHabilitadas();
	esperado = Tupla<TipoRetorno, pEstacion>(OK, estaciones[22]);
	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, masHabilitadas.DarFormato(estaciones[22]->ObtenerNombre()));

	CerrarSeccion();
}

void CasoDePrueba::PruebaOKListadoEstacionesHorario()
{
	IniciarSeccion("Listado Estaciones Horario");
	Puntero<ISistema> interfaz = InicializarSistema();

	ignorarOK = true;
	Verificar(interfaz->IngresoEstacion("Berna", 1, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Campamento", 5, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Atocha", 3, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Mirasierra", 14, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Vicálvaro", 14, 21), OK, "");
	Verificar(interfaz->IngresoEstacion("Avenida de América", 2, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Quevedo", 15, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Callao", 20, 23), OK, "");
	ignorarOK = false;

	//Se espera que a igual hora de apertura se ordene por nombre
	Array<pEstacion> estaciones = Array<pEstacion>(8);
	estaciones[0] = new EstacionMock("Berna", 1, 20);
	estaciones[1] = new EstacionMock("Avenida de América", 2, 20);
	estaciones[2] = new EstacionMock("Atocha", 3, 20);
	estaciones[3] = new EstacionMock("Campamento", 5, 20);
	estaciones[4] = new EstacionMock("Mirasierra", 14, 20);
	estaciones[5] = new EstacionMock("Vicálvaro", 14, 21);
	estaciones[6] = new EstacionMock("Quevedo", 15, 20);
	estaciones[7] = new EstacionMock("Callao", 20, 23);

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	
	obtenido = interfaz->ListadoEstacionesHorario();
	esperado = Tupla<TipoRetorno, Iterador<pEstacion>>(OK, estaciones.ObtenerIterador());

	VerificarListadoEstacionesHorario(obtenido, esperado, "Se listan las estaciones por horario de apertura.");
	
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKTrayectoMenorDistancia()
{
	IniciarSeccion("Trayecto Menor Distancia");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	ignorarOK = true;
	
	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(0);
	Cadena ingreso = " Se ingresa la estacion {0}";
	foreach (estacion, estaciones)
		Verificar(interfaz->IngresoEstacion(estacion->ObtenerNombre(), estacion->ObtenerHAbre(), estacion->ObtenerHCierra()), OK, ingreso.DarFormato(estacion->ObtenerNombre()));
	
	//Se crean algunas lineas mas simples para poder probar
	//Linea 1 		
	Array<Tupla<Cadena, nat, nat, nat>> tramos;	
	tramos = Array<Tupla<Cadena, nat, nat, nat>>(5);
	tramos[0] = Tupla<Cadena, nat, nat, nat>(estaciones[1]->ObtenerNombre(), 0, 0, 0);
	tramos[1] = Tupla<Cadena, nat, nat, nat>(estaciones[2]->ObtenerNombre(), 100, 8, 30);
	tramos[2] = Tupla<Cadena, nat, nat, nat>(estaciones[3]->ObtenerNombre(), 50, 8, 30);
	tramos[3] = Tupla<Cadena, nat, nat, nat>(estaciones[4]->ObtenerNombre(), 150, 20, 50);
	tramos[4] = Tupla<Cadena, nat, nat, nat>(estaciones[5]->ObtenerNombre(), 50, 10, 10);
	interfaz->IngresoLinea(1, 1, tramos.ObtenerIterador());

	//Linea 2
	tramos = Array<Tupla<Cadena, nat, nat, nat>>(4);
	tramos[0] = Tupla<Cadena, nat, nat, nat>(estaciones[2]->ObtenerNombre(), 0, 0, 0);
	tramos[1] = Tupla<Cadena, nat, nat, nat>(estaciones[3]->ObtenerNombre(), 100, 8, 30);
	tramos[2] = Tupla<Cadena, nat, nat, nat>(estaciones[6]->ObtenerNombre(), 50, 8, 30);
	tramos[3] = Tupla<Cadena, nat, nat, nat>(estaciones[5]->ObtenerNombre(), 90, 20, 50);

	interfaz->IngresoLinea(2, 1, tramos.ObtenerIterador());

	//Linea 3
	tramos = Array<Tupla<Cadena, nat, nat, nat>>(4);
	tramos[0] = Tupla<Cadena, nat, nat, nat>(estaciones[3]->ObtenerNombre(), 0, 0, 0);
	tramos[1] = Tupla<Cadena, nat, nat, nat>(estaciones[6]->ObtenerNombre(), 100, 8, 30);
	tramos[2] = Tupla<Cadena, nat, nat, nat>(estaciones[7]->ObtenerNombre(), 25, 8, 30);
	tramos[3] = Tupla<Cadena, nat, nat, nat>(estaciones[5]->ObtenerNombre(), 50, 20, 50);

	interfaz->IngresoLinea(3, 1, tramos.ObtenerIterador());

	ignorarOK = false;

	//PRUEBA 1
	//Entre estaciones[1] y estaciones [5]
	//con las lineas ingresadas el camino de menor distancia debería ser 1-2-3-6-7-5 
	//la suma de distancias da 275. Pero a la hora 19 la estacion 6 está cerrada
	//Entonces la más corta es 1-2-3-4-5

	//array de resultado esperado
	Array<pEstacion> estacionesEsperadas = Array<pEstacion>(5);	
	estacionesEsperadas[0] = estaciones[1];
	estacionesEsperadas[1] = estaciones[2];
	estacionesEsperadas[2] = estaciones[3];
	estacionesEsperadas[3] = estaciones[4];
	estacionesEsperadas[4] = estaciones[5];
	
	obtenido = interfaz->TrayectoMenorDistancia(estaciones[1]->ObtenerNombre(), estaciones[5]->ObtenerNombre(), 19);
	esperado = Tupla<TipoRetorno, Iterador<pEstacion>>(OK, estacionesEsperadas.ObtenerIterador());

	VerificarTrayectoMenorDistancia(obtenido, esperado, "Se compara el trayecto de menor distancia esperado con el obtenido. ");	

	//PRUEBA 2
	//Prueba mas simple que la anterior, solo para probar más casos. Entre 2 y 4. El mas corto
	//debería ser 2-3-4 con una distancia total de 200.
	estacionesEsperadas = Array<pEstacion>(3);	
	estacionesEsperadas[0] = estaciones[2];
	estacionesEsperadas[1] = estaciones[3];
	estacionesEsperadas[2] = estaciones[4];
	obtenido = interfaz->TrayectoMenorDistancia(estaciones[2]->ObtenerNombre(), estaciones[4]->ObtenerNombre(), 19);
	esperado = Tupla<TipoRetorno, Iterador<pEstacion>>(OK, estacionesEsperadas.ObtenerIterador());

	VerificarTrayectoMenorDistancia(obtenido, esperado, "Se compara el trayecto de menor distancia esperado con el obtenido. ");

	CerrarSeccion();
}

void CasoDePrueba::PruebaOKCableadoMenorDistancia()
{
	IniciarSeccion("Cableado Menor Distancia");
	Puntero<ISistema> interfaz = InicializarSistema();
	
	ignorarOK = true;
	//InicializarEstacion(interfaz);	

	Array<pLinea> lineas = Array<pLinea>(3);
	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);
	Array<pEstacion> estaciones2(9);
	estaciones2[0] = estaciones[0];
	estaciones2[1] = estaciones[1];
	estaciones2[2] = estaciones[2];
	estaciones2[3] = estaciones[3];
	estaciones2[4] = estaciones[4];
	estaciones2[5] = estaciones[5];
	estaciones2[6] = estaciones[6];
	estaciones2[7] = estaciones[7];
	estaciones2[8] = estaciones[9];

	Cadena ingresoE = " Se ingresa la estacion {0}";
	foreach (estacion, estaciones2)
		Verificar(interfaz->IngresoEstacion(estacion->ObtenerNombre(), estacion->ObtenerHAbre(), estacion->ObtenerHCierra()), OK, ingresoE.DarFormato(estacion->ObtenerNombre()));
	
	Array<Tupla<pEstacion, nat, nat, nat>> tramos;
	
	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(5);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[1], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[2], 100, 8, 30);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[3], 245, 8, 30);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[4], 150, 20, 50);
	tramos[4] = Tupla<pEstacion, nat, nat, nat>(estaciones[5], 50, 10, 10);
	lineas[0] = new LineaMock(8, 20, tramos.ObtenerIterador());

	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(5);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[0], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[2], 50, 50, 15);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[3], 20, 20, 10);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[4], 100, 7, 10);
	tramos[4] = Tupla<pEstacion, nat, nat, nat>(estaciones[7], 100, 10, 10);
	lineas[1] = new LineaMock(10, 100, tramos.ObtenerIterador());

	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(5);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[6], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[9], 50, 50, 15);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[2], 10, 20, 10);
	tramos[3] = Tupla<pEstacion, nat, nat, nat>(estaciones[4], 15, 7, 10);
	tramos[4] = Tupla<pEstacion, nat, nat, nat>(estaciones[7], 10, 10, 10);
	lineas[2] = new LineaMock(11, 100, tramos.ObtenerIterador());

	Cadena ingreso = " Se ingresa la linea {0}";

	foreach (linea, lineas)
	{
		char nroLinea[8]; 
		_itoa_s(linea->ObtenerNroLinea(), nroLinea, 10);

		Verificar(interfaz->IngresoLinea(linea->ObtenerNroLinea(), linea->ObtenerPrecio(), linea->ObtenerEstaciones().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), OK, ingreso.DarFormato(nroLinea));
	}
	ignorarOK = false;

	Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> esperado;
	Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> obtenido;

	Array<Tupla<pEstacion, pEstacion, nat>> tramosEsperados;

	tramosEsperados = Array<Tupla<pEstacion, pEstacion, nat>>(8);
	tramosEsperados[0] = Tupla<pEstacion, pEstacion, nat>(estaciones[0], estaciones[2], 50);
	tramosEsperados[1] = Tupla<pEstacion, pEstacion, nat>(estaciones[1], estaciones[2], 100);
	tramosEsperados[2] = Tupla<pEstacion, pEstacion, nat>(estaciones[9], estaciones[2], 10);
	tramosEsperados[3] = Tupla<pEstacion, pEstacion, nat>(estaciones[3], estaciones[2], 20);
	tramosEsperados[4] = Tupla<pEstacion, pEstacion, nat>(estaciones[9], estaciones[6], 50);
	tramosEsperados[5] = Tupla<pEstacion, pEstacion, nat>(estaciones[4], estaciones[2], 15);
	tramosEsperados[6] = Tupla<pEstacion, pEstacion, nat>(estaciones[7], estaciones[4], 10);
	tramosEsperados[7] = Tupla<pEstacion, pEstacion, nat>(estaciones[4], estaciones[5], 50);

	obtenido = interfaz->CableadoMenorDistancia();
	esperado = Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>>(OK, tramosEsperados.ObtenerIterador());

	VerificarCableadoMenorDistancia(obtenido, esperado, "Se verifia el cableado de menor distancia. ");

	CerrarSeccion();
}

void CasoDePrueba::PruebaOKListadoTrayecto()
{
	IniciarSeccion("Listado Trayecto");
	Puntero<ISistema> interfaz = InicializarSistema();
	
	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;
	
	Array<pEstacion> resultado;
	Array<Cadena> trayecto;

	trayecto = Array<Cadena>(3);
	trayecto[0] = estaciones[0]->ObtenerNombre();
	trayecto[1] = estaciones[2]->ObtenerNombre();
	trayecto[2] = estaciones[17]->ObtenerNombre();

	resultado = Array<pEstacion>(6);
	resultado[0] = estaciones[0];
	resultado[1] = estaciones[11];
	resultado[2] = estaciones[21];
	resultado[3] = estaciones[2];
	resultado[4] = estaciones[11];
	resultado[5] = estaciones[17];
	
	obtenido = interfaz->ListadoTrayecto(trayecto.ObtenerIterador());
	esperado =  Tupla<TipoRetorno, Iterador<pEstacion>>(OK, resultado.ObtenerIterador());

	VerificarListadoTrayecto(obtenido, esperado, "Se comprueba el Listado Trayecto 1");


	trayecto = Array<Cadena>(4);
	trayecto[0] = estaciones[13]->ObtenerNombre();
	trayecto[1] = estaciones[7]->ObtenerNombre();
	trayecto[2] = estaciones[11]->ObtenerNombre();
	trayecto[3] = estaciones[1]->ObtenerNombre();

	resultado = Array<pEstacion>(11);
	resultado[0] = estaciones[13];
	resultado[1] = estaciones[6];
	resultado[2] = estaciones[2];
	resultado[3] = estaciones[7];
	resultado[4] = estaciones[2];
	resultado[5] = estaciones[11];
	resultado[6] = estaciones[21];
	resultado[7] = estaciones[2];
	resultado[8] = estaciones[18];
	resultado[9] = estaciones[15];
	resultado[10] = estaciones[1];
	
	obtenido = interfaz->ListadoTrayecto(trayecto.ObtenerIterador());
	esperado =  Tupla<TipoRetorno, Iterador<pEstacion>>(OK, resultado.ObtenerIterador());

	VerificarListadoTrayecto(obtenido, esperado, "Se comprueba el Listado Trayecto 2");
	

	Cadena inhabilitar = " Se inhabilita el tramo {0} - {1} perteneciente a la linea {2}";
	
	ignorarOK = true;
	Verificar(interfaz->HabilitacionTramo(5, estaciones[6]->ObtenerNombre(), estaciones[2]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("5", estaciones[6]->ObtenerNombre(), estaciones[2]->ObtenerNombre()));
	Verificar(interfaz->HabilitacionTramo(2, estaciones[15]->ObtenerNombre(), estaciones[1]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("2", estaciones[15]->ObtenerNombre(), estaciones[1]->ObtenerNombre()));
	ignorarOK = false;

	resultado = Array<pEstacion>(8);
	resultado[0] = estaciones[13];
	resultado[1] = estaciones[7];
	resultado[2] = estaciones[2];
	resultado[3] = estaciones[11];
	resultado[4] = estaciones[21];
	resultado[5] = estaciones[2];
	resultado[6] = estaciones[18];
	resultado[7] = estaciones[1];
	
	obtenido = interfaz->ListadoTrayecto(trayecto.ObtenerIterador());
	esperado =  Tupla<TipoRetorno, Iterador<pEstacion>>(OK, resultado.ObtenerIterador());

	VerificarListadoTrayecto(obtenido, esperado, "Se comprueba el Listado Trayecto 3");


	trayecto = Array<Cadena>(3);
	trayecto[0] = estaciones[0]->ObtenerNombre();
	trayecto[1] = estaciones[11]->ObtenerNombre();
	trayecto[2] = estaciones[17]->ObtenerNombre();

	resultado = Array<pEstacion>(3);
	resultado[0] = estaciones[0];
	resultado[1] = estaciones[11];
	resultado[2] = estaciones[17];
	
	obtenido = interfaz->ListadoTrayecto(trayecto.ObtenerIterador());
	esperado =  Tupla<TipoRetorno, Iterador<pEstacion>>(OK, resultado.ObtenerIterador());

	VerificarListadoTrayecto(obtenido, esperado, "Se comprueba el Listado Trayecto 4");

		
	ignorarOK = true;
	Verificar(interfaz->HabilitacionTramo(2, estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre(), false), OK, inhabilitar.DarFormato("2", estaciones[11]->ObtenerNombre(), estaciones[17]->ObtenerNombre()));
	ignorarOK = false;

	trayecto = Array<Cadena>(3);
	trayecto[0] = estaciones[0]->ObtenerNombre();
	trayecto[1] = estaciones[11]->ObtenerNombre();
	trayecto[2] = estaciones[17]->ObtenerNombre();

	resultado = Array<pEstacion>(3);
	resultado[0] = estaciones[0];
	resultado[1] = estaciones[11];
	resultado[2] = estaciones[17];
	
	obtenido = interfaz->ListadoTrayecto(trayecto.ObtenerIterador());
	esperado =  Tupla<TipoRetorno, Iterador<pEstacion>>(OK, resultado.ObtenerIterador());

	VerificarListadoTrayecto(obtenido, esperado, "Se comprueba el Listado Trayecto 5");

	CerrarSeccion();
}

void CasoDePrueba::PruebaOKListadoTodosLosTrayectos()
{
	IniciarSeccion("Listado Todos Los Trayectos");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> esperado;
	Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> obtenido;

	
	ignorarOK = true;
	InicializarEstacion(interfaz);	
	
	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);
	//Se crean algunas lineas mas simples para poder probar
	//Linea 1 		
	Array<Tupla<Cadena, nat, nat, nat>> tramos;	
	tramos = Array<Tupla<Cadena, nat, nat, nat>>(5);
	tramos[0] = Tupla<Cadena, nat, nat, nat>(estaciones[1]->ObtenerNombre(), 0, 0, 0);
	tramos[1] = Tupla<Cadena, nat, nat, nat>(estaciones[2]->ObtenerNombre(), 100, 8, 30);
	tramos[2] = Tupla<Cadena, nat, nat, nat>(estaciones[3]->ObtenerNombre(), 50, 8, 30);
	tramos[3] = Tupla<Cadena, nat, nat, nat>(estaciones[4]->ObtenerNombre(), 150, 20, 50);
	tramos[4] = Tupla<Cadena, nat, nat, nat>(estaciones[5]->ObtenerNombre(), 50, 10, 10);
	interfaz->IngresoLinea(1, 1, tramos.ObtenerIterador());

	//Linea 2
	tramos = Array<Tupla<Cadena, nat, nat, nat>>(4);
	tramos[0] = Tupla<Cadena, nat, nat, nat>(estaciones[2]->ObtenerNombre(), 0, 0, 0);
	tramos[1] = Tupla<Cadena, nat, nat, nat>(estaciones[3]->ObtenerNombre(), 100, 8, 30);
	tramos[2] = Tupla<Cadena, nat, nat, nat>(estaciones[6]->ObtenerNombre(), 50, 8, 30);
	tramos[3] = Tupla<Cadena, nat, nat, nat>(estaciones[5]->ObtenerNombre(), 90, 20, 50);

	interfaz->IngresoLinea(2, 1, tramos.ObtenerIterador());

	//Linea 3
	tramos = Array<Tupla<Cadena, nat, nat, nat>>(4);
	tramos[0] = Tupla<Cadena, nat, nat, nat>(estaciones[3]->ObtenerNombre(), 0, 0, 0);
	tramos[1] = Tupla<Cadena, nat, nat, nat>(estaciones[6]->ObtenerNombre(), 100, 8, 30);
	tramos[2] = Tupla<Cadena, nat, nat, nat>(estaciones[7]->ObtenerNombre(), 25, 8, 30);
	tramos[3] = Tupla<Cadena, nat, nat, nat>(estaciones[5]->ObtenerNombre(), 50, 20, 50);

	interfaz->IngresoLinea(3, 1, tramos.ObtenerIterador());

	ignorarOK = false;

	//Trayecto 1
	Array<pEstacion> trayecto1 = Array<pEstacion>(5);
	trayecto1[0] = estaciones[1];
	trayecto1[1] = estaciones[2];
	trayecto1[2] = estaciones[3]; 
	trayecto1[3] = estaciones[4];
	trayecto1[4] = estaciones[5];
	//Trayecto 2
	Array<pEstacion> trayecto2 = Array<pEstacion>(5);
	trayecto2[0] = estaciones[1];
	trayecto2[1] = estaciones[2];
	trayecto2[2] = estaciones[3]; 
	trayecto2[3] = estaciones[6];
	trayecto2[4] = estaciones[5];
	//Trayecto 3
	Array<pEstacion> trayecto3 = Array<pEstacion>(6);
	trayecto3[0] = estaciones[1];
	trayecto3[1] = estaciones[2];
	trayecto3[2] = estaciones[3]; 
	trayecto3[3] = estaciones[6];
	trayecto3[4] = estaciones[7];
	trayecto3[5] = estaciones[5];

	//Iterador de trayectos
	Array<Iterador<pEstacion>> trayectos = Array<Iterador<pEstacion>>(3);
	trayectos[0] = trayecto1.ObtenerIterador();
	trayectos[1] = trayecto2.ObtenerIterador();
	trayectos[2] = trayecto3.ObtenerIterador();
    obtenido = interfaz->ListadoTodosLosTrayectos(estaciones[1]->ObtenerNombre(), estaciones[5]->ObtenerNombre());
	esperado = Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>>(OK, trayectos.ObtenerIterador());

	VerificarListadoTodosLosTrayectos(obtenido, esperado, "Se verifican todos los trayectos");
	
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKTrayectoMenosTransbordos()
{
	IniciarSeccion("Trayecto Menos Transbordos");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;
	
	ignorarOK = true;
	InicializarEstacion(interfaz);	
	
	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);
	//Se crean algunas lineas mas simples para poder probar
	//Linea 1 		
	Array<Tupla<Cadena, nat, nat, nat>> tramos;	
	tramos = Array<Tupla<Cadena, nat, nat, nat>>(5);
	tramos[0] = Tupla<Cadena, nat, nat, nat>(estaciones[1]->ObtenerNombre(), 0, 0, 0);
	tramos[1] = Tupla<Cadena, nat, nat, nat>(estaciones[2]->ObtenerNombre(), 100, 8, 30);
	tramos[2] = Tupla<Cadena, nat, nat, nat>(estaciones[3]->ObtenerNombre(), 50, 8, 30);
	tramos[3] = Tupla<Cadena, nat, nat, nat>(estaciones[4]->ObtenerNombre(), 150, 20, 50);
	tramos[4] = Tupla<Cadena, nat, nat, nat>(estaciones[6]->ObtenerNombre(), 50, 10, 10);
	interfaz->IngresoLinea(1, 1, tramos.ObtenerIterador());

	//Linea 2
	tramos = Array<Tupla<Cadena, nat, nat, nat>>(3);
	tramos[0] = Tupla<Cadena, nat, nat, nat>(estaciones[3]->ObtenerNombre(), 0, 0, 0);
	tramos[1] = Tupla<Cadena, nat, nat, nat>(estaciones[6]->ObtenerNombre(), 50, 8, 30);
	tramos[2] = Tupla<Cadena, nat, nat, nat>(estaciones[5]->ObtenerNombre(), 90, 20, 50);

	interfaz->IngresoLinea(2, 1, tramos.ObtenerIterador());

	//Linea 3
	tramos = Array<Tupla<Cadena, nat, nat, nat>>(4);
	tramos[0] = Tupla<Cadena, nat, nat, nat>(estaciones[3]->ObtenerNombre(), 0, 0, 0);
	tramos[1] = Tupla<Cadena, nat, nat, nat>(estaciones[6]->ObtenerNombre(), 50, 8, 30);
	tramos[2] = Tupla<Cadena, nat, nat, nat>(estaciones[7]->ObtenerNombre(), 25, 8, 30);
	tramos[3] = Tupla<Cadena, nat, nat, nat>(estaciones[5]->ObtenerNombre(), 50, 20, 50);
	interfaz->IngresoLinea(3, 1, tramos.ObtenerIterador());
	ignorarOK = false;

	//PRUEBA 1
	//Hay dos trayectos con 1 transbordo (lo menor posible en este caso) para llegar de 1 a 5.
	// (1-2-3-6-5, usando lineas 1 y 2) y (1-2-3-6-7-5, usando lineas 1 y 3), pero el segundo
	// trayecto tiene menor distancia, 275, y el primero 290


	Array<pEstacion> estacionesEsperadas = Array<pEstacion>(6);
	estacionesEsperadas[0] = estaciones[1];
	estacionesEsperadas[1] = estaciones[2];
	estacionesEsperadas[2] = estaciones[3];
	estacionesEsperadas[3] = estaciones[6];
	estacionesEsperadas[4] = estaciones[7];
	estacionesEsperadas[5] = estaciones[5];
	obtenido = interfaz->TrayectoMenosTransbordos(estaciones[1]->ObtenerNombre(), estaciones[5]->ObtenerNombre());
	esperado = Tupla<TipoRetorno, Iterador<pEstacion>>(OK, estacionesEsperadas.ObtenerIterador());
	VerificarTrayectoMenosTransbordos(obtenido, esperado, "Se verifica el trayecto de menos trabordos");
    

	//PRUEBA 2
	//Ahora va a haber un trayecto con 0 transbordos (una linea entera)
	ignorarOK = true;
	tramos = Array<Tupla<Cadena, nat, nat, nat>>(4);
	tramos[0] = Tupla<Cadena, nat, nat, nat>(estaciones[1]->ObtenerNombre(), 0, 0, 0);
	tramos[1] = Tupla<Cadena, nat, nat, nat>(estaciones[3]->ObtenerNombre(), 100, 4, 23);
	tramos[2] = Tupla<Cadena, nat, nat, nat>(estaciones[7]->ObtenerNombre(), 250, 4, 23);
	tramos[3] = Tupla<Cadena, nat, nat, nat>(estaciones[5]->ObtenerNombre(), 300, 8, 23);
	interfaz->IngresoLinea(4, 1, tramos.ObtenerIterador());
	ignorarOK = false;

	estacionesEsperadas = Array<pEstacion>(4);
	estacionesEsperadas[0] = estaciones[1];
	estacionesEsperadas[1] = estaciones[3];
	estacionesEsperadas[2] = estaciones[7];
	estacionesEsperadas[3] = estaciones[5];

	obtenido = interfaz->TrayectoMenosTransbordos(estaciones[1]->ObtenerNombre(), estaciones[5]->ObtenerNombre());
	esperado = Tupla<TipoRetorno, Iterador<pEstacion>>(OK, estacionesEsperadas.ObtenerIterador());
	VerificarTrayectoMenosTransbordos(obtenido, esperado, "Se verifica el trayecto de menos trabordos");

	CerrarSeccion();
}

void CasoDePrueba::PruebaOKCantidadMaxima()
{
	IniciarSeccion("Cantidad Maxima");
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, nat> esperado;
	Tupla<TipoRetorno, nat> obtenido;

	ignorarOK = true;
	InicializarEstacion(interfaz);		
	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);
	//Se crean algunas lineas mas simples para poder probar
	//Linea 1 		
	Array<Tupla<Cadena, nat, nat, nat>> tramos;	
	tramos = Array<Tupla<Cadena, nat, nat, nat>>(5);
	tramos[0] = Tupla<Cadena, nat, nat, nat>(estaciones[1]->ObtenerNombre(), 0, 0, 0);
	tramos[1] = Tupla<Cadena, nat, nat, nat>(estaciones[2]->ObtenerNombre(), 100, 8, 30);
	tramos[2] = Tupla<Cadena, nat, nat, nat>(estaciones[3]->ObtenerNombre(), 50, 8, 30);
	tramos[3] = Tupla<Cadena, nat, nat, nat>(estaciones[4]->ObtenerNombre(), 150, 20, 50);
	tramos[4] = Tupla<Cadena, nat, nat, nat>(estaciones[6]->ObtenerNombre(), 50, 10, 10);
	interfaz->IngresoLinea(1, 1, tramos.ObtenerIterador());

	//Linea 2
	tramos = Array<Tupla<Cadena, nat, nat, nat>>(3);
	tramos[0] = Tupla<Cadena, nat, nat, nat>(estaciones[3]->ObtenerNombre(), 0, 0, 0);
	tramos[1] = Tupla<Cadena, nat, nat, nat>(estaciones[6]->ObtenerNombre(), 50, 8, 30);
	tramos[2] = Tupla<Cadena, nat, nat, nat>(estaciones[5]->ObtenerNombre(), 90, 20, 50);
	interfaz->IngresoLinea(2, 1, tramos.ObtenerIterador());

	//Linea 3
	tramos = Array<Tupla<Cadena, nat, nat, nat>>(3);
	tramos[0] = Tupla<Cadena, nat, nat, nat>(estaciones[3]->ObtenerNombre(), 0, 0, 0);
	tramos[1] = Tupla<Cadena, nat, nat, nat>(estaciones[6]->ObtenerNombre(), 50, 5, 30);
	tramos[2] = Tupla<Cadena, nat, nat, nat>(estaciones[7]->ObtenerNombre(), 25, 15, 30);
	interfaz->IngresoLinea(3, 1, tramos.ObtenerIterador());

	ignorarOK = false;

	//PRUEBA 1 
	//Entre 1 y 5. Se espera un maximo de densidad de 8
	
	obtenido = interfaz->CantidadMaxima(estaciones[1]->ObtenerNombre() , estaciones[5]->ObtenerNombre());
	esperado = Tupla<TipoRetorno, nat>(OK, 8);

	VerificarCantidadMaxima(obtenido, esperado, "Se verifica la máxima densidad. Se espera una densidad máxima de 8.");
	

	//PRUEBA 2
	//Entre 3 y 7. Se espera un maximo de densidad de 15, ya que se puede pasar de 3 a 6 por tres caminos, 
	//uno con densidad 8, otro con 5 (esos dos directos 3-6), y otro 3-4-6 que tiene una densidad de 20, lo que suma 33.
	//Pero luego de 6 hasta 7 entran 15, lo que hace que la densidad maxima sea 15.
	obtenido = interfaz->CantidadMaxima(estaciones[3]->ObtenerNombre() , estaciones[7]->ObtenerNombre());
	esperado = Tupla<TipoRetorno, nat>(OK, 15);

	VerificarCantidadMaxima(obtenido, esperado, "Se verifica la máxima densidad. Se espera una densidad total de 15.");
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKLineasAAbordarA()
{
	IniciarSeccion("Lineas AAbordar A");
	PruebaOKLineasAAbordar(true);
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKLineasAAbordarB()
{
	IniciarSeccion("Lineas AAbordar B");
	PruebaOKLineasAAbordar(false);
	CerrarSeccion();
}

void CasoDePrueba::PruebaOKLineasAAbordar(bool esA)
{
	Puntero<ISistema> interfaz = InicializarSistema();

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pLinea> lineas = ObtenerLineasDelSistema();
	/*
	Linea - distancia - precio
	8	-	350	-	20
	10	-	85	-	100
	5	-	160	-	50
	19	-	105	-	90
	1	-	225	-	50
	2	-	940	-	120
	7	-	890	-	110
	*/

	Tupla<TipoRetorno, nat, Iterador<pLinea>> esperado;
	Tupla<TipoRetorno, nat, Iterador<pLinea>> obtenido;
	Array<pLinea> seleccionadas;

	seleccionadas = Array<pLinea>(1);
	seleccionadas[0] = lineas[0];
	esperado = Tupla<TipoRetorno, nat, Iterador<pLinea>>(OK, 350, seleccionadas.ObtenerIterador());
	if(esA)
		obtenido = interfaz->LineasAAbordarA(30);
	else
		obtenido = interfaz->LineasAAbordarB(30);

	VerificarLineasAAbordar(obtenido, esperado, "Se verifican las lineas a abordar 1");

	seleccionadas = Array<pLinea>(1);
	seleccionadas[0] = lineas[0];
	esperado = Tupla<TipoRetorno, nat, Iterador<pLinea>>(OK, 350, seleccionadas.ObtenerIterador());
	if(esA)
		obtenido = interfaz->LineasAAbordarA(50);
	else
		obtenido = interfaz->LineasAAbordarB(50);

	VerificarLineasAAbordar(obtenido, esperado, "Se verifican las lineas a abordar 2");

	seleccionadas = Array<pLinea>(2);
	seleccionadas[0] = lineas[0];
	seleccionadas[1] = lineas[4];
	esperado = Tupla<TipoRetorno, nat, Iterador<pLinea>>(OK, 575, seleccionadas.ObtenerIterador());
	if(esA)
		obtenido = interfaz->LineasAAbordarA(100);
	else
		obtenido = interfaz->LineasAAbordarB(100);

	VerificarLineasAAbordar(obtenido, esperado, "Se verifican las lineas a abordar 3");

	seleccionadas = Array<pLinea>(1);
	seleccionadas[0] = lineas[5];
	esperado = Tupla<TipoRetorno, nat, Iterador<pLinea>>(OK, 940, seleccionadas.ObtenerIterador());
	if(esA)
		obtenido = interfaz->LineasAAbordarA(120);
	else
		obtenido = interfaz->LineasAAbordarB(120);

	VerificarLineasAAbordar(obtenido, esperado, "Se verifican las lineas a abordar 4");

	seleccionadas = Array<pLinea>(2);
	seleccionadas[0] = lineas[0];
	seleccionadas[1] = lineas[6];
	esperado = Tupla<TipoRetorno, nat, Iterador<pLinea>>(OK, 1240, seleccionadas.ObtenerIterador());
	if(esA)
		obtenido = interfaz->LineasAAbordarA(139);
	else
		obtenido = interfaz->LineasAAbordarB(139);

	VerificarLineasAAbordar(obtenido, esperado, "Se verifican las lineas a abordar 5");

	seleccionadas = Array<pLinea>(3);
	seleccionadas[0] = lineas[0];
	seleccionadas[1] = lineas[4];
	seleccionadas[2] = lineas[6];
	esperado = Tupla<TipoRetorno, nat, Iterador<pLinea>>(OK, 1465, seleccionadas.ObtenerIterador());
	if(esA)
		obtenido = interfaz->LineasAAbordarA(185);
	else
		obtenido = interfaz->LineasAAbordarB(185);

	VerificarLineasAAbordar(obtenido, esperado, "Se verifican las lineas a abordar 6");
}

void CasoDePrueba::PruebaOKEstacionesCriticas()
{
	IniciarSeccion("Estaciones Criticas");
	Puntero<ISistema> interfaz = InicializarSistema();

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;
	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);
	Array<pEstacion> resultado;

	resultado = Array<pEstacion>(1);
	resultado[0] = estaciones[4];

	obtenido = interfaz->EstacionesCriticas(estaciones[5]->ObtenerNombre(), estaciones[13]->ObtenerNombre());
	esperado = Tupla<TipoRetorno, Iterador<pEstacion>>(OK, resultado.ObtenerIterador());

	VerificarEstacionesCriticas(obtenido, esperado, "Se verifica estaciones criticas 1");

	resultado = Array<pEstacion>(2);
	resultado[0] = estaciones[4];
	resultado[1] = estaciones[13];

	obtenido = interfaz->EstacionesCriticas(estaciones[5]->ObtenerNombre(), estaciones[2]->ObtenerNombre());
	esperado = Tupla<TipoRetorno, Iterador<pEstacion>>(OK, resultado.ObtenerIterador());

	VerificarEstacionesCriticas(obtenido, esperado, "Se verifica estaciones criticas 2");

	resultado = Array<pEstacion>(5);
	resultado[0] = estaciones[4];
	resultado[1] = estaciones[13];
	resultado[2] = estaciones[2];
	resultado[3] = estaciones[18];
	resultado[4] = estaciones[1];

	obtenido = interfaz->EstacionesCriticas(estaciones[5]->ObtenerNombre(), estaciones[10]->ObtenerNombre());
	esperado = Tupla<TipoRetorno, Iterador<pEstacion>>(OK, resultado.ObtenerIterador());

	VerificarEstacionesCriticas(obtenido, esperado, "Se verifica estaciones criticas 3");

	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORIngresoEstacion()
{
	IniciarSeccion("Ingreso Estacion", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();
	ignorarOK = true;		
	Verificar(interfaz->IngresoEstacion("Berna", 1, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Campamento", 5, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Atocha", 3, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Mirasierra", 14, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Vicálvaro", 14, 21), OK, "");
	Verificar(interfaz->IngresoEstacion("Avenida de América", 2, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Quevedo", 15, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Callao", 20, 23), OK, "");
	ignorarOK = false;

	//Se verifica por mismo nombre
	Verificar(interfaz->IngresoEstacion("Berna", 2, 23), ERROR, "Se espera error por nombre ya existente.");
	//Por HAbre mayor que HCierra
	Verificar(interfaz->IngresoEstacion("Centro", 22, 21), ERROR, "Se espera error por hora abre mayor a hora cierra.");
	//Por HCierra mayor a 24
	Verificar(interfaz->IngresoEstacion("Centro", 2, 25), ERROR, "Se espera error Por HCierra mayor a 24.");
	//Por MAX_ESTACIONES
	interfaz = InicializarSistema(2,2);
	ignorarOK = true;		
	Verificar(interfaz->IngresoEstacion("Berna", 1, 20), OK, "");
	Verificar(interfaz->IngresoEstacion("Campamento", 5, 20), OK, "");
	ignorarOK = false;
	Verificar(interfaz->IngresoEstacion("Bilbao", 2, 23), ERROR, "Se espera error por MAX_ESTACIONES ya alcanzado.");

	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORIngresoLinea()
{
	IniciarSeccion("Ingreso Linea", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	ignorarOK = true;
	InicializarEstacion(interfaz);
	ignorarOK = false;

	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);
	
	Array<Tupla<pEstacion, nat, nat, nat>> tramos;
	
	tramos = Array<Tupla<pEstacion, nat, nat, nat>>(3);
	tramos[0] = Tupla<pEstacion, nat, nat, nat>(estaciones[18], 0, 0, 0);
	tramos[1] = Tupla<pEstacion, nat, nat, nat>(new EstacionMock("LaPaz", 1,2) , 100, 8, 30);
	tramos[2] = Tupla<pEstacion, nat, nat, nat>(estaciones[1], 100, 8, 30);

	Verificar(interfaz->IngresoLinea(8, 100, tramos.ObtenerIterador().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), ERROR, "Error. No existe estacion LaPaz");

	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[2] , 100, 8, 30);

	Verificar(interfaz->IngresoLinea(4000, 100, tramos.ObtenerIterador().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), ERROR, "Error. nro linea fuera de rango");

	tramos[1] = Tupla<pEstacion, nat, nat, nat>(estaciones[2] , 0, 8, 30);

	Verificar(interfaz->IngresoLinea(2, 100, tramos.ObtenerIterador().Convert<Tupla<Cadena, nat, nat, nat>, ConvertNombre>()), ERROR, "Error. Distancia es 0");

	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORHabilitacionTramo()
{
	IniciarSeccion("Habilitacion Tramo", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);
	
	Verificar(interfaz->HabilitacionTramo(84, estaciones[22]->ObtenerNombre(), estaciones[9]->ObtenerNombre(), false), ERROR, "Error. No existe la linea 84");
	Verificar(interfaz->HabilitacionTramo(8, estaciones[1]->ObtenerNombre(), "LaPaz", false), ERROR, "Error. No existe la estscion LaPaz");
	Verificar(interfaz->HabilitacionTramo(7, "LaPaz", estaciones[17]->ObtenerNombre(), false), ERROR, "Error. No existe la estscion LaPaz");

	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORConsultaLinea()
{
	IniciarSeccion("Consulta Linea", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, pLinea> esperado;
	Tupla<TipoRetorno, pLinea> obtenido;

	char nroLinea[8]; 

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	obtenido = interfaz->ConsultaLinea(125);
	esperado = Tupla<TipoRetorno, pLinea>(ERROR, NULL);

	VerificarConsultaLinea(obtenido, esperado, "No existe la line 125");

	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORConsultaEstacion()
{
	IniciarSeccion("Consulta Estacion", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, pEstacion> esperado;
	Tupla<TipoRetorno, pEstacion> obtenido;

	ignorarOK = true;
	InicializarEstacion(interfaz);	
	ignorarOK = false;
	
	obtenido = interfaz->ConsultaEstacion("Gran Estación");
	esperado = Tupla<TipoRetorno, pEstacion>(ERROR, NULL);

	VerificarConsultaEstacion(obtenido, esperado, "Se espera ERROR. La estación consultada no existe.");
	
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORListadoEstaciones()
{
	IniciarSeccion("Listado Estaciones", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;
	
	obtenido = interfaz->ListadoEstaciones();
	esperado = Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR, NULL);

	VerificarListadoEstaciones(obtenido, esperado, "Se espera ERROR. Se consulta el listado de estaciones cuando no hay ninguna ingresada.");
 
	CerrarSeccion();
}

void CasoDePrueba::PruebaERROREstacionMasLineasHabilitadas()
{
	IniciarSeccion("Estacion Mas Lineas Habilitadas", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, pEstacion> esperado = Tupla<TipoRetorno, pEstacion>(ERROR, NULL);
	Tupla<TipoRetorno, pEstacion> obtenido;

	obtenido = interfaz->EstacionMasLineasHabilitadas();
	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, "Error. No hay estaciones en el sistema");

	ignorarOK = true;
	InicializarEstacion(interfaz);
	ignorarOK = false;

	obtenido = interfaz->EstacionMasLineasHabilitadas();
	VerificarEstacionMasLineasHabilitadas(obtenido, esperado, "Error. No hay lineas en el sistema");

	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORListadoEstacionesHorario()
{
	IniciarSeccion("Listado Estaciones Horario", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado;
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

    obtenido = interfaz->ListadoEstaciones();
	esperado = Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR, NULL);

	VerificarListadoEstacionesHorario(obtenido, esperado, "Se espera ERROR. Se consulta el listado de estaciones cuando no hay ninguna ingresada.");
 
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORTrayectoMenorDistancia()
{
	IniciarSeccion("Trayecto Menor Distancia", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado(ERROR, NULL);
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);

	obtenido = interfaz->TrayectoMenorDistancia("LaPaz", estaciones[0]->ObtenerNombre(), 19);
	VerificarTrayectoMenorDistancia(obtenido, esperado, "Error. No existe estacion origen");

	obtenido = interfaz->TrayectoMenorDistancia(estaciones[0]->ObtenerNombre(), "LaPaz", 19);
	VerificarTrayectoMenorDistancia(obtenido, esperado, "Error. No existe estacion destino");

	obtenido = interfaz->TrayectoMenorDistancia(estaciones[20]->ObtenerNombre(), estaciones[16]->ObtenerNombre(), 19);
	Cadena cadena = "Error. No se puede llegar de estacion {0} a estacion {1}.";
	VerificarTrayectoMenorDistancia(obtenido, esperado, cadena.DarFormato(estaciones[20]->ObtenerNombre(), estaciones[16]->ObtenerNombre()));

	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORCableadoMenorDistancia()
{
	IniciarSeccion("Cableado Menor Distancia", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> esperado(ERROR, NULL);
	Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> obtenido;

	ignorarOK = true;
	InicializarEstacion(interfaz);
	ignorarOK = false;

	obtenido = interfaz->CableadoMenorDistancia();

	VerificarCableadoMenorDistancia(obtenido, esperado, "Error. No se puede conectar todas las estaciones");

	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORListadoTrayecto()
{
	IniciarSeccion("Listado Trayecto", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado(ERROR, NULL);
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);

	Array<Cadena> trayecto(3);
	trayecto[0] = estaciones[16]->ObtenerNombre();
	trayecto[1] = "LaPaz";
	trayecto[2] = estaciones[9]->ObtenerNombre();

	obtenido = interfaz->ListadoTrayecto(trayecto.ObtenerIterador());
	VerificarListadoTrayecto(obtenido, esperado, "Error. No existe estacion LaPaz");

	trayecto[1] = estaciones[20]->ObtenerNombre();

	obtenido = interfaz->ListadoTrayecto(trayecto.ObtenerIterador());
	Cadena cadena = "Error. No se puede llegar de estacion {0} a estacion {1}.";
	VerificarListadoTrayecto(obtenido, esperado, cadena.DarFormato(estaciones[20]->ObtenerNombre(), estaciones[9]->ObtenerNombre()));

	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORListadoTodosLosTrayectos()
{
	IniciarSeccion("Listado Todos Los Trayectos", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> esperado(ERROR, NULL);
	Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> obtenido;

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);

	obtenido = interfaz->ListadoTodosLosTrayectos("LaPaz", estaciones[0]->ObtenerNombre());
	VerificarListadoTodosLosTrayectos(obtenido, esperado, "Error. No existe estacion origen");

	obtenido = interfaz->ListadoTodosLosTrayectos(estaciones[0]->ObtenerNombre(), "LaPaz");
	VerificarListadoTodosLosTrayectos(obtenido, esperado, "Error. No existe estacion destino");

	obtenido = interfaz->ListadoTodosLosTrayectos(estaciones[20]->ObtenerNombre(), estaciones[16]->ObtenerNombre());
	Cadena cadena = "Error. No se puede llegar de estacion {0} a estacion {1}.";
	VerificarListadoTodosLosTrayectos(obtenido, esperado, cadena.DarFormato(estaciones[20]->ObtenerNombre(), estaciones[16]->ObtenerNombre()));

	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORTrayectoMenosTransbordos()
{
	IniciarSeccion("Trayecto Menos Transbordos", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado(ERROR, NULL);
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);

	obtenido = interfaz->TrayectoMenosTransbordos("LaPaz", estaciones[0]->ObtenerNombre());
	VerificarTrayectoMenosTransbordos(obtenido, esperado, "Error. No existe estacion origen");

	obtenido = interfaz->TrayectoMenosTransbordos(estaciones[0]->ObtenerNombre(), "LaPaz");
	VerificarTrayectoMenosTransbordos(obtenido, esperado, "Error. No existe estacion destino");

	obtenido = interfaz->TrayectoMenosTransbordos(estaciones[20]->ObtenerNombre(), estaciones[16]->ObtenerNombre());
	Cadena cadena = "Error. No se puede llegar de estacion {0} a estacion {1}.";
	VerificarTrayectoMenosTransbordos(obtenido, esperado, cadena.DarFormato(estaciones[20]->ObtenerNombre(), estaciones[16]->ObtenerNombre()));

	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORCantidadMaxima()
{
	IniciarSeccion("Cantidad Maxima", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, nat> esperado(ERROR, 0);
	Tupla<TipoRetorno, nat> obtenido;

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);

	obtenido = interfaz->CantidadMaxima("LaPaz", estaciones[0]->ObtenerNombre());
	VerificarCantidadMaxima(obtenido, esperado, "Error. No existe estacion origen");

	obtenido = interfaz->CantidadMaxima(estaciones[0]->ObtenerNombre(), "LaPaz");
	VerificarCantidadMaxima(obtenido, esperado, "Error. No existe estacion destino");

	obtenido = interfaz->CantidadMaxima(estaciones[20]->ObtenerNombre(), estaciones[16]->ObtenerNombre());
	Cadena cadena = "Error. No se puede llegar de estacion {0} a estacion {1}.";
	VerificarCantidadMaxima(obtenido, esperado, cadena.DarFormato(estaciones[20]->ObtenerNombre(), estaciones[16]->ObtenerNombre()));

	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORLineasAAbordarA()
{
	IniciarSeccion("Lineas AAbordar A", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, nat, Iterador<pLinea>> esperado;
	Tupla<TipoRetorno, nat, Iterador<pLinea>> obtenido;

	/*
	obtenido = interfaz->LineasAAbordarA();
	esperado = ...

	VerificarLineasAAbordarA(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaERRORLineasAAbordarB()
{
	IniciarSeccion("Lineas AAbordar B", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, nat, Iterador<pLinea>> esperado;
	Tupla<TipoRetorno, nat, Iterador<pLinea>> obtenido;

	/*
	obtenido = interfaz->LineasAAbordarB();
	esperado = ...

	VerificarLineasAAbordarB(obtenido, esperado, "Comentario");
	*/
	CerrarSeccion();
}

void CasoDePrueba::PruebaERROREstacionesCriticas()
{
	IniciarSeccion("Estaciones Criticas", ERROR);
	Puntero<ISistema> interfaz = InicializarSistema();

	Tupla<TipoRetorno, Iterador<pEstacion>> esperado(ERROR, NULL);
	Tupla<TipoRetorno, Iterador<pEstacion>> obtenido;

	ignorarOK = true;
	InicializarEstacion(interfaz);
	InicializarLinea(interfaz);
	ignorarOK = false;

	Array<pEstacion> estaciones = ObtenerEstacionesDelSistema(1);

	obtenido = interfaz->EstacionesCriticas("LaPaz", estaciones[0]->ObtenerNombre());
	VerificarEstacionesCriticas(obtenido, esperado, "Error. No existe estacion origen");

	obtenido = interfaz->EstacionesCriticas(estaciones[0]->ObtenerNombre(), "LaPaz");
	VerificarEstacionesCriticas(obtenido, esperado, "Error. No existe estacion destino");

	obtenido = interfaz->EstacionesCriticas(estaciones[20]->ObtenerNombre(), estaciones[16]->ObtenerNombre());
	Cadena cadena = "Error. No se puede llegar de estacion {0} a estacion {1}.";
	VerificarEstacionesCriticas(obtenido, esperado, cadena.DarFormato(estaciones[20]->ObtenerNombre(), estaciones[16]->ObtenerNombre()));

	CerrarSeccion();
}
