#pragma once

#include "FuncionHash.h"

template<class T>
class FuncHashMia
{

};
