#pragma once
#include "Comparador.h"
#include "GrafoImp.h"
#include "arcoGrafoEstaciones.h"

class ComparadorArcoGrafoEstaciones : public Comparador<pArcoEstaciones>
{
	protected:
	  CompRetorno Comparar(const pArcoEstaciones & t1, const pArcoEstaciones& t2) const
	  {
		  if(t1->distancia == t2->distancia)
			  return IGUALES;
		  if(t1->distancia > t2->distancia)
			  return MAYOR;
		  if(t1->distancia < t2->distancia)
			  return MENOR;

		  return DISTINTOS;
	  }
};

class ComparadorArcoGrafoEstacionesListaMenor : public Comparador<pArcoEstaciones>
{
	protected:
	  CompRetorno Comparar(const pArcoEstaciones & t1, const pArcoEstaciones& t2) const
	  {
		  if(t1->densidad == t2->densidad && t1->nroLinea == t2->nroLinea)
			  return IGUALES;
		  return MENOR;
	  }
};


class ComparadorNodoGrafo : public Comparador<Puntero<nodoArco<pArcoEstaciones>>>
{
	protected://no se tiene en cuenta el origen y el destino se asume que se comparan con
		//las de mismos orignes y destinos
	  CompRetorno Comparar(const Puntero<nodoArco<pArcoEstaciones>>& t1, const Puntero<nodoArco<pArcoEstaciones>>& t2) const
	  {
		  if(t1->arco->nroLinea == t2->arco->nroLinea 
			  && t1->arco->origen->ObtenerNombre() == t2->arco->origen->ObtenerNombre()
			  && t1->arco->destino->ObtenerNombre() == t2->arco->destino->ObtenerNombre())
			  return IGUALES;
		  if(t1->arco->nroLinea > t2->arco->nroLinea 
			  && t1->arco->origen->ObtenerNombre() == t2->arco->origen->ObtenerNombre()
			  && t1->arco->destino->ObtenerNombre() == t2->arco->destino->ObtenerNombre())
			  return MAYOR;
		  if(t1->arco->nroLinea < t2->arco->nroLinea 
			  && t1->arco->origen->ObtenerNombre() == t2->arco->origen->ObtenerNombre()
			  && t1->arco->destino->ObtenerNombre() == t2->arco->destino->ObtenerNombre())
			  return MENOR;

		  return DISTINTOS;
	  }
};