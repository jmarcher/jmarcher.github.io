#pragma once
#include "Puntero.h"
#include "Cadena.h" 
#include "IEstacion.h"

typedef unsigned int nat;
class arcoGrafoEstaciones{
public:

	arcoGrafoEstaciones(){};
	arcoGrafoEstaciones(nat nroL, pEstacion o, pEstacion d)
	{
		this->nroLinea=nroL;
		this->origen=o;
		this->destino=d;
	};
	nat nroLinea;
	nat densidad;
	nat distancia;
	nat tiempo;
	pEstacion origen, destino;
	/*
	Cadena EOrigen;
	Cadena EDestino;*/

	virtual bool operator==(const arcoGrafoEstaciones& nge)
	{
		return nroLinea == nge.nroLinea && nge.origen == origen && nge.destino==destino;
		//return densidad==nge.densidad && distancia==nge.distancia  && tiempo==nge.tiempo;
	};
};
typedef Puntero<arcoGrafoEstaciones> pArcoEstaciones;