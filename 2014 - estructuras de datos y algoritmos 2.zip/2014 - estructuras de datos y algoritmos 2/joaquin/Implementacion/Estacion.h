#pragma once
#include "IEstacion.h"
#include "Cadena.h"
class Estacion :
	public IEstacion
{
public:
	Estacion(Cadena nom, nat hAb, nat hCierr);


	//de IEstacion;
	Cadena ObtenerNombre() const{ return nombre;};
	nat ObtenerHAbre() const{return HAbre;}
	nat ObtenerHCierra() const{return HCierra;};
	//bool HoraEnRango(nat hora){ return hora>=HAbre && hora<=HCierra;};

	bool operator==(const IEstacion& e) const{ return nombre == e.ObtenerNombre();};

	virtual ~Estacion(void){};
private:
	Cadena nombre;
	nat HAbre;
	nat HCierra;
};

