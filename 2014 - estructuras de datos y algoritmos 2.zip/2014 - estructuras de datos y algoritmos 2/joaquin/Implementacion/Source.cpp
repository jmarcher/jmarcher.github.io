

#include <iostream>
#include <assert.h>
using namespace std;
#define DIM 6
#define PASAR -1
#define NO_PASAR -2
#define NO_PASE 0
int tablero[DIM+1][DIM+1];
int di[]={ 1, 1, -1,-1, 2, 2,-2,-2};
int dj[]={ 2,-2, 2, -2, 1,-1, 1,-1};
void muestroTablero();
void inicializoTablero()
{
	for(int i=0;i<=DIM;i++)
		for(int j=0;j<=DIM;j++)
			tablero[i][j]=NO_PASE;
};
void inicializoTableroCamino()
{
	for(int i=0;i<=DIM;i++)
		for(int j=0;j<=DIM;j++)
			tablero[i][j]=NO_PASE;
	tablero[1][2]=PASAR;
	tablero[2][3]=PASAR;
	tablero[3][4]=PASAR;
	tablero[2][5]=NO_PASAR;
	tablero[1][5]=NO_PASAR;
	muestroTablero();


};
int ** copio(int tablero[DIM+1][DIM+1],int d1=DIM+1,int d2=DIM+1)
{
	int ** ret=new int*[d1];
	assert(ret);
	for(int i=0;i<d1;i++)
	{
		ret[i]=new int[d2];
		assert(ret[i]);
		for(int j=0;j<d2;j++)
			ret[i][j]=tablero[i][j];
	};
	return ret;
};
void muestroTablero()
{
	cout << endl<<"----------------------";
	for(int i=1;i<=DIM;i++)
	{
		cout << endl;
		cout << endl;
		for(int j=1;j<=DIM;j++)
		{
			cout.width(3);
			cout<<tablero[i][j];
		}
	}
	cout << endl<<"----------------------";
};
bool estaLibre(int tablero[DIM+1][DIM+1],int i,int j)
{
	return i>0 && i<=DIM && j>0 && j<=DIM && tablero[i][j]==0;
};
void colocarCaballo(int tablero[DIM+1][DIM+1],int i,int j,int nroMov)
{
	tablero[i][j]=nroMov;
};
int adyacentes(int i,int j)
{
	int cont=0;
	for(int k=0;k<8;k++)
	{
		if(estaLibre(tablero,i+di[k],j+dj[k]))
		{
			cont++;
		};
	};
	return cont;
};
int mejorAdyacente(int tablero[DIM+1][DIM+1],int i,int j)
{
	int pos=-1;
	int cant=-1;
	for(int k=0;k<8;k++)
	{
		if(estaLibre(tablero,i+di[k],j+dj[k]))
		{
			int c=adyacentes(i+di[k],j+dj[k]);
			if(c>cant)
			{
				cant=c; pos = k;
			};
		};
	};
	return pos;

};
void retirarCaballo(int tablero[DIM+1][DIM+1],int i,int j)
{
	tablero[i][j]=NO_PASE;
};
void caballoAvaro(int i,int j,int nroMov)
{
	assert(estaLibre(tablero,i,j));
	bool termine=false;
	while(!termine)
	{
		colocarCaballo(tablero,i,j,nroMov);
		if(nroMov==DIM*DIM)
		{
			termine=true;
			cout << endl<< "terminamos"<< endl;
			muestroTablero();
			return;
		};
		int pos=mejorAdyacente(tablero,i,j);
		if(pos<0)
		{
			cout<< endl<< " NO SE PUDO"<< endl;
			muestroTablero();
			return;

		};
		i=i+di[pos];
		j=j+dj[pos];
		nroMov++;
	};


};
bool perteneceAlTablero(int i,int j)
{
	return i>0 && i<=DIM && j>0 && j<=DIM;
};
bool termine(int nroMov)
{
	return nroMov == DIM*DIM;
};
int inicializarLaSeleccionDeAlternativas()
{
	return -1;
};
int seleccionarLaSiguienteAlternativa(int k)
{
	return k+1;
};
bool hayMasAlternativas(int k)
{
	return k<7;
};
bool pase(int tablero[DIM+1][DIM+1],int i,int j)
{
	return tablero[i][j]!=NO_PASE;
};
bool pase(int i,int j)
{
	return pase(tablero,i,j);
};

void caballoBT(int i,int j,int nroMov, bool & exito)
{
	static int numSol=1;
	if(perteneceAlTablero(i,j))
	{
		//cout << "entro";
		if(!pase(i,j))
		{

			colocarCaballo(tablero,i,j,nroMov);
			if(termine(nroMov))
			{
				exito=true;
				//if(numSol> 2)exito=true; // todas
				//numSol++;
				//muestroTablero();
				retirarCaballo(tablero,i,j);
			}
			else
			{
				int k=inicializarLaSeleccionDeAlternativas();
				do
				{
					k=seleccionarLaSiguienteAlternativa(k);
					caballoBT(i+di[k],j+dj[k],nroMov+1,exito);

				}
				while(hayMasAlternativas(k) && !exito);
			};
			if(!exito) retirarCaballo(tablero,i,j);


		};
	};
};
bool NoSeDebePasar(int tablero[DIM+1][DIM+1],int i,int j)
{
	return tablero[i][j]!=NO_PASAR;
};
bool tengoQuePasar(int tablero[DIM+1][DIM+1],int i,int j)
{
	return tablero[i][j]!=PASAR;
};
bool pasePorTodos(int Pase,int cantAPasar)
{
	return Pase==cantAPasar;
};
bool termine(int oi,int oj,int di,int dj)
{
	return oi==di && oj==dj;
};
void caminoCaballo(int oi,int oj,int Di, int Dj, int tablero[DIM+1][DIM+1],
				   int solucionActual[DIM+1][DIM+1]
,int nroPasosActual,int & mejorNroPasos, int mejorSolucion[DIM+1][DIM+1],int cantAPasar,int cantPase)
{

	if(perteneceAlTablero(oi,oj))//factibilidad de la soluci�n
	{
		//cout << "entro";
		if(!pase(solucionActual,oi,oj)) //factibilidad de la soluci�n
		{
			if(!NoSeDebePasar(tablero,oi,oj)) //factibilidad de la soluci�n
			{
				if(nroPasosActual<mejorNroPasos) //poda
				{

					colocarCaballo(solucionActual,oi,oj,nroPasosActual);
					int auxPase=cantPase;
					if(tengoQuePasar(tablero,oi,oj)) auxPase++;
					if(termine(oi,oj,Di,Dj))
					{
						if(pasePorTodos(auxPase,cantAPasar))
						{
							//mejorSolucion=copio(solucionActual);
							mejorNroPasos=nroPasosActual;
						}

					}
					else
					{
						int k=inicializarLaSeleccionDeAlternativas();
						do
						{
							k=seleccionarLaSiguienteAlternativa(k);
							caminoCaballo(oi+di[k],oj+dj[k],Di,Dj,tablero,solucionActual,nroPasosActual+1,mejorNroPasos,mejorSolucion,cantAPasar,auxPase);

						}
						while(hayMasAlternativas(k));
					};
					retirarCaballo(solucionActual,oi,oj);


				};
			};
		};
	};
};

//////////////////////////////////////////////////////////////////////////////////
///
///  DAR CAMBIO BT
////////////////////////////////////////////////////////////////////////////////
#define INFINITO 10000
int valorMoneda[]={1,2,4,5,20,50,100,500};

int cambio(int cantAPagar,int monedaHasta,int * valorMoneda)
{
	if(cantAPagar<0 || monedaHasta <0)
		return INFINITO;
	if(cantAPagar==0)
		return 0;
	int usando=1+cambio(cantAPagar-valorMoneda[monedaHasta],monedaHasta,valorMoneda);
	int noUsando=cambio(cantAPagar,monedaHasta-1,valorMoneda);
	return min(usando,noUsando);
};
//////////////////////////////////////////////////////////////////////////////////
///
///  DAR CAMBIO MEMORIZACION
////////////////////////////////////////////////////////////////////////////////
#define CANT_MAX 1500
#define MON_HASTA 10
int * bdCambio[CANT_MAX][MON_HASTA];
void inicializoBDCambio()
{
	for(int c=0;c<CANT_MAX;c++)
		for(int m=0;m<MON_HASTA;m++)
			bdCambio[c][m]=NULL;
};
bool fueCalculado(int cantAPagar,int monedaHasta, int * bd[CANT_MAX][MON_HASTA])
{
	return bd[cantAPagar][monedaHasta]!=NULL;
};
int cambioMem(int cantAPagar,int monedaHasta,int * valorMoneda, int * bd[CANT_MAX][MON_HASTA])
{
	if(cantAPagar<0 || monedaHasta <0)
		return INFINITO;
	if(!fueCalculado(cantAPagar,monedaHasta,bd))
	{
		bd[cantAPagar][monedaHasta]=new int;
		if(cantAPagar==0)
		{
			*bd[cantAPagar][monedaHasta]= 0;
		}
		else
		{
			int usando=1+cambioMem(cantAPagar-valorMoneda[monedaHasta],monedaHasta,valorMoneda,bd);
			int noUsando=cambioMem(cantAPagar,monedaHasta-1,valorMoneda,bd);
			*bd[cantAPagar][monedaHasta]= min(usando,noUsando);
		}
	}
	return *bd[cantAPagar][monedaHasta];
};
int cantMon[8];
void  quemonedas(int cantAPagar,int monedaHasta,int * valorMoneda,int * bd[CANT_MAX][MON_HASTA],int *cantMon)
{
	int mH=monedaHasta;
	for(int i=0;i<=monedaHasta;i++)
		cantMon[i]=0;
	inicializoBDCambio();
	int cant=cambioMem(cantAPagar,monedaHasta,valorMoneda,bd);
	cout <<endl<< "para pagar "<< cantAPagar << "usando moendas hasta la "<< monedaHasta<<" se requieren "<< cant <<" monedas"<< endl;
	while(cantAPagar>0 && monedaHasta>=0)
	{
		if(monedaHasta==0)
		{
			cantMon[monedaHasta]++;
			cantAPagar=cantAPagar-valorMoneda[monedaHasta];
		}
		else
		{
			if(*bd[cantAPagar][monedaHasta]==*bd[cantAPagar][monedaHasta-1])
				monedaHasta--;

			else
			{
				cantMon[monedaHasta]++;
				cantAPagar=cantAPagar-valorMoneda[monedaHasta];
			};
		};
	};
	cout <<endl;
	for(int i=0;i<=mH;i++)
	{
		cout<< endl;
		cout.width(4);
		cout<< valorMoneda[i];
		cout.width(4);
		cout<< cantMon[i];
		cout<< endl;
	};
}
void mainoponlocllo()
{
	bool exito=false;
	//inicializoTablero();
	//caballoAvaro(1,1,1);
	//caballoBT(3,5,1,exito);
	//muestroTablero();
	/*	cout << endl << cambio(8,0,valorMoneda)<<endl;
	cout << endl << cambio(8,1,valorMoneda)<<endl;
	cout << endl << cambio(8,2,valorMoneda)<<endl;
	cout << endl << cambio(8,3,valorMoneda)<<endl;
	cout << endl << cambio(20,3,valorMoneda)<<endl;
	cout << endl << cambio(40,3,valorMoneda)<<endl;
	cout << endl << cambio(121,3,valorMoneda)<<endl;
	cout << endl << cambio(1210,7,valorMoneda)<<endl;
	*/

	cout << endl << cambioMem(8,0,valorMoneda,bdCambio)<<endl;
	cout << endl << cambioMem(8,1,valorMoneda,bdCambio)<<endl;
	cout << endl << cambioMem(8,2,valorMoneda,bdCambio)<<endl;
	cout << endl << cambioMem(8,3,valorMoneda,bdCambio)<<endl;
	cout << endl << cambioMem(20,3,valorMoneda,bdCambio)<<endl;
	cout << endl << cambioMem(40,3,valorMoneda,bdCambio)<<endl;
	cout << endl << cambioMem(121,3,valorMoneda,bdCambio)<<endl;
	cout << endl << cambioMem(1210,7,valorMoneda,bdCambio)<<endl;
	quemonedas(8,0,valorMoneda,bdCambio,cantMon);
	quemonedas(8,1,valorMoneda,bdCambio,cantMon);
	quemonedas(8,2,valorMoneda,bdCambio,cantMon);
	quemonedas(8,3,valorMoneda,bdCambio,cantMon);
	quemonedas(20,3,valorMoneda,bdCambio,cantMon);
	quemonedas(40,3,valorMoneda,bdCambio,cantMon);
	quemonedas(121,3,valorMoneda,bdCambio,cantMon);
	quemonedas(1210,7,valorMoneda,bdCambio,cantMon);


};

