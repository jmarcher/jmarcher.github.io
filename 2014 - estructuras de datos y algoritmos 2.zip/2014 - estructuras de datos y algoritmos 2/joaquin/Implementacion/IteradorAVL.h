#ifndef ITERADORAVL_H
#define ITERADORAVL_H

#include "Iterador.h"
#include "AVL.h"
#include "Array.h"
#include "nodoAVL.h"

template <class T>
class IteradorAVL : public Iteracion<T>{
public:
	IteradorAVL(Puntero<nodoAVL<T>> raiz, nat largo);
	~IteradorAVL();

	void Reiniciar();
	bool HayElemento() const;
	const T& ElementoActual() const;
	void Avanzar();
	Puntero<Iteracion<T>> Clonar() const;
	
private:
	Puntero<nodoAVL<T>> raiz;
	Array<Puntero<nodoAVL<T>>> stack;
	nat tope;
	void AgregarCamino(Puntero<nodoAVL<T>> nodo);
};

#include "IteradorAVL.cpp"

#endif