#pragma once
#include "Comparador.h"
#include "IEstacion.h"
#include "GrafoImp.h"
#include "ListaOrdenada.h"

class ComparadorEstaciones : public Comparador<pEstacion>
{
	protected:
	  CompRetorno Comparar(const pEstacion & t1, const pEstacion& t2) const
	  {
		  if(t1->ObtenerNombre() == t2->ObtenerNombre() )
			  return IGUALES;
		  else if (t1->ObtenerNombre()<t2->ObtenerNombre())
			  return MENOR;
		  else if(t1->ObtenerNombre() > t2->ObtenerNombre())
			  return MAYOR;

		  return DISTINTOS;
	  }
};
class ComparadorEstacionesLista : public Comparador<pEstacion>
{
	protected:
	  CompRetorno Comparar(const pEstacion & t1, const pEstacion& t2) const
	  {
		  if(t1->ObtenerNombre() == t2->ObtenerNombre() )
			  return IGUALES;
		  return MAYOR;
	  }
};
class ComparadorEstacionesListaMenor : public Comparador<pEstacion>
{
	protected:
	  CompRetorno Comparar(const pEstacion & t1, const pEstacion& t2) const
	  {
		  if(t1->ObtenerNombre() == t2->ObtenerNombre() )
			  return IGUALES;
		  return MENOR;
	  }
};

class ComparadorListaOrdenada : public Comparador<Puntero<ListaOrdenada<pEstacion>>>
{
	protected:
	  CompRetorno Comparar(const Puntero<ListaOrdenada<pEstacion>> & t1, const Puntero<ListaOrdenada<pEstacion>>& t2) const
	  {
		  if(t1->cardinal() == t2->cardinal())
		  {
			  Array<pEstacion> a1 = t1->toArray();
			  Array<pEstacion> a2 = t2->toArray();
			  if(a1.ObtenerLargo() == a2.ObtenerLargo())
			  {
				  bool todosIguales=true;
				  for(nat i=0; i<a1.ObtenerLargo();i++)
				  {
					  if(!(a1[i]->ObtenerNombre() == a2[i]->ObtenerNombre()))
					  {
						  return MAYOR;
						  bool todosIguales=false;
						  break;
					  };
				  };
				  if(todosIguales){
					  return IGUALES;
				  }
			  };
		  };
		  return MAYOR;
	  }
};

class ComparadorVertices : public Comparador<nodoVert<pEstacion>>
{
	protected:
	  CompRetorno Comparar(const nodoVert<pEstacion> & t1, const nodoVert<pEstacion>& t2) const
	  {
		  if(t1.vertice->ObtenerNombre() == t2.vertice->ObtenerNombre() )
			  return IGUALES;
		  else if (t1.vertice->ObtenerNombre()<t2.vertice->ObtenerNombre())
			  return MENOR;
		  else if(t1.vertice->ObtenerNombre() > t2.vertice->ObtenerNombre())
			  return MAYOR;

		  return DISTINTOS;
	  }
};