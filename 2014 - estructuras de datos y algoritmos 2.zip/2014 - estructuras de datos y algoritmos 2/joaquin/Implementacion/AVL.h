#ifndef AVL_H
#define AVL_H

#include "Puntero.h"
#include "Comparador.h"
#include "nodoAVL.h"
#include "IteradorAVL.h"
#include "Iterable.h"

template<class T>
class IteradorAVL;

typedef unsigned int nat;

template<class T>
class AVL : public Iterable<T>
{
public:
	
	AVL(void);

	AVL(const Puntero<Comparador<T>>& comp);
	//AVL(AVL<T> & a);
	
	void insertar(const T& t);
	void eliminar(const T& t);
	void vaciar();
	Puntero<AVL<T>>& crearVacio() const;
	Puntero<nodoAVL<T>> getNodo(const T& t) const;
	T& getDato(const T& t) const;


	bool pertenece(const T& t) const;
	bool esVacio() const;


	void imprimirEnOrden(Puntero<nodoAVL<T>> nodo) const;
 
	Puntero<nodoAVL<T>> maximo(Puntero<nodoAVL<T>> r) const;

	Puntero<AVL<T>> clon() const;

	AVL<T>& operator=(const AVL<T>& r);
	AVL<T>& operator=(AVL<T>* r);
	
	nat cardinal() const{ return cantNodos;};

	Iterador<T> ObtenerIterador() const;

	virtual ~AVL(void);

private:

	nat cantNodos;

	Puntero<Comparador<T>> aComp;
	Puntero<nodoAVL<T>> raiz;
	bool vario_h;

	//auxiliares
	void eliminar(Puntero<nodoAVL<T>>& r, const T& t);
	bool pertenece(Puntero<nodoAVL<T>> raiz, const T& t) const;
	void insertarAux(Puntero<nodoAVL<T>>& raiz, const T& t);
	void BalanceoD(Puntero<nodoAVL<T>>& r);
	void BalanceoI(Puntero<nodoAVL<T>>& r);
	void vaciarAux(Puntero<nodoAVL<T>> & r);
	Puntero<nodoAVL<T>> getNodo(Puntero<nodoAVL<T>> r, const T& t) const;
};
#include "AVL.cpp"

#endif