#ifndef LISTAORDENADA_CPP
#define LISTAORDENADA_CPP
#include "ListaOrdenada.h"
#include "Puntero.h"

#include <iostream>
template<class T>
ListaOrdenada<T>::ListaOrdenada()
{
	lista = NULL;
	card = 0;
};
template<class T>
ListaOrdenada<T>::ListaOrdenada(Puntero<Comparador<T>> comp)
{
	lista = NULL;
	card = 0;
	this->aComp =comp;
};

template<class T>
nat ListaOrdenada<T>::cardinal() const
{
	return card;
}
template<class T>
T ListaOrdenada<T>::obtenerPrimero() const
{
	return lista->elemento;
};
template<class T>
Puntero<nodoLista<T>> ListaOrdenada<T>::obtenerResto() const
{
	return lista->siguiente;
};
template<class T>
void ListaOrdenada<T>::agregarElemento(const T& t, bool ignorarIguales)
{
	if(lista==NULL){
		Puntero<nodoLista<T>> l = new nodoLista<T>();
		l->elemento= t;
		l->siguiente = NULL;
		lista = l;
		card++;
	}else{
		if(this->aComp->EsMenor(t, lista->elemento) ||(!ignorarIguales&& this->aComp->SonIguales(t, lista->elemento))){
			Puntero<nodoLista<T>> l = new nodoLista<T>();
			l->elemento = t;
			l->siguiente = lista;
			lista = l;
			card++;
		}else{// if(this->aComp->EsMayor(t, lista->elemento) ){  
			//sdsdsd
			Puntero<nodoLista<T>> l = lista;
			bool agrego = false;
			if(l->siguiente == NULL)
			{
				Puntero<nodoLista<T>> lr = new nodoLista<T>();
					lr->elemento = t;
					lr->siguiente = NULL;
					lista->siguiente=lr;
					agrego=true;
					card++;
			};
			while(!(l->siguiente == NULL  || agrego)){

				if(l != NULL && (this->aComp->EsMenor(t, l->siguiente->elemento) 
					|| (!ignorarIguales && this->aComp->SonIguales(t, l->siguiente->elemento)))){
					Puntero<nodoLista<T>> lr = new nodoLista<T>();
					lr->elemento = t;
					lr->siguiente = l->siguiente;
					l->siguiente = lr;
					agrego=true;
					card++;
				}else if(l->siguiente->siguiente == NULL){
					Puntero<nodoLista<T>> lr = new nodoLista<T>();
					lr->elemento = t;
					lr->siguiente = NULL;
					l->siguiente->siguiente = lr;
					agrego=true;
					card++;
				}
				l = l->siguiente;
			};
		};

	}
};



template<class T>
void ListaOrdenada<T>::eliminar(const T& t){
	if(pertenece(t)){
		Puntero<nodoLista<T>> l = lista;
		bool elimino =false;
		if(card == 1)
		{
			lista=NULL;
			elimino=true;
			card=0;
		};
		while(!(elimino)){
			if(this->aComp->SonIguales(t, l->siguiente->elemento) && l->siguiente->siguiente==NULL){
				l->siguiente = NULL;
				elimino = true;
				card--;
			};

			if(this->aComp->SonIguales(t, l->elemento) && !elimino)
			{
				l->elemento =  l->siguiente->elemento;
				l->siguiente = l->siguiente->siguiente;
				elimino=true;
				card--;
			};


			l = l->siguiente;
		};
	};
}

//Mejorable
template<class T>
bool ListaOrdenada<T>::pertenece(const T& t) const
{
	bool encontre=false;
	Puntero<nodoLista<T>> l = lista;
	while(!(l==NULL || encontre))
	{
		if(this->aComp->SonIguales(t, l->elemento))
			encontre=true;
		l=l->siguiente;
	};
	return encontre;
};

template<class T>
void ListaOrdenada<T>::imprimir() const{
	/*Puntero<nodoLista<T>> l = lista;
	cout<<endl<<"+--- COMIENZO ---+"<<endl<<"{";
	while(l!=NULL){
		cout<<l->elemento->origen->ObtenerNombre()<<" - " << l->elemento->destino->ObtenerNombre() << " : " << l->elemento->distancia << endl;
		l=l->siguiente;
	};
	cout << "NULL}" << endl<<"+--- FIN ---+"<<endl;*/
}

template<class T>
Puntero<Lista<T>> ListaOrdenada<T>::clone() const
{
	Puntero<ListaOrdenada<T>> ret = new ListaOrdenada<T>(this->aComp);
	Puntero<nodoLista<T>> l = lista;
	while(l!=NULL)
	{
		ret->agregarElemento(l->elemento);
		l=l->siguiente;
	};
	return ret;
};

template<class T>
Array<T> ListaOrdenada<T>::toArray() const
{
	Array<T> ret = Array<T>(this->card);
	Puntero<nodoLista<T>> l = lista;
	nat indice=0;
	while(l!=NULL)
	{
		ret[indice]=l->elemento;
		indice++;
		l=l->siguiente;
	};
	return ret;
};

#endif
