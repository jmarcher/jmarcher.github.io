#include "ColaPrioridad.h"

template<class T>
ColaPrioridad<T>::ColaPrioridad(nat CANT_ELEMENTOS, const Puntero<Comparador<T>>& comp)
{
}

