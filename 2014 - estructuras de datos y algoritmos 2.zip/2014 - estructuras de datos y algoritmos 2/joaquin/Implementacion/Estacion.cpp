#include "Estacion.h"


Estacion::Estacion(Cadena nom, nat hAb, nat hCierr)
{
	this->nombre=nom;
	this->HAbre=hAb;
	this->HCierra=hCierr;
};