#ifndef AVL_CPP
#define AVL_CPP
#include "AVL.h"
#include "Puntero.h"
#include "Comparador.h"
#include <iostream>

template<class T>
AVL<T>::AVL(void)
{
	raiz = NULL;
	this->cantNodos=0;
};

template<class T>
AVL<T>::AVL(const Puntero<Comparador<T>>& comp)
{
	raiz=NULL;
	this->aComp = comp;
	this->cantNodos=0;
};


template<class T>
void AVL<T>::insertarAux(Puntero<nodoAVL<T>>& raiz, const T& t){
	Puntero<nodoAVL<T>> p1, p2;
	if(raiz==NULL)
	{
		Puntero<nodoAVL<T>> r = new nodoAVL<T>();
		r->dato = t;
		r->bal = 0;
		r->izq = NULL;    
		r->der = NULL;
		raiz = r;
		vario_h = true;
		++cantNodos;
	}else{
		if(aComp->EsMayor(raiz->dato,t)){
		//if(raiz->dato > t){
			//a la izquierda
			insertarAux(raiz->izq, t);
			if(vario_h)
			{
				switch(raiz->bal)
				{
				case 1: 
					raiz->bal = 0;
					vario_h=false;
					break;
				case 0:
					raiz->bal = -1;
					break;
				case -1:
					p1 = raiz->izq;
					if(p1->bal == -1)
					{
						//II
						raiz->izq = p1->der;
						p1->der = raiz;
						raiz->bal = 0;
						raiz = p1;
					}else{
						p2 = p1->der;
						p1->der = p2->izq;
						p2->izq = p1;
						raiz->izq = p2->der;
						p2->der = raiz;
						raiz->bal = p2->bal == -1 ? 1:0;
						p1->bal = p2->bal == 1 ? -1:0;
						raiz = p2;

					};
					raiz->bal = 0;
					vario_h=false;
				};
			};
		}else if(aComp->EsMenor(raiz->dato,t)){
		//}else if (raiz->dato < t){
			// a la derecha
			insertarAux(raiz->der, t);
			if(vario_h)
			{
				switch(raiz->bal)
				{
				case -1: 
					raiz->bal = 0;
					vario_h=false;
					break;
				case 0:
					raiz->bal = 1;
					break;
				case 1:
					p1 = raiz->der;
					if(p1->bal == 1)
					{
						//DD
						raiz->der = p1->izq;
						p1->izq = raiz;
						raiz->bal = 0;
						raiz = p1;
					}else{
						p2 = p1->izq;
						p1->izq = p2->der;
						p2->der = p1;
						raiz->der = p2->izq;
						p2->izq = raiz;
						raiz->bal = p2->bal == -1 ? 1:0;
						p1->bal = p2->bal == 1 ? -1:0;
						raiz = p2;

					};
					raiz->bal = 0;
					vario_h=false;
				};
			};
		}else{
			//ya estaba
			vario_h = false;
		};


	};
};

template<class T>
void AVL<T>::eliminar(const T& t)
{
	eliminar(raiz, t);
};

template<class T>
Puntero<nodoAVL<T>> AVL<T>::maximo(Puntero<nodoAVL<T>> r) const
{
	if(r->izq == NULL && r->der == NULL){
		return r;
	}else{
		return maximo(r->der);
	}
};



//ELIMINAR SIN REBALANCEOS
template<class T>
void AVL<T>::eliminar(Puntero<nodoAVL<T>>& r, const T& t)
{
	if(r!= NULL)
	{
		if(aComp->EsMenor(r->dato,t)){
		//if(r->dato < t){
			eliminar(r->der, t);
		}
		else if(aComp->EsMayor(r->dato,t))
		{
			eliminar(r->izq, t);
		}
		else
		{
			if(r->der != NULL && r->izq != NULL)
			{
				Puntero<nodoAVL<T>> pred = maximo(r->izq);
				r->dato = pred->dato;
				eliminar(r->izq, pred->dato);
			}
			else
			{
				Puntero<nodoAVL<T>> temp = r;
				--cantNodos;
				if(r->der == NULL)
					r = r->izq;
				else
					r = r->der;

			};

		};
	};
};

template<class T>
void AVL<T>::insertar(const T& t)
{
	insertarAux(raiz, t);


};

template<class T>
bool AVL<T>::esVacio() const
{
	return raiz==NULL;
};

template<class T>
void AVL<T>::imprimirEnOrden(Puntero<nodoAVL<T>> nodo) const{
	if(nodo != NULL){
		imprimirEnOrden(nodo->izq);
		cout << nodo->dato << endl;
		imprimirEnOrden(nodo->der);
	}
};

template<class T>
bool AVL<T>::pertenece(const T& t) const
{
	return pertenece(raiz,t);
};

template<class T>
void AVL<T>::vaciar()
{
	while(!esVacio(raiz))
	 eliminar(raiz);
};
template<class T>
Puntero<AVL<T>>& AVL<T>::crearVacio() const
{
	return new AVL<T>();
};

template<class T>
Puntero<AVL<T>> AVL<T>::clon() const
{
	Puntero<AVL<T>> aux = new AVL<T>();

};

template<class T>
bool AVL<T>::pertenece(Puntero<nodoAVL<T>> r, const T & t) const
{
	if(r == NULL){
		return false;
	}else{
		if(aComp->EsMenor(r->dato, t)){
			return pertenece(r->der, t);
		}else if(aComp->EsMayor(r->dato,t)){
			return pertenece(r->izq, t);
		}else{
			return true;
		};
	};
};

template<class T>
void AVL<T>::BalanceoD(Puntero<nodoAVL<T>>& r)
{
	Puntero<nodoAVL<T>> p1, p2;
	int d1, d2;
	switch(r->bal){
	case 1:
		r->bal=0;
		break;
	case 0:
		r->bal = -1;
		vario_h=false;
		break;
	case -1:
		{
			p1 = r->izq;
			d1 = p1->bal;
			if(d1 <=0 )
			{
				r->izq = p1->der;
				p1->der = r;
				if( d1 == 0)
				{
					r->bal = -1;
					p1->bal=1;
					vario_h=false;
				}
				else
				{
					p1->bal = r->bal = 0;
					r = p1;
				};
			}
			else
			{ //ID
				p2 = p1->der;
				d2 = p2->bal;
				p1->der = p2->izq;
				p2->izq = p1;
				r->izq = p2->der;
				p2->der = r;
				r->bal = d2== - 1 ? 1 : 0;
				p1->bal = d2 == 1 ? -1 : 0;
				r = p2;
				p2->bal = 0 ;
			

			};

		};


	};

};

template<class T>
void AVL<T>::BalanceoI(Puntero<nodoAVL<T>>& r)
{
	Puntero<nodoAVL<T>> p1, p2;
	int d1, d2;
	switch(r->bal)
	{
	case -1:
		r->bal = 0;
		break;
	case 0:
		r->bal =1;
		vario_h = false;
		break;
	case 1:
		{
			p1 = r->der;
			d1 = p1->bal;
			if(d1 >= 0)
			{
				r->der = p1->izq;
				p1->izq = r;
				if(d1==0)
				{
					r->bal =1;
					p1->bal=-1;
					vario_h=false;
				}
				else
					r->bal = p1->bal  = 0;
				r = p1;
			}
			else
			{//DI
				p1 = p1->izq;
				d2 = p2->bal;
				p1->izq = p2->der;
				p2->der = p1;
				r->der = p2->izq;
				p2->izq = r;
				r->bal = d2 == 1 ? -1 : 0;
				p1->bal = d2 == -1 ? 1 : 0;
				r = p2;
				p2->bal = 0;
			};
		};
	};
};

template<class T>
Puntero<nodoAVL<T>> AVL<T>::getNodo(Puntero<nodoAVL<T>> r, const T& t) const
{
	if(aComp->SonIguales(r->dato,t))
		return r;
	else
	{
		if(aComp->EsMayor(t,r->dato))
			return getNodo(r->der,t);
		else
			return getNodo(r->izq,t);
		
	};

};

template<class T>
Puntero<nodoAVL<T>> AVL<T>::getNodo(const T& t) const
{
	return getNodo(raiz, t);
};

template<class T>
T& AVL<T>::getDato(const T& t) const{
	Puntero<nodoAVL<T>> nAVL = getNodo(t);
	return nAVL->dato;
};

template<class T>
AVL<T>::~AVL(void)
{
};

template<class T>
AVL<T>& AVL<T>::operator=(const AVL<T>& r)
{
	if(this != &r)
	{
		if(r!=NULL){
			vaciar();
			raiz=r->raiz;
			raiz->izq = r->izq;
			raiz->der = r->der
		}
		
	};
	return *this;
};

template<class T>
AVL<T>& AVL<T>::operator=(AVL<T>* r)
{
	if(this != r)
	{
		if(r!=NULL){
			vaciar();
			raiz=r->raiz;
			raiz->izq = r->izq;
			raiz->der = r->der
		}
		
	};
	return *this;
};

template<class T>
Iterador<T> AVL<T>::ObtenerIterador() const
{
	return new IteradorAVL<T>(raiz, this->cardinal());
};
#endif