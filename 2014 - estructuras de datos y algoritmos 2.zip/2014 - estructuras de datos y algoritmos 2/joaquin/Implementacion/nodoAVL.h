#ifndef NODOAVL_H
#define NODOAVL_H

	template<class T>
	class nodoAVL{
	public:
		T dato;
		int bal;
		Puntero<nodoAVL<T>> izq;
		Puntero<nodoAVL<T>> der;
		virtual T& getDato(){
			return dato;
		};
	};

#endif