#pragma once
#include "Comparador.h"
#include "IEstacion.h"

class ComparadorEstacionPorHorario : public Comparador<pEstacion>
{
	protected:
	  CompRetorno Comparar(const pEstacion & t1, const pEstacion& t2) const
	  {
		  if(t1->ObtenerHAbre() == t2->ObtenerHAbre())
		  {
			  if(t1->ObtenerNombre() == t2->ObtenerNombre())
				  return IGUALES;
			  else if(t1->ObtenerNombre() > t2->ObtenerNombre())
				  return MAYOR;
			  else if(t1->ObtenerNombre() < t2->ObtenerNombre())
				  return MENOR;
		
		  }else if (t1->ObtenerHAbre()<t2->ObtenerHAbre())
			  return MENOR;
		  else if(t1->ObtenerHAbre() > t2->ObtenerHAbre())
			  return MAYOR;

		  return DISTINTOS;
	  }
};