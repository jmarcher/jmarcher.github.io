#pragma once
#include "FuncionHash.h"
#include "ILinea.h"
#include "CadenaFuncionHash.h"

class FuncionHashLinea : public FuncionHash<pLinea>
{
public:
	nat CodigoDeHash(const pLinea& l) const
	{
		return l->ObtenerNroLinea();
	};
};