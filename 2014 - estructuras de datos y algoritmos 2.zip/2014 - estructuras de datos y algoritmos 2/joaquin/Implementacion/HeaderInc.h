#include "Puntero.h"
typedef unsigned int nat;