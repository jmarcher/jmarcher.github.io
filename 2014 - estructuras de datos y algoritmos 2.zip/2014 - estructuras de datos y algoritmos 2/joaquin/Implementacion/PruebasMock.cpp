﻿#include "PruebasMock.h"

EstacionMock::EstacionMock(Cadena nombre, nat hAbre, nat hCierra)
{
	m_Nombre = nombre;
	m_HAbre = hAbre;
	m_HCierra = hCierra;
}

Cadena EstacionMock::ObtenerNombre() const
{
	return m_Nombre;
}

nat EstacionMock::ObtenerHAbre() const
{
	return m_HAbre;
}

nat EstacionMock::ObtenerHCierra() const
{
	return m_HCierra;
}

bool EstacionMock::operator==(const IEstacion& e) const
{
	return this == &e;
}

LineaMock::LineaMock(nat nroLinea, nat precio, Iterador<Tupla<pEstacion, nat, nat, nat>> estaciones)
{
	m_NroLinea = nroLinea;
	m_Precio = precio;
	m_Estaciones = estaciones;
}

nat LineaMock::ObtenerNroLinea() const
{
	return m_NroLinea;
}

nat LineaMock::ObtenerPrecio() const
{
	return m_Precio;
}

Iterador<Tupla<pEstacion, nat, nat, nat>> LineaMock::ObtenerEstaciones() const
{
	return m_Estaciones;
}

bool LineaMock::operator==(const ILinea& l) const
{
	return this == &l;
}
