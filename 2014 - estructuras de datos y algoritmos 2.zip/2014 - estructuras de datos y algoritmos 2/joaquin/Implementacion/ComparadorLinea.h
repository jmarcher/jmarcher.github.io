#pragma once
#include "Comparador.h"
#include "ILinea.h"
#include "Linea.h"

class ComparadorLinea : public Comparador<pLinea>
{
	protected:
	  CompRetorno Comparar(const pLinea & t1, const pLinea& t2) const
	  {
		  if(t1->ObtenerNroLinea() == t2->ObtenerNroLinea() )
			  return IGUALES;
		  else if (t1->ObtenerNroLinea()<t2->ObtenerNroLinea())
			  return MENOR;
		  else if(t1->ObtenerNroLinea() > t2->ObtenerNroLinea())
			  return MAYOR;

		  return DISTINTOS;
	  }
};

class ComparadorLineaMia : public Comparador<pLineaMia>
{
	protected:
		CompRetorno Comparar(const pLineaMia & t1, const pLineaMia& t2) const
	  {
		  if(t1->ObtenerDistancia() == t2->ObtenerDistancia())
			  return IGUALES;
		  else if (t1->ObtenerDistancia()<t2->ObtenerDistancia())
			  return MENOR;
		  else if(t1->ObtenerDistancia() > t2->ObtenerDistancia())
			  return MAYOR;

		  return DISTINTOS;
	  }
};