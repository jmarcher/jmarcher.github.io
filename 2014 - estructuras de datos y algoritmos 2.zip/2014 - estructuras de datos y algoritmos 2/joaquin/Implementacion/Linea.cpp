#include "Linea.h"

Linea::Linea(nat numeroLinea, nat precioLinea, Iterador<Tupla<pEstacion, nat, nat, nat>> iter)
{
	this->nroLinea = numeroLinea;
	this->precio = precioLinea;
	nat card=0;

	nat dist=0;
	if(iter != NULL){
		while(iter.HayElemento()){
			++card;
			iter.Avanzar();
		};
		iter.Reiniciar();
		estaciones = Array<Tupla<pEstacion, nat, nat, nat>>(card);
		nat i=0;
		while(iter.HayElemento()){
			Tupla<pEstacion, nat, nat, nat> elem = iter.ElementoActual();
			iter.Avanzar();
			dist += elem.ObtenerDato2();
			estaciones[i]=elem;
			i++;
		};
		iter.Reiniciar();
	};
	this->distancia =dist;
};

Linea::Linea(const pLinea& l)
{
	this->nroLinea = l->ObtenerNroLinea();
	this->precio = l->ObtenerPrecio();
	
	Iterador<Tupla<pEstacion, nat, nat, nat>> iter = l->ObtenerEstaciones();

	nat card=0;

	nat dist=0;
	if(iter != NULL){
		while(iter.HayElemento()){
			++card;
			iter.Avanzar();
		};
		iter.Reiniciar();
		estaciones = Array<Tupla<pEstacion, nat, nat, nat>>(card);
		nat i=0;
		while(iter.HayElemento()){
			Tupla<pEstacion, nat, nat, nat> elem = iter.ElementoActual();
			iter.Avanzar();
			dist += elem.ObtenerDato2();
			estaciones[i]=elem;
			i++;
		};
		iter.Reiniciar();
	};
	this->distancia =dist;
};

Linea::~Linea(void)
{
}

Iterador<Tupla<pEstacion, nat, nat, nat>> Linea::ObtenerEstaciones() const
{
	return estaciones.ObtenerIterador();
};