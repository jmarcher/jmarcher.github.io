﻿#include "Sistema.h"
#include "Estacion.h"
#include "Linea.h"
#include "Cadena.h"
#include <iostream>
//#include "GrafoMetro.h"
using namespace std;

Sistema::Sistema(nat MAX_LINEAS, nat MAX_ESTACIONES)
{
	MAX_CANT_ESTACIONES = MAX_ESTACIONES;
	MAX_CANT_LINEAS     = MAX_LINEAS;
	cantLineas          = 0;

	compEstaciones = new ComparadorEstaciones();
	funcHashEst =  new FuncionHashEstacion();
	compArcoGrafoEstaciones = new ComparadorArcoGrafoEstaciones();
	compEstacionesPorHorario =  new ComparadorEstacionPorHorario();

	hashEstaciones =  new TablaHash<pEstacion>(funcHashEst,compEstaciones,MAX_CANT_ESTACIONES);
	arrayLineas = Array<pLinea>(MAX_CANT_LINEAS);
	avlEstaciones =  new AVL<pEstacion>(compEstaciones);
	avlEstacionesPorHorario =  new AVL<pEstacion>(compEstacionesPorHorario);
	grafoEstaciones = new GrafoImp<pEstacion,pArcoEstaciones>(MAX_CANT_ESTACIONES, compEstaciones, compArcoGrafoEstaciones);

	//grafoEstaciones = new GrafoMetro(MAX_CANT_ESTACIONES, compEstaciones, compArcoGrafoEstaciones);
};

bool Sistema::enRangoLinea(nat n)
{
	return n>=1 && n<=MAX_CANT_LINEAS;
};

bool horaValida(nat hora)
{
	return hora>=0 && hora<=24;
};

// Hito de Control Tipo 1

TipoRetorno Sistema::IngresoEstacion(Cadena nombre, nat hAbre, nat hCierra)
{
	pEstacion estacionAInsertar = new Estacion(nombre, hAbre, hCierra);
	if(!hashEstaciones->pertenece(estacionAInsertar)){
		if(hashEstaciones->cardinal() < MAX_CANT_ESTACIONES){
			//return OK;
			if(hAbre <= hCierra){

				if(hCierra<=24){
					if(horaValida(hAbre) && horaValida(hCierra)){
						//Tengo que insertar en las dos estructuras porque me pide devolverlas
						//en orden alfabetico en orden log(n)
						hashEstaciones->insertar(estacionAInsertar);
						avlEstaciones->insertar(estacionAInsertar);
						avlEstacionesPorHorario->insertar(estacionAInsertar);
						grafoEstaciones->InsertarVertice(estacionAInsertar);


						return OK;
					}
				}
			}
		}
	}
	return ERROR;
}

template<class T>
nat contarIterador(Iterador<T> iter)
{
	nat ret =0;
	while(iter.HayElemento())
	{
		ret++;
		iter.Avanzar();
	};
	iter.Reiniciar();
	return ret;
};

Iterador<Tupla<pEstacion, nat, nat, nat>> Sistema::pertenecenEstaciones( Iterador<Tupla<Cadena, nat, nat, nat>> estaciones) const
{
	Iterador<Tupla<pEstacion, nat, nat, nat>> iter;
	Array<Tupla<pEstacion,nat, nat,nat>> arrEst = Array<Tupla<pEstacion,nat, nat,nat>>(contarIterador(estaciones));

	nat i = 0;
	while(estaciones.HayElemento())
	{
		Tupla<pEstacion,nat, nat,nat> tupRet;

		Tupla<Cadena, nat, nat, nat> elem = estaciones.ElementoActual();
		Cadena nombreEstacion = elem.ObtenerDato1();
		pEstacion estAux = new Estacion(nombreEstacion,1,2);
		if(!hashEstaciones->pertenece(estAux) || (i>0 && elem.ObtenerDato2()==0))
		{
			return NULL;
		}
		else
		{
			estAux = hashEstaciones->getDato(estAux);
			tupRet.AsignarDato1(estAux);
			tupRet.AsignarDato2(elem.ObtenerDato2());
			tupRet.AsignarDato3(elem.ObtenerDato3());
			tupRet.AsignarDato4(elem.ObtenerDato4());
			arrEst[i]=tupRet;
			i++;
		};
		estaciones.Avanzar();

	};

	estaciones.Reiniciar();
	return arrEst.ObtenerIterador();
};



TipoRetorno Sistema::IngresoLinea(nat nroLinea, nat precio, Iterador<Tupla<Cadena, nat, nat, nat>> estaciones)
{
	//En implementacion
	//return NO_IMPLEMENTADA; //sacar esto para probar
	//pLinea lineaAInsertar = new Linea(estaciones);

	Iterador<Tupla<pEstacion, nat, nat, nat>> iterEstaciones = pertenecenEstaciones(estaciones);

	if(nroLinea>=1 && nroLinea<=MAX_CANT_LINEAS)
	{
		if(iterEstaciones != NULL) //retorna NULL cuando no existe una estacion o una distancia es 0 (excpepto la primera)
		{
			pLinea lineaAInsertar = new Linea(nroLinea, precio, iterEstaciones);
			if(arrayLineas[nroLinea]==NULL)
			{
				//Agrego los arcos al grafo
				while(iterEstaciones.HayElemento())
				{

					pEstacion eO = iterEstaciones.ElementoActual().ObtenerDato1();
					iterEstaciones.Avanzar();
					if(iterEstaciones.HayElemento())
					{
						pEstacion eD = iterEstaciones.ElementoActual().ObtenerDato1();

						pArcoEstaciones pArcoAInsertar = new arcoGrafoEstaciones();
						pArcoAInsertar->nroLinea = nroLinea;
						pArcoAInsertar->distancia = iterEstaciones.ElementoActual().ObtenerDato2();
						pArcoAInsertar->densidad = iterEstaciones.ElementoActual().ObtenerDato3();
						pArcoAInsertar->tiempo = iterEstaciones.ElementoActual().ObtenerDato4();
						pArcoAInsertar->origen = eO;
						pArcoAInsertar->destino = eD;

						grafoEstaciones->InsertarArco(eO,eD,pArcoAInsertar);
					};

				};
				iterEstaciones.Reiniciar();
				arrayLineas[nroLinea]=lineaAInsertar;
				cantLineas++;
				return OK;
			};
		};
	};

	return ERROR;
}

TipoRetorno Sistema::HabilitacionTramo(nat nroLinea, Cadena eOrigen, Cadena eDestino, bool habilitado)
{
	if(!hashEstaciones->pertenece(new Estacion(eOrigen,1,2)))
		return ERROR;
	if(!hashEstaciones->pertenece(new Estacion(eDestino,1,2)))
		return ERROR;
	if(!enRangoLinea(nroLinea))
		return ERROR;
	if(arrayLineas[nroLinea]==NULL)
		return ERROR;

	pEstacion peOrigen  = hashEstaciones->getDato(new Estacion(eOrigen,  1, 2));
	pEstacion peDestino = hashEstaciones->getDato(new Estacion(eDestino, 1, 2));
	pLinea    lineaReal =  arrayLineas[nroLinea];

	pArcoEstaciones arcoTrucho = new arcoGrafoEstaciones(nroLinea,peOrigen,peDestino);

	if(habilitado)
		grafoEstaciones->HabilitarArco(peOrigen,peDestino,arcoTrucho);
	else
		grafoEstaciones->DeshabilitarArco(peOrigen,peDestino,arcoTrucho);
	return OK;
}

Tupla<TipoRetorno, pLinea> Sistema::ConsultaLinea(nat nroLinea)
{
	if(enRangoLinea(nroLinea) && arrayLineas[nroLinea]!=NULL)
		return Tupla<TipoRetorno, pLinea>(OK, arrayLineas[nroLinea]);
	else
		return Tupla<TipoRetorno, pLinea>(ERROR,NULL);
}

Tupla<TipoRetorno, pEstacion> Sistema::ConsultaEstacion(Cadena nombreEstacion)
{
	pEstacion eAux = new Estacion(nombreEstacion,1,2);
	if(!hashEstaciones->pertenece(eAux))
		return Tupla<TipoRetorno, pEstacion>(ERROR, NULL);
	else
		return Tupla<TipoRetorno, pEstacion>(OK, hashEstaciones->getDato(eAux));
}

Tupla<TipoRetorno, Iterador<pEstacion>> Sistema::ListadoEstaciones()
{
	if(avlEstaciones->cardinal() ==0 )
		return Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR, NULL);
	else
		return Tupla<TipoRetorno, Iterador<pEstacion>>(OK, avlEstaciones->ObtenerIterador());
}

Tupla<TipoRetorno, pEstacion> Sistema::EstacionMasLineasHabilitadas()
{

	if(hashEstaciones->cardinal() == 0 
		|| cantLineas == 0)
		return Tupla<TipoRetorno, pEstacion>(ERROR, NULL);
	else
		return Tupla<TipoRetorno, pEstacion>(OK,grafoEstaciones->verticeMasAdyacentes());
}

// Entrega final Tipo 1

Tupla<TipoRetorno, Iterador<pEstacion>> Sistema::ListadoEstacionesHorario()
{
	if(avlEstacionesPorHorario->cardinal() ==0 )
		return Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR, NULL);
	else
		return Tupla<TipoRetorno, Iterador<pEstacion>>(OK, avlEstacionesPorHorario->ObtenerIterador());
}

Tupla<TipoRetorno, Iterador<pEstacion>> Sistema::TrayectoMenorDistancia(Cadena eOrigen, Cadena eDestino, nat hora)
{
	pEstacion eo=new Estacion(eOrigen,1,2);
	pEstacion ed = new Estacion(eDestino,1,2);


	if(!hashEstaciones->pertenece(eo)
		|| !hashEstaciones->pertenece(ed))
		return Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR, NULL);
	eo = hashEstaciones->getDato(eo);
	ed = hashEstaciones->getDato(ed);
	Iterador<pEstacion> retorno = grafoEstaciones->trayectoMenordistancia(eo,ed,hora);
	if(retorno == NULL)
		return Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR, NULL);
	return Tupla<TipoRetorno, Iterador<pEstacion>>(OK, retorno);
}

Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>> Sistema::CableadoMenorDistancia()
{
	Iterador<Tupla<pEstacion, pEstacion, nat>> retorno = grafoEstaciones->cableadoMenorDistancia();
	if(retorno == NULL)
		return Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>>(ERROR, NULL);
	return Tupla<TipoRetorno, Iterador<Tupla<pEstacion, pEstacion, nat>>>(OK, retorno);

}

Tupla<TipoRetorno, Iterador<pEstacion>> Sistema::ListadoTrayecto(Iterador<Cadena> estaciones)
{
	Puntero<ListaOrdenada<pEstacion>> estacionesPEstacion = new ListaOrdenada<pEstacion>(new ComparadorEstacionesLista());
	while(estaciones.HayElemento())
	{
		pEstacion aInsertar = new Estacion(estaciones.ElementoActual(),1,2);
		if(!hashEstaciones->pertenece(aInsertar))
		{
			return Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR, NULL);
		};
		estacionesPEstacion->agregarElemento(hashEstaciones->getDato(aInsertar));
		estaciones.Avanzar();
	};
	estaciones.Reiniciar();
	Iterador<pEstacion> iterEstaciones;
	iterEstaciones = grafoEstaciones->trayectoMenorTiempo(estacionesPEstacion->toArray().ObtenerIterador());
	if(iterEstaciones==NULL)
	{
		return Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR, NULL);
	}
	return Tupla<TipoRetorno, Iterador<pEstacion>>(OK, iterEstaciones);
}

Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> Sistema::ListadoTodosLosTrayectos(Cadena eOrigen, Cadena eDestino)
{
	pEstacion eo = new Estacion(eOrigen,1,2);
	pEstacion ed = new Estacion(eDestino,1,2);
	Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>> errorRetorno=Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>>(ERROR, NULL);
	if(!hashEstaciones->pertenece(eo))
		return errorRetorno;
	if(!hashEstaciones->pertenece(ed))
		return errorRetorno;
	if(!grafoEstaciones->HayCamino(eo,ed))
		return errorRetorno;
	eo = hashEstaciones->getDato(eo);
	ed= hashEstaciones->getDato(ed);
	return Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>>(OK,grafoEstaciones->todosLosTrayectos(eo,ed));
	/*;
	if(!(hashEstaciones->pertenece(eo) && hashEstaciones->pertenece(ed) && grafoEstaciones->HayCamino(eo,ed)))
	return Tupla<TipoRetorno, Iterador<Iterador<pEstacion>>>(ERROR, NULL);*/

	//grafoEstaciones->todosLosTrayectosBT(eo,ed,conocidos,solucion);	

}

// Entrega final Tipo 2

Tupla<TipoRetorno, Iterador<pEstacion>> Sistema::TrayectoMenosTransbordos(Cadena eOrigen, Cadena eDestino)
{
	pEstacion eo = new Estacion(eOrigen,1,2);
	pEstacion ed = new Estacion(eDestino,1,2);
	if(!hashEstaciones->pertenece(eo))
		return Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR, NULL);
	if(!hashEstaciones->pertenece(ed))
		return Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR, NULL);
	eo=hashEstaciones->getDato(eo);
	ed=hashEstaciones->getDato(ed);
	if(!grafoEstaciones->HayCamino(eo,ed))
		return Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR, NULL);

	Iterador<pEstacion> retorno = grafoEstaciones->trayectoMenosTrasbordosRetorno(eo,ed);
	return Tupla<TipoRetorno, Iterador<pEstacion>>(OK, retorno);
}

Tupla<TipoRetorno, nat> Sistema::CantidadMaxima(Cadena eOrigen, Cadena eDestino)
{
	pEstacion eo = new Estacion(eOrigen, 1 ,2);
	pEstacion ed = new Estacion(eDestino,1,2);
	if(!hashEstaciones->pertenece(eo))
		return Tupla<TipoRetorno, nat>(ERROR, 0); 
	if(!hashEstaciones->pertenece(ed))
		return Tupla<TipoRetorno, nat>(ERROR, 0);
	eo = hashEstaciones->getDato(eo);
	ed = hashEstaciones->getDato(ed);
	if(!grafoEstaciones->HayCamino(eo,ed))
		return Tupla<TipoRetorno, nat>(ERROR, 0);
	//todos los errores cubiertos
	nat cantMax=grafoEstaciones->cantidadMaximaPersonas(eo,ed);
	return Tupla<TipoRetorno, nat>(OK, cantMax);
}
bool Sistema::fueCalculado(int c, int lineaHasta)
{
	return dbLineas[lineaHasta][c]!=-1;
};
int Sistema::lineasAAbordarMochila(int c, int lineaHasta)
{
	
	if(c<0 )
		return -INFINITO;
	if(lineaHasta<0){

		return 0;
	}
	if(!fueCalculado(c,lineaHasta)){
		if(c==0){
			dbLineas[lineaHasta][c]=0;

		}else{
			dbLineas[lineaHasta][c]=max((int)(lineas[lineaHasta]->ObtenerDistancia() + lineasAAbordarMochila(c-lineas[lineaHasta]->ObtenerPrecio(), lineaHasta-1)),
				lineasAAbordarMochila(c, lineaHasta-1));
		}
	}/*else
		std::cout << "c: " << c << " linea: "<<lineaHasta << std::endl;*/
	return dbLineas[lineaHasta][c];
};
int Sistema::lineasAAbordarMochilaSinMemoria(int c, int lineaHasta)
{
	
	if(c<0 )
		return -INFINITO;
	if(lineaHasta<0){

		return 0;
	}

	if(c==0){
		dbLineas[lineaHasta][c]=0;

	}else{
		dbLineas[lineaHasta][c]=max((int)(lineas[lineaHasta]->ObtenerDistancia() + lineasAAbordarMochilaSinMemoria(c-lineas[lineaHasta]->ObtenerPrecio(), lineaHasta-1)),
			lineasAAbordarMochilaSinMemoria(c, lineaHasta-1));
	}

	return dbLineas[lineaHasta][c];
};

Tupla<TipoRetorno, nat, Iterador<pLinea>> Sistema::LineasAAbordarA(nat dineroMax)
{
	Puntero<ListaOrdenada<pLineaMia>> lLineas = new ListaOrdenada<pLineaMia>(new ComparadorLineaMia());
	Puntero<ListaOrdenada<pLinea>> lSolucion2 = new ListaOrdenada<pLinea>(new ComparadorLinea());
	//lineas = Array<pLineaMia>(this->cantLineas);
	if(lineas.ObtenerLargo()!=this->cantLineas){
		Iterador<pLinea> iter = arrayLineas.ObtenerIterador();
		///nat indice=0;
		while(iter.HayElemento())
		{
			if(iter.ElementoActual()!=NULL){
				lLineas->agregarElemento(new Linea(iter.ElementoActual()));
				//lineas[indice]=;
				//indice++;
			}
			iter.Avanzar();

		};
		iter.Reiniciar();
		//cout << lLineas->cardinal() << endl;
		lineas = lLineas->toArray();
	}

	int * distancia = 0;
	int * precio = 0;
	dbLineas = Matriz<int>(lineas.ObtenerLargo()+1,dineroMax+1);
	for(nat j=0;j<lineas.ObtenerLargo()+1;j++)
	{
		for(nat i=0;i<dineroMax+1;i++)
		{
			dbLineas[j][i] = -1;
		}
	}
	/*if(dbLineasAAbordar.ObtenerLargo()==0)
	{
		dbLineasAAbordar=Array<Matriz<int>>((int)INFINITO);
	}*/
	int result= lineasAAbordarMochila(dineroMax,lineas.ObtenerLargo()-1);
	
	//dbLineasAAbordar[dineroMax] = dbLineas;
	int lineaHasta = lineas.ObtenerLargo()-1;
	int plataMax = (int)dineroMax;
	while(plataMax>0 && lineaHasta>=0)
	{
		if(lineaHasta==0)
		{
			//lSolucion2->agregarElemento(arrayLineas[lineas[lineaHasta]->ObtenerNroLinea()]);
			plataMax=plataMax-lineas[lineaHasta]->ObtenerPrecio();
			if(plataMax>=0)
			{
				if(!lSolucion2->pertenece(arrayLineas[lineas[lineaHasta]->ObtenerNroLinea()]))
					lSolucion2->agregarElemento(arrayLineas[lineas[lineaHasta]->ObtenerNroLinea()]);
			}
		}
		else
		{
			if(dbLineas[lineaHasta][plataMax]==dbLineas[lineaHasta-1][plataMax])
				lineaHasta--;

			else
			{

				plataMax=plataMax-lineas[lineaHasta]->ObtenerPrecio();
				if(plataMax>=0){
					if(!lSolucion2->pertenece(arrayLineas[lineas[lineaHasta]->ObtenerNroLinea()])){
						lSolucion2->agregarElemento(arrayLineas[lineas[lineaHasta]->ObtenerNroLinea()]);
						lineaHasta--;
					}

				}else
				{
					if(!lSolucion2->pertenece(arrayLineas[lineas[lineaHasta-1]->ObtenerNroLinea()])){
						lSolucion2->agregarElemento(arrayLineas[lineas[lineaHasta-1]->ObtenerNroLinea()]);
						lineaHasta--;
					}

				}
			};
		};
	};
	return Tupla<TipoRetorno, nat, Iterador<pLinea>>(OK, result, lSolucion2->toArray().ObtenerIterador());
}

Tupla<TipoRetorno, nat, Iterador<pLinea>> Sistema::LineasAAbordarB(nat dineroMax)
{


	Puntero<ListaOrdenada<pLineaMia>> lLineas = new ListaOrdenada<pLineaMia>(new ComparadorLineaMia());
	Puntero<ListaOrdenada<pLinea>> lSolucion2 = new ListaOrdenada<pLinea>(new ComparadorLinea());
	//lineas = Array<pLineaMia>(this->cantLineas);
	if(lineas.ObtenerLargo()!=this->cantLineas)
	{
		Iterador<pLinea> iter = arrayLineas.ObtenerIterador();
		///nat indice=0;
		while(iter.HayElemento())
		{
			if(iter.ElementoActual()!=NULL){
				lLineas->agregarElemento(new Linea(iter.ElementoActual()));
				//lineas[indice]=;
				//indice++;
			}
			iter.Avanzar();

		};
		iter.Reiniciar();
		lineas = lLineas->toArray();
	}
	dbLineas = Matriz<int>(lineas.ObtenerLargo()+1,dineroMax+1);
	for(nat j=0;j<lineas.ObtenerLargo()+1;j++)
	{
		for(nat i=0;i<dineroMax+1;i++)
		{
			dbLineas[j][i] = -1;
		}
	}
	int result= lineasAAbordarMochilaSinMemoria(dineroMax,lineas.ObtenerLargo()-1);
	//dbLineas = dbLineasAAbordar[dineroMax];
	int lineaHasta = lineas.ObtenerLargo()-1;
	int plataMax = (int)dineroMax;
	while(plataMax>0 && lineaHasta>=0)
	{
		if(lineaHasta==0)
		{
			//lSolucion2->agregarElemento(arrayLineas[lineas[lineaHasta]->ObtenerNroLinea()]);
			plataMax=plataMax-lineas[lineaHasta]->ObtenerPrecio();
			if(plataMax>=0)
			{
				if(!lSolucion2->pertenece(arrayLineas[lineas[lineaHasta]->ObtenerNroLinea()]))
					lSolucion2->agregarElemento(arrayLineas[lineas[lineaHasta]->ObtenerNroLinea()]);
			}
		}
		else
		{
			if(dbLineas[lineaHasta][plataMax]==dbLineas[lineaHasta-1][plataMax])
				lineaHasta--;

			else
			{

				plataMax=plataMax-lineas[lineaHasta]->ObtenerPrecio();
				if(plataMax>=0){
					if(!lSolucion2->pertenece(arrayLineas[lineas[lineaHasta]->ObtenerNroLinea()])){
						lSolucion2->agregarElemento(arrayLineas[lineas[lineaHasta]->ObtenerNroLinea()]);
						lineaHasta--;
					}

				}else
				{
					if(!lSolucion2->pertenece(arrayLineas[lineas[lineaHasta-1]->ObtenerNroLinea()])){
						lSolucion2->agregarElemento(arrayLineas[lineas[lineaHasta-1]->ObtenerNroLinea()]);
						lineaHasta--;
					}

				}
			};
		};
	};
	return Tupla<TipoRetorno, nat, Iterador<pLinea>>(OK, result, lSolucion2->toArray().ObtenerIterador());
}

// Operaciones opcionales

Tupla<TipoRetorno, Iterador<pEstacion>> Sistema::EstacionesCriticas(Cadena eOrigen, Cadena eDestino)
{
	//return Tupla<TipoRetorno, Iterador<pEstacion>>(NO_IMPLEMENTADA, NULL);

	//limpiar el iterador que tiene nulls
	pEstacion eo = new Estacion(eOrigen,1,2);
	pEstacion ed = new Estacion(eDestino,1,2);
	if(!hashEstaciones->pertenece(eo)
		|| !hashEstaciones->pertenece(ed))
		return Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR, NULL);
	eo = hashEstaciones->getDato(eo);
	ed = hashEstaciones->getDato(ed);
	Iterador<pEstacion> iter = grafoEstaciones->estacionesCriticas(eo,ed);
	if(iter == NULL)
		return Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR, NULL);
	if(!grafoEstaciones->HayCamino(eo,ed))
		return Tupla<TipoRetorno, Iterador<pEstacion>>(ERROR, NULL);

	return Tupla<TipoRetorno, Iterador<pEstacion>>(OK, iter);
}
