#pragma once
#include "Puntero.h"
typedef unsigned int nat;

template <class T>
class nodoLista;

template<class T>
class Lista
{
public:
	virtual ~Lista(void){};
	virtual void agregarElemento(const T& t, bool ignorarIguales=false) abstract;
	//pre
	//pos inserta el elemento en la lista

	virtual bool esVacia() const { return cardinal()==0; };
	virtual nat cardinal() const abstract;
	virtual bool pertenece(const T& t) const abstract;

	virtual T obtenerPrimero() const abstract;
	//pre la lista no esta vacia
	//pos retorna el primer elemento de la lista

	virtual Puntero<nodoLista<T>> obtenerResto() const abstract;

	//pre lista no es vacia
	//pos retorna el resto de la lista

	virtual void eliminar(const T& t) abstract;


	virtual void imprimir() const abstract;

	virtual Puntero<Lista<T>> clone() const abstract;
	/*virtual Lista<T>& operator=(Lista<T> & l){

	}*/

//private:
	
	Puntero<nodoLista<T>> lista;
	nat tamano;
	
};

template <class T>
ostream& operator<<(ostream& out,  const Lista<T>& l)
{
	out<<endl << "+---INICIO LISTA---+" << endl << "{";
	Lista<T> lista = l;
	while(!lista.esVacia()){
		T t = lista.obtenerPrimero();
		out << "["<< t  << "] --> ";
//		lista = &lista.obtenerResto();
	}
	out<<endl << "+---FIN LISTA---+" << endl;
};


