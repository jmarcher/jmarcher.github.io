#pragma once
#include "IGrafo.h"
#include "Puntero.h"
#include "Matriz.h"
#include "Lista.h"
#include "Array.h"
#include "TablaHash.h"
#include "AVL.h"
#include "Comparador.h"
#include "IEstacion.h"
#include "Tupla.h"
#include "ListaOrdenada.h"
#include "arcoGrafoEstaciones.h"

struct nodoDijkstra
{
	bool conocido;
	nat distancia;
	nat tiempo;
	nat densidad;
	pEstacion ant;
	pEstacion estacion;
	pArcoEstaciones arcoUsado;
};

template<class V>
struct nodoVert{
		V vertice;
		nat nombreInterno;
		bool habilitado;
		nat cantAdyacentes;
		bool conocido;
	};


typedef unsigned int nat;
typedef Puntero<ListaOrdenada<pEstacion>> tListaEstaciones;

template<class A>
class nodoArco
{
public: 
	nodoArco(){};
	nodoArco(const A& a)
	{
		arco = a;
		kDelete = false;
	};
	A arco;
	bool habilitado;
	bool kDelete;
};


template<class V, class A>
class GrafoImp : public Grafo<V,A>
{
public:
	/*typedef struct
	{
		A arco;
		bool habilitado;
	} nodoArco;*/
	typedef Puntero<nodoArco<A>> pArco;
	

	//Creo que solo necesito el de compVertices
	//GrafoImp(nat cantMaxVertices,const Puntero<Comparador<V>>& compVertices);
	GrafoImp(nat cantMaxVertices,const Puntero<Comparador<V>>& compVertices,const Puntero<Comparador<A>>& compArcos);
	void InsertarVertice(const V& v);
	void InsertarArco(const V& o, const V& d, A arco);

	bool EliminarArco(const V& o, const V& d, const A& a);
	bool EliminarVertice(const V& v);

	bool HabilitarArco(const V& o, const V& d, const A& a);
	bool DeshabilitarArco(const V& o, const V& d, const A& a);

	bool HabilitarVertice(const V& v);
	bool DeshabilitarVertice(const V& v);

	bool estaHabilitado(const V& v) const;
	bool estaHabilitado(const V& o, const V& d, const A& a) const;

	bool pertenece(const V& v) const;

	bool estaLleno() const;

	nat cantVertices() const {return cardinal;};
	Puntero<Grafo<V,A>> clon() const;

	Puntero<Grafo<V,A>> crearVacio() const;
	Grafo<V,A>& operator=(const Grafo<V,A>& g);

	const V& verticeMasAdyacentes() const;

	Iterador<A> arcos(const V& o, const V& d) const;
	//pre
	//pos retorna un iterador sobre los arcos o-d

	Iterador<V> vertices() const;
	//pre
	//pos retorna un iterador sobre los vertices del grafo


	//O tambien incidentes
	Iterador<A> adyacentes(const V& v) const;

	Iterador<A> incidentes(const V& v) const;

	Iterador<pEstacion> trayectoMenordistancia(const pEstacion& o, const pEstacion& d, nat hora);
	Iterador<pEstacion> estacionesCriticas(const pEstacion& o, const pEstacion& d );

	Tupla<Matriz<A>,nat> kruskal();

	Array<nodoDijkstra> dijkstra(const pEstacion &origen);

	Array<nodoDijkstra> dijkstraDensidad(const pEstacion &origen);

	virtual ~GrafoImp(void);
	nat nombreInterno(const V& v) const;
	Iterador<Tupla<pEstacion, pEstacion, nat>> cableadoMenorDistancia();
	bool HayCamino(pEstacion origen, pEstacion destino);
	bool perteneceCamino(Array<Iterador<pEstacion>> caminos, Iterador<pEstacion> camino);
	Iterador<Iterador<pEstacion>> todosLosTrayectos(const pEstacion& origen, const pEstacion& destino);
	void todosTrayectos(const pEstacion& origenActual, const pEstacion& destino, Puntero<ListaOrdenada<pEstacion>> lstActual, Puntero<ListaOrdenada<tListaEstaciones>> lstSolucion);
	
	void trayectoMenosTrasbordos(const pEstacion& origenActual, const pEstacion& destino, 
		Puntero<ListaOrdenada<pEstacion>> lstActual,Puntero<ListaOrdenada<tListaEstaciones>> lstSolucion,
		int cantLineasActuales,Puntero<int> mejorCantLineas, int distanciaActual, Puntero<int> mejorDistancia, int lineaActual);

	Iterador<pEstacion> trayectoMenosTrasbordosRetorno(const pEstacion& origen, const pEstacion& destino);

	Iterador<pEstacion> trayectoMenorTiempo(Iterador<pEstacion> pasar);
	Iterador<pEstacion> crearCamino(const pEstacion& origen, const pEstacion& destino, Array<nodoDijkstra> dbDij);
	Tupla<Iterador<A>,nat> crearCaminoDensidad(const pEstacion& origen, const pEstacion& destino, Array<nodoDijkstra> dbDij);
	nat cantidadMaximaPersonas(const pEstacion& origen, const pEstacion& destino);

	//auxiliares
	void dejarAristasEnCero();
	void actualizarDensidad(const pEstacion& origen, const pEstacion& destino, pArcoEstaciones arco, nat nuevaDensidad);
private:
	//atributos
	nat cantMaxVertices;
	nat cardinal;
	

	 Puntero<Comparador<V>> aCompVertice;
	 Puntero<Comparador<A>> aCompArco;

	 nodoVert<V> nodoMasAdy;

	Array<nodoVert<V>> aVertices;
	Puntero<TablaHash<nodoVert<V>>> thVertices;
	//Matriz<Puntero<AVL<Puntero<nodoArco<A>>>>> aArcos;
	Matriz<Puntero<AVL<pArco>>> aArcos;
	//Matriz<nodoArco> aArcos;
	//m�todos
	
	void maxAdy();
	pEstacion ObtenerSiguienteDesconocido(Array<nodoDijkstra> dbDij);
	pEstacion ObtenerSiguienteDesconocidoDensidad(Array<nodoDijkstra> dbDij);
	bool HayMasDesconocidos(Array<nodoDijkstra> dbDij);
	Array<int> componente;
	

	int mejorCantLineasAt;
	int mejorDistanciaAt;




	//funciones auxiliares
	int componenteDe(int v){
		if (componente[v]==v)
			return v;
		else
		{
			int k = componenteDe(componente[v]);
			componente[v]=k;
			return k;
		};
	};
	void unir(nat c1, nat c2) //une componentes
	{
		componente[c1]=componente[c2];
	};

};
#include "GrafoImp.cpp"

