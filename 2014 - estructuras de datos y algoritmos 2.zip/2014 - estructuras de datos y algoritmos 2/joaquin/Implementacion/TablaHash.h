#pragma once
#include "Puntero.h"
#include "Array.h"
#include "AVL.h"
#include "FuncionHash.h"
#include "Comparador.h"

typedef unsigned int nat;


template<class T>
class TablaHash
{
public:
	TablaHash(const Puntero<FuncionHash<T>>& fH, const Puntero<Comparador<T>>& comp, nat capacidad);

	void insertar(const T& t);
	void eliminar(const T& t);

	bool pertenece(const T& t) const;

	T& getDato(const T& t) const;

	nat cardinal() const {return cantNodos;};

	
	//pre !pertenece(t)
	//pos inserta el elemento
	/*
	metodos:
	insertar
	eliminar

	pertenencia
	

	no se que mas
	*/
	~TablaHash(void){};

private:

	nat cantNodos;
	Puntero<FuncionHash<T>> aFH;

	Puntero<Comparador<T>> aComp;

	struct nodoHash{
		Puntero<AVL<T>> datos;
	};
	Array<nodoHash> tabla;
	int maxNodos; //el siguiente primo de capacidad*1.5
};
#include "TablaHash.cpp"