#pragma once
#include "Lista.h"
#include "Puntero.h"
#include "Comparador.h"
#include "Array.h"
#include <iostream>
template<class T>
class nodoLista{
public:
		T elemento;
		Puntero<nodoLista<T>> siguiente;
};

template<class T>
class ListaOrdenada : public Lista<T>
{
public:
	ListaOrdenada();
	ListaOrdenada(Puntero<Comparador<T>> comp);
	nat cardinal() const;
	bool esVacia(){return lista==NULL;}
	T obtenerPrimero() const;
	Puntero<nodoLista<T>> obtenerResto() const;
	void agregarElemento(const T& t, bool ignorarIguales=false);

	void eliminar(const T& t);

	//Mejorable
	bool pertenece(const T& t) const;

	void imprimir() const;

	Puntero<Lista<T>> clone() const;
	Array<T> toArray() const;

	~ListaOrdenada(){};
	void eliminarPrimero(){ if(card>0) eliminar(obtenerPrimero());};
private:
	nat card;
	Puntero<Comparador<T>> aComp;
};
#include "ListaOrdenada.cpp"

