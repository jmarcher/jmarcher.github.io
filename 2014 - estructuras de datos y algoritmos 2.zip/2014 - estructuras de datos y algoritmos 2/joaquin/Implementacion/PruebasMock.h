﻿#pragma once

#include "IEstacion.h"
#include "ILinea.h"

class EstacionMock : public IEstacion
{
public:
	EstacionMock(Cadena nombre, nat hAbre, nat hCierra);

	Cadena ObtenerNombre() const;
	nat ObtenerHAbre() const;
	nat ObtenerHCierra() const;

	bool operator==(const IEstacion& e) const;

private:
	Cadena m_Nombre;
	nat m_HAbre;
	nat m_HCierra;
};

class LineaMock : public ILinea
{
public:
	LineaMock(nat nroLinea, nat precio, Iterador<Tupla<pEstacion, nat, nat, nat>> estaciones);

	nat ObtenerNroLinea() const;
	nat ObtenerPrecio() const;
	Iterador<Tupla<pEstacion, nat, nat, nat>> ObtenerEstaciones() const;

	bool operator==(const ILinea& l) const;

private:
	nat m_NroLinea;
	nat m_Precio;
	Iterador<Tupla<pEstacion, nat, nat, nat>> m_Estaciones;
};
