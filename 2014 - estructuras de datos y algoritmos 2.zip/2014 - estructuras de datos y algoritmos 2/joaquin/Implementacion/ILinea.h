﻿#pragma once

#include "Puntero.h"
#include "Iterador.h"
#include "Tupla.h"
#include "IEstacion.h"

class IEstacion;
typedef Puntero<IEstacion> pEstacion;

class ILinea abstract
{
public:
	virtual ~ILinea(){}

	virtual nat ObtenerNroLinea() const abstract;
	virtual nat ObtenerPrecio() const abstract;
	virtual Iterador<Tupla<pEstacion, nat, nat, nat>> ObtenerEstaciones() const abstract;

	virtual bool operator==(const ILinea& l) const abstract;
};
typedef Puntero<ILinea> pLinea;