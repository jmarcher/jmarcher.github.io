#ifndef TABLAHASH_CPP
#define TABLAHASH_CPP
#include "TablaHash.h"
#include "AVL.h"
#include <iostream>
using namespace std;


template<class T>
TablaHash<T>::TablaHash(const Puntero<FuncionHash<T>>& fH, const Puntero<Comparador<T>>& comp, nat capacidad)
{
	/*if(capacidad>1500)
		capacidad=1511;*/
	maxNodos = capacidad;
	tabla = Array<nodoHash>(maxNodos);
	for(nat i=0; i<capacidad; i++)
	{
		tabla[i].datos = new AVL<T>(comp);
	};
	aFH = fH;
	cantNodos=0;
}

template<class T>
void TablaHash<T>::insertar(const T& t)
{
	
	nat indice = aFH->CodigoDeHash(t) % maxNodos;
	cantNodos++;
	tabla[indice].datos->insertar(t);
};

template<class T>
void TablaHash<T>::eliminar(const T& t)
{
	cantNodos--;
	nat indice = aFH->CodigoDeHash(t) % maxNodos;
	tabla[indice].datos->eliminar(t);
};

template<class T>
bool TablaHash<T>::pertenece(const T& t) const
{
	nat indice = aFH->CodigoDeHash(t) % maxNodos;
	return tabla[indice].datos->pertenece(t);
};

template<class T>
T& TablaHash<T>::getDato(const T& t) const{
	nat indice = aFH->CodigoDeHash(t) % maxNodos;
	return tabla[indice].datos->getDato(t);
}
#endif
