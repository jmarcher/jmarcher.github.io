#pragma once

enum TipoRetorno
{
	OK, ERROR, NO_IMPLEMENTADA
};
