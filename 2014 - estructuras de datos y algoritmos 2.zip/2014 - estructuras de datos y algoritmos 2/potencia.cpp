
float pot(float a, int k)
{
	if(a==0 && k<=0) return error();
	if(a==o && k !=0) return 0;
	if(a!=0 && k<0) return pot(1/a, -k);
	if(esPar(k))
	{
		float z = pot(a,k/2);
		return z*z;
	}
	else
	{
		return a*pot(a,k-1);
	}
};