int cantPoligonos(Grafo<V,A>*g)
{
	int cant=0;
	Lista<A>*opl-new ListaImp<A>();
	Iterador<V> *ct = g->vertices();
	while(!ct->esFin())
	{
		Vertice v = ct->actual();
		ct->avanzar();
		Iterador<A>*a=g->adyacentes(v);
		while(!a->esFin())
		{
			Arista ar = a->actual();
			a->avanzar();
			formarPoligono(g,v,v,ar.destino, ar.peso,1,poligono);
			if(!pol->esVacia)
			{
				cont++;
				borrarAristas(g,pol);
				a=g->adyacentes(v);
				delete pol;
				pol = new ListaImp<A>();
			}
		}
	}
};
void formarPoligono(Grafo<V,A>*g, Vertice origen, Arista aActual,bool &exito, int peso, int longitud, Lista<A>* poligono)
{
	if(!pase(aActual,pol))
	{
		if(aActual.peso == peso)
		{
			pol->agregar(aActual);
			if(llegueAlOrigen(origen,aActual) && longitud>2)
			{
				exito=true;
			};
		};
	};
};