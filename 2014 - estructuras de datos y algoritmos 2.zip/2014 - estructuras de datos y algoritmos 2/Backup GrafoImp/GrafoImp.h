#pragma once
#include "IGrafo.h"
#include "Puntero.h"
#include "Matriz.h"
#include "Lista.h"
#include "Array.h"
#include "TablaHash.h"
#include "AVL.h"
#include "Comparador.h"
typedef unsigned int nat;

template<class V, class A>
class GrafoImp : public Grafo<V,A>
{
public:
	typedef struct
	{
		A arco;
		bool habilitado;
	} nodoArco;

	//Creo que solo necesito el de compVertices
	GrafoImp(nat cantMaxVertices,const Puntero<Comparador<V>>& compVertices);
	GrafoImp(nat cantMaxVertices,const Puntero<Comparador<V>>& compVertices,const Puntero<Comparador<A>>& compArcos);
	void InsertarVertice(const V& v);
	void InsertarArco(const V& o, const V& d, A arco);

	bool EliminarArco(const V& o, const V& d, const A& a);
	bool EliminarVertice(const V& v);

	bool HabilitarArco(const V& o, const V& d, const A& a);
	bool DeshabilitarArco(const V& o, const V& d, const A& a);

	bool HabilitarVertice(const V& v);
	bool DeshabilitarVertice(const V& v);

	bool estaHabilitado(const V& v) const;
	bool estaHabilitado(const V& o, const V& d, const A& a) const;

	bool pertenece(const V& v) const;

	bool estaLleno() const;

	nat cantVertices() const {return cardinal;};
	Puntero<Grafo<V,A>> clon() const;

	Puntero<Grafo<V,A>> crearVacio() const;
	Grafo<V,A>& operator=(const Grafo<V,A>& g);

	Iterador<A> arcos(const V& o, const V& d) const;
	//pre
	//pos retorna un iterador sobre los arcos o-d

	Iterador<V> vertices() const;
	//pre
	//pos retorna un iterador sobre los vertices del grafo


	//O tambien incidentes
	Iterador<A> adyacentes(const V& v) const;

	Iterador<A> incidentes(const V& v) const;


	virtual ~GrafoImp(void);

private:
	//atributos
	nat cantMaxVertices;
	nat cardinal;
	struct nodoVert{
		V vertice;
		bool habilitado;
	};

	 Puntero<Comparador<V>> aCompVertice;
	 Puntero<Comparador<A>> aCompArco;

	Array<nodoVert> aVertices;
	//Puntero<TablaHash<V>> thVertices;
	//Matriz<Puntero<AVL<Puntero<nodoArco<A>>>>> aArcos;
	Matriz<nodoArco> aArcos;
	//m�todos
	nat nombreInterno(const V& v) const;

};
#include "GrafoImp.cpp"

