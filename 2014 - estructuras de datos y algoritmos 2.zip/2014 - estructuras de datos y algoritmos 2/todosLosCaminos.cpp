void todosLosCaminos(Nodo origenActual, Nodo destino, int costoActual, int costoMaximo, 
Camino & caminoActual,Lista<Camin>& todosLosCaminos, Grafo<Nodo,Arco>& g)
{
	if(EsIgual(origenActual,destino))
	{
		//llegue a destino
		marcarConocido(origenActual);
		caminoActual.agregar(origenActual);
		Camino aInsertar = caminoActual.clonar();
		if(costoActual<=costoMaximo)
		{
			todosLosCaminos.agregar(aInsertar);
		};
		caminoActual.eliminar(origenActual);
		return;
	}
	if(esConocido(origenActual))
		return;
	
	marcarConocido(origenActual);
	Lista<Arco> arco = g.adyacentes(origenActual);
	while(!arco.esVacia())
	{
		todosLosCaminos(arco.destino, destino, costoActual+arco.costo,costoMaximo,caminoActual,todosLosCaminos,g);
		arco = arco.siguiente();
	};
	caminoActual.eliminar(arco.destino);
	marcarDesconocido(arco.destino);
	
};
#define MAX_N 1000
#define MAX_M 1000

int foo(int n, int m)
{
	if (m == 0 || n == m)
	return 1;
	return foo(n-1, m) + foo(n-1, m-1);
}

bool fueCalculado(int n, int m, Matriz<int> dbPascal)
{
	return dbPascal[n][m]!=-1;
}

int Pascal(int n, int m, Matriz<int> dbPascal)
{
	if (m == 0 || n == m)
		return 1;
	else
	{
		if(!fueCalculado(n,m,dbPascal)){
			dbPascal[n][m] = Pascal(n-1,m) + Pascak(n-1,m-1,dbPascal);
		}
	
	return dbPascal[n][m];
}

void inicializar(Matriz<int> dbPascal)
{
	for(int i = 0; i<MAX_N ; i++)
	{
		for(int i = 0; i<MAX_N ; i++)
		{
		
		}
	}
}

int TrianguloPascal(int n, int m)
{
	Matriz<int> dbPascal = Matriz<int>(MAX_N,MAX_M);
	inicializar(dbPascal);
	return Pascal(n,m,dbPascal);
};