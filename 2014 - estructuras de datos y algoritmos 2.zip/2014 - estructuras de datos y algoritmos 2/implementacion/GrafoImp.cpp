#ifndef GRAFOIMP_CPP
#define GRAFOIMP_CPP

#include "GrafoImp.h"

template<class V, class A>
GrafoImp<V,A>::GrafoImp(nat maxVertices)
{
	this->cardinal = 0;
	this->cantMaxVertices =  maxVertices;
	//this->aArcos = Matriz<Puntero<AVL<Puntero<nodoArco<A>>>>>(cantMaxVertices);
	this->aArcos = Matriz<nodoArco>(cantMaxVertices);
	this->aVertices = Array<nodoVert>(cantMaxVertices);

	/*for(nat i=0;i<cantMaxVertices;i++)
	{
		for(nat j=0;j<cantMaxVertices;j++)
		{
			this->aArcos[i][j] = new AVL<Puntero<nodoArco<A>>>();
		};
	};*/
	//this->thVertices =  new TablaHash<V>(
};

template<class V, class A>
void GrafoImp<V,A>::InsertarVertice(const V& v)
{
	if(!pertenece(v)){
		if(!estaLleno()){
			nodoVert nV;
			nV.vertice = v;
			nV.habilitado = true;
			this->aVertices[this->cardinal]=nV;
			this->cardinal++;
		};
	};
};

template<class V, class A>
void GrafoImp<V,A>::InsertarArco(const V& o, const V& d, A arco)
{
	//si ya existe el arco, lo actualiza.
	if(pertenece(o) && pertenece(d) && estaHabilitado(o) && estaHabilitado(d))
	{
		nat origen = nombreInterno(o);
		nat destino = nombreInterno(d);
		nodoArco nA;
		nA.arco = arco;
		nA.habilitado = true;
		this->aArcos[origen][destino] = nA;
	};
};

template<class V, class A>
bool GrafoImp<V,A>::EliminarArco(const V& o, const V& d, const A& a)
{
	assert(false);
	//SIN IMPLEMENTAR
	return false;
};


template<class V, class A>
bool GrafoImp<V,A>::EliminarVertice(const V& v)
{
	assert(false);
	//SIN IMPLEMENTAR
	return false;
};

template<class V, class A>
bool GrafoImp<V,A>::HabilitarArco(const V& o, const V& d, const A& a)
{
	if(pertenece(o) && pertenece(d))
	{
		nat origen  = nombreInterno(o);
		nat destino = nombreInterno(d);
		if(this->aArcos[origen][destino].arco != NULL)
		{
			/*Puntero<nodoArco<A>> nA = this->aArcos[origen][destino]->getNodo(a);
			nA->habilitado = true;*/
			this->aArcos[origen][destino].habilitado=true;
			return true;
		}
		return false;
	}
	return false;
};

template<class V, class A>
bool GrafoImp<V,A>::DeshabilitarArco(const V& o, const V& d, const A& a)
{
	if(pertenece(o) && pertenece(d))
	{
		nat origen = nombreInterno(o);
		nat destino = nombreInterno(d);
		if(this->aArcos[origen][destino].arco != NULL)
		{
			/*Puntero<nodoArco<A>> nA = this->aArcos[origen][destino]->getNodo(a);
			nA->habilitado = false;*/
			this->aArcos[origen][destino].habilitado=false;
			return true;
		}
		return false;
	}
	return false;
};

template<class V, class A>
bool GrafoImp<V,A>::HabilitarVertice(const V& v)
{
	if(pertenece(v))
	{
		nat indice = nombreInterno(v);
		this->aVertices[indice].habilitado=true;
		return true;
	};
	return false;
};

template<class V, class A>
bool GrafoImp<V,A>::DeshabilitarVertice(const V& v)
{
	if(pertenece(v))
	{
		nat indice = nombreInterno(v);
		this->aVertices[indice].habilitado=false;
		return true;
	};
	return false;
};

template<class V, class A>
bool GrafoImp<V,A>::estaHabilitado(const V& v) const
{
	nat indice = nombreInterno(v);
	return aVertices[indice].habilitado;
};

template<class V, class A>
bool GrafoImp<V,A>::estaHabilitado(const V& o, const V& d, const A& a) const
{
	nat origen = nombreInterno(o);
	nat destino = nombreInterno(d);
	nodoArco nA = this->aArcos[origen][destino];
		
	return estaHabilitado(o) && estaHabilitado(d) && nA.habilitado;
};



template<class V, class A>
Puntero<Grafo<V,A>> GrafoImp<V,A>::clon() const
{
	assert(false);
	//SIN IMPLEMENTAR
	return NULL;
};

template<class V, class A>
Puntero<Grafo<V,A>> GrafoImp<V,A>::crearVacio() const
{
	return new GrafoImp<V,A>(cantMaxVertices);
};

template<class V, class A>
Grafo<V,A>& GrafoImp<V,A>::operator=(const Grafo<V,A>& g)
{
	
	return *this;
};

template<class V, class A>
Puntero<Iterador<A>> GrafoImp<V,A>::arcos(const V& o, const V& d) const
{	
	Array<A> arreglo = Array<A>(cantMaxVertices*10);
	if(pertenece(o) && pertenece(d))
	{
		nat origen = nombreInterno(o);
		nat destino = nombreInterno(d);
		nodoArco nA = this->aArcos[origen][destino];
		if(nA.habilitado)
			arreglo[0]=nA.arco;
	};
	return &arreglo.ObtenerIterador();
};
//pre
//pos retorna un iterador sobre los arcos o-d

template<class V, class A>
Puntero<Iterador<V>> GrafoImp<V,A>::vertices() const
{
	return &this->aVertices.ObtenerIterador();
};
//pre
//pos retorna un iterador sobre los vertices del grafo


//O tambien incidentes
template<class V, class A>
Puntero<Iterador<A>> GrafoImp<V,A>::adyacentes(const V& v) const
{
	Array<A> arreglo = Array<A>(cantMaxVertices*10);
	if(pertenece(v))
	{
		nat origen = nombreInterno(v);
		for(nat i = 0; i<cantMaxVertices ; i++)
		{
			nodoArco nA = this->aArcos[origen][i];
			if(i!=origen)
				if(nA.habilitado)
					arreglo[i] = nA.arco;
		};
	};
	return &arreglo.ObtenerIterador();
};

template<class V, class A>
Puntero<Iterador<A>> GrafoImp<V,A>::incidentes(const V& v) const
{
	Array<A> arreglo = Array<A>(cantMaxVertices*10);
	if(pertenece(v))
	{
		nat destino = nombreInterno(v);
		for(nat i = 0; i<cantMaxVertices ; i++)
		{
			nodoArco nA = this->aArcos[i][destino];
			if(i!=destino)
				if(nA.habilitado)
					arreglo[i] = nA.arco;
		};
	};
	return &arreglo.ObtenerIterador();
};

template<class V, class A>
bool GrafoImp<V,A>::pertenece(const V& v) const
{
	bool esta=false;
	for(nat i = 0; i < cardinal; i++)
	{
		if(aVertices[i].vertice == v && estaHabilitado(v))
			esta=true;
	};
	return esta;
};

template<class V, class A>
nat GrafoImp<V,A>::nombreInterno(const V& v) const
{
	int pos=0;
	for(nat i = 0; i < cardinal; i++)
	{
		if(aVertices[i].vertice == v )
			pos=i;
	};
	return pos;
};

template<class V, class A>
GrafoImp<V,A>::~GrafoImp(void)
{
};
#endif