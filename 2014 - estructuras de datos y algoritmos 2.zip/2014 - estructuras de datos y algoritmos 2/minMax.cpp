void MINMAX(int * v, int izq, int der, int &m, int &M)
{
	int medio, mIzq, mDr, MIzq, MDer;
	if(izq==der)
	{
		m=v[izq]; M=v[izq];
	}
	else
	{
		if(izq==der-1)//2 elementos
		{
			if(v[izq]<v[der])
			{
				m=v[izq]; M=[der];
			}
			else
			{
				m=v[der]; M=[izq];
			};
		}
		else
		{
			medio=(izq+der)/2;
			MINMAX(v, izq, medio, mIzq, MIzq);
			MINMAX(v, medio+1, der, mDer, MDer );
			m=min(mIzq,mDer);
			M=max(MIzq, MDer);
		};
	};
};