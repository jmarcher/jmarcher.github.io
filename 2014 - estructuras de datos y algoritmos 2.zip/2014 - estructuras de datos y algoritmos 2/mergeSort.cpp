void MS(int * v, int izq, int der)
{
	if(izq<der)
	{
		int medio=(izq+der)/2;
		MS(v,izq,medio);
		MS(v,medio+1,der);
		intercalar(v,izq,medio,der);
	};
};
